# -*- coding: utf-8 -*-
"""
رادار الأخبار العالمية — بحث بالعربية في مصادر إسرائيلية وأمريكية وبريطانية + بحث عام عبر GDELT
"""
import hashlib
from collections import Counter
import html
import json
import os
import re
from datetime import datetime, timedelta, timezone
from urllib.parse import quote, unquote, urlparse

import streamlit as st

import core
import dossiers as dossiers_mod
import intel
from core import fmt_seen, tr
import gh_actions
import watch as watch_mod
import hmac
import links as links_mod
from about import TAB_HELP, TAB_NAMES, plain as about_plain, sections as about_sections
import keys as keys_mod
import store
import time
import writers as writers_mod
from sources import ARAB_EG_GROUP, ARABIC, EGYPT, EGYPT_ARABIC, FLAGS, ISRAEL, REGION, SECTIONS, UK, USA, egypt_only, source_country
from writers import WRITERS

DOMAIN_LABELS = {}
for _g in (ISRAEL, USA, UK, REGION, ARABIC, EGYPT):
    for _entries in _g.values():
        for _label, _doms, _ in _entries:
            for _d in _doms.split("|"):
                DOMAIN_LABELS.setdefault(_d, _label)
for _n, _d, *_rest in intel.SOURCES:
    DOMAIN_LABELS.setdefault(_d, _n)


def source_name(domain):
    domain = (domain or "").lower().replace("www.", "")
    for d, label in DOMAIN_LABELS.items():
        if domain == d or domain.endswith("." + d):
            return label
    return domain


AR_NAMES = {  # أسماء الجرايد بالعربي زي ما بنقولها (الترجمة الآلية ممكن تقول «الحارس» بدل الجارديان)
    "AP News": "أسوشيتد برس", "Al-Monitor": "المونيتور", "Atlantic Council": "المجلس الأطلسي", "Axios": "أكسيوس", "BBC": "بي بي سي",
    "Baker Institute (Rice)": "معهد بيكر (جامعة رايس)", "Bloomberg": "بلومبرج", "Brookings": "معهد بروكينجز", "CNN": "سي إن إن",
    "CSIS": "مركز الدراسات الاستراتيجية والدولية", "Chatham House": "تشاتام هاوس", "Council on Foreign Relations": "مجلس العلاقات الخارجية",
    "DEBKAfile": "ديبكا", "Defense One": "ديفنس وان", "Financial Times": "فايننشال تايمز", "Foreign Affairs": "فورين أفيرز",
    "Foreign Policy": "فورين بوليسي", "Fox News": "فوكس نيوز", "JNS (Jewish News Syndicate)": "جي إن إس (وكالة الأخبار اليهودية)",
    "Jewish Chronicle": "جويش كرونيكل", "Jewish Insider": "جويش إنسايدر", "MSNBC": "إم إس إن بي سي", "Middle East Eye": "ميدل إيست آي",
    "Middle East Institute": "معهد الشرق الأوسط", "Middle East Monitor": "ميدل إيست مونيتور", "NPR": "الإذاعة الوطنية الأمريكية NPR",
    "Politico": "بوليتيكو", "Quincy Institute": "معهد كوينسي", "RUSI": "المعهد الملكي للخدمات المتحدة RUSI", "Reuters": "رويترز",
    "Sky News": "سكاي نيوز", "The Economist": "الإيكونوميست", "The Guardian": "الجارديان", "The Hill": "ذا هيل",
    "The Independent": "الإندبندنت", "The Intercept": "ذا إنترسبت", "The New Arab": "العربي الجديد (إنجليزي)",
    "The New York Times": "نيويورك تايمز", "The Telegraph": "التلجراف", "The Times": "التايمز", "The Wall Street Journal": "وول ستريت جورنال",
    "The Washington Post": "واشنطن بوست", "Washington Institute": "معهد واشنطن", "i24NEWS": "آي 24 نيوز", "openDemocracy": "أوبن ديموقراسي",
}


@st.cache_data(ttl=7 * 86400, show_spinner=False)
def _ar_name(label):
    if label in AR_NAMES:
        return AR_NAMES[label]
    if re.search(r"[\u0600-\u06FF]", label):
        return label
    try:
        return tr(label, "en", "ar") or label
    except Exception:
        return label


def src_label(domain, with_domain=True):
    """«اسم المصدر بالعربية · 🏳️ دولته» — يُستخدم في كل مكان يظهر فيه مصدر. لا يُسقط الصفحة أبداً"""
    try:
        dom = str(domain or "").lower().replace("www.", "")
        name = str(source_name(dom))
        name_ar = str(_ar_name(name)) if name != dom else dom
        country = str(source_country(dom) or "")
        out = html.escape(name_ar)
        if with_domain and name_ar != dom:
            out += f" ({html.escape(dom)})"
        out += (f" · {FLAGS.get(country, '🏳️')} {country}" if country else " · 🏳️ دولة غير محددة")
        return out
    except Exception as e:  # أي خطأ هنا لا يجب أن يكسر عرض الخبر
        return html.escape(str(domain or "")) + f" (تعذّر تحديد الدولة: {type(e).__name__})"


st.set_page_config(page_title="مرصد الأخبار", page_icon="🛰️", layout="wide", initial_sidebar_state="collapsed")

st.markdown(
    """
<style>
:root { --marsad-bg:#07111f; --marsad-panel:#101e30; --marsad-line:#263c56; --marsad-accent:#168cf0; --marsad-muted:#91a4ba; }
.stApp { background: radial-gradient(ellipse at 50% -20%, #17375b 0%, #091728 42%, #07111f 78%); }
[data-testid="stHeader"] { background:rgba(7,17,31,.88); }
[data-testid="stMainBlockContainer"] { max-width:1500px; padding-top:1.1rem; padding-bottom:3rem; }
.stMarkdown, label, [data-testid="stWidgetLabel"], [data-testid="stCaptionContainer"] { direction:rtl; text-align:right; }
h1,h2,h3 { letter-spacing:0; }
h1 { font-size:clamp(1.5rem,2.4vw,2.25rem)!important; font-weight:800!important; }
.ar-title {font-size:1.08rem; font-weight:750; line-height:1.8; margin-bottom:4px;}
.ltr {direction:ltr; text-align:left; color:#9aacc0; font-size:.86rem; margin-bottom:2px;}
.meta {color:var(--marsad-muted); font-size:.82rem; margin:6px 0;}
.badge {background:#16385a; color:#bfe3ff; padding:2px 9px; border-radius:999px; font-size:.76rem;}
a.btn {display:inline-block; background:#087bd4; color:#fff!important; padding:8px 16px; border-radius:10px; text-decoration:none; font-weight:650; margin-top:4px;}
a.btn:hover {background:#1596ff;}
.card,.hm-row {border:1px solid var(--marsad-line); border-radius:14px; padding:13px 15px; margin-bottom:10px; background:linear-gradient(145deg,rgba(21,42,66,.92),rgba(12,27,44,.9));}
.article-body p {line-height:2; font-size:1.05rem; margin-bottom:1rem;}
[data-testid="stTabs"] > div[role="tablist"] { gap:7px; padding:7px; border:1px solid rgba(100,145,190,.25); border-radius:15px; background:rgba(8,22,38,.76); flex-wrap:nowrap; overflow-x:auto; }
[data-testid="stTabs"] button[role="tab"] { border:1px solid #29435f!important; border-radius:11px!important; padding:10px 16px!important; min-height:44px!important; background:#12243a!important; color:#d7e7f8!important; white-space:nowrap!important; font-weight:650!important; }
[data-testid="stTabs"] button[role="tab"][aria-selected="true"] { background:linear-gradient(135deg,#087bd4,#0755a0)!important; border-color:#28a7ff!important; color:white!important; box-shadow:0 0 0 1px rgba(40,167,255,.2),0 5px 18px rgba(0,80,160,.25)!important; }
[data-baseweb="tab-highlight"],[data-baseweb="tab-border"] {display:none!important;}
[data-testid="stVerticalBlockBorderWrapper"] { border-color:rgba(100,145,190,.22)!important; border-radius:15px!important; }
[data-testid="stMetric"] { background:rgba(17,37,59,.8); border:1px solid var(--marsad-line); border-radius:13px; padding:12px; }
[data-testid="stButton"] button[kind="primary"],button[kind="primary"] { background:linear-gradient(120deg,#087bd4,#0755a0); border:1px solid #249dff; border-radius:11px; font-weight:750; }
[data-testid="stExpander"] { border:1px solid rgba(100,145,190,.25); border-radius:12px; background:rgba(14,30,48,.55); }
[data-baseweb="select"] > div, [data-testid="stTextInput"] input, [data-testid="stTextArea"] textarea { border-radius:10px!important; }
[data-testid="stCaptionContainer"] { color:#9eb1c6; }
.hm-stat {border:1px solid var(--marsad-line); border-radius:13px; padding:12px; text-align:center; background:rgba(16,34,54,.9);}
.hm-stat b {display:block; font-size:1.55rem; color:#f0f7ff;}
.hm-tag {font-size:.73rem; padding:2px 9px; border-radius:999px; color:#fff; margin-left:6px;}
@media(max-width:720px){
 [data-testid="stMainBlockContainer"] {padding-left:.7rem;padding-right:.7rem;}
 [data-testid="stTabs"] button[role="tab"] {padding:8px 11px!important;font-size:.86rem!important;}
 .ar-title {font-size:1rem;}
}
</style>
""",
    unsafe_allow_html=True,
)


# ───────────────────────── القراءة الصوتية ─────────────────────────

TTS_MODES = ["العنوان + المقال كاملاً", "العنوان + ملخص قصير", "العنوان فقط"]
ORDINALS = ["الأول", "الثاني", "الثالث", "الرابع", "الخامس", "السادس", "السابع", "الثامن", "التاسع", "العاشر"]


@st.cache_data(ttl=86400, max_entries=30, show_spinner=False)
def tts_cached(text, voice, rate):
    return core.tts(text, voice, rate)


_fragment = getattr(st, "fragment", lambda f: f)  # الجزء ده بيتحدّث لوحده من غير ما يعيد تحميل باقي التابات


def pick(container, label, options, default, key, fmt=None):
    """بديل لشريط السحب: الشريط كان بيتحرك لوحده مع الطلوع والنزول على الموبايل فيعمل تحديث للصفحة. هنا اختيارات بتتداس بس"""
    options = list(options)
    if default not in options:
        try:
            default = min(options, key=lambda o: abs(o - default))
        except Exception:
            default = options[0]
    kw = {"format_func": fmt} if fmt else {}
    if len(options) <= 6:
        return container.radio(label, options, index=options.index(default), horizontal=True, key=key, **kw)
    return container.selectbox(label, options, index=options.index(default), key=key, **kw)


def untranslated(items):
    return [x for x in items if isinstance(x, dict) and (x.get("title") or "").strip()
            and not core._HAS_AR.search(x.get("title_ar") or "") and not core._HAS_AR.search(x.get("title") or "")]


def fix_untranslated(items, limit=40):
    """بيترجم العناوين اللي فضلت بلغتها (لما الترجمة كانت واقعة وقت البحث). بيرجع عدد اللي اتصلح"""
    bad = untranslated(items)[:limit]
    if not bad:
        return 0
    try:
        core.translate_titles(bad)
    except Exception:
        return 0
    return sum(1 for x in bad if core._HAS_AR.search(x.get("title_ar") or ""))


def tts_settings(prefix):
    c1, c2 = st.columns(2)
    label = c1.selectbox("الصوت", list(core.VOICES), key=f"{prefix}_voice")
    rate = pick(c2, "السرعة", range(-30, 45, 5), 0, f"{prefix}_rate", fmt=lambda v: f"{v:+d}%")
    return core.VOICES[label], rate


def audio_block(entry, wk, name="marsad_news"):
    data, _engine, note = entry
    if note:
        st.caption("ℹ️ " + note)
    st.audio(data, format="audio/mpeg")
    st.download_button(
        "⬇️ تنزيل MP3 (للاستماع بدون إنترنت داخل المترو)", data=data, file_name=f"{name}.mp3", mime="audio/mpeg", key=f"dl_{wk}"
    )
    st.caption("⏸ للإيقاف المؤقت أو الإيقاف استخدم زر المشغّل. الصوت يستمر والشاشة مغلقة.")


def speech_text(url, title_ar, mode):
    """يجهّز النص العربي المراد نطقه حسب الوضع. يعيد (النص، ملاحظة)"""
    if mode == TTS_MODES[2]:
        return title_ar, ""
    art = core.fetch_article(url)
    if not art:
        return title_ar, "تعذّر جلب نص المقال (اشتراك أو حجب) فقُرئ العنوان فقط."
    if mode == TTS_MODES[1]:
        summ = core.summarize(url, verdict=False)
        summ = re.sub(r"^ملخص مبسّط[^\n]*\n+", "", summ)
        return f"{title_ar}. {summ}", ""
    return f"{title_ar}. {core.translate_long(art['text'])}", ""


def make_audio(text, voice, rate):
    try:
        return tts_cached(text, voice, rate)
    except Exception as e:
        st.error(f"تعذّر توليد الصوت ({type(e).__name__}): {e}")
        return None


def listen_widget(a, wk):
    aud = st.session_state.setdefault("audio", {})
    url = a.get("url", "")
    if st.button("🎧 استمع", key=f"ls_{wk}"):
        ss = st.session_state
        voice = core.VOICES[ss.get("tts_voice", list(core.VOICES)[0])]
        with st.spinner("جارٍ تجهيز الصوت (جلب النص وترجمته ثم النطق)… قد يستغرق دقيقة للمقالات الطويلة."):
            text, note0 = speech_text(url, a.get("title_ar", ""), ss.get("tts_mode", TTS_MODES[0]))
            res = make_audio(text, voice, ss.get("tts_rate", 0))
            if res:
                if len(aud) >= 6:
                    aud.pop(next(iter(aud)))
                aud[url] = (res[0], res[1], (note0 + " " + res[2]).strip())
    if url in aud:
        audio_block(aud[url], wk)


# ───────────────────────── صفحة قراءة المقال ─────────────────────────


@st.cache_data(ttl=3600, show_spinner=False)
def alt_cached(title, domain):
    items, note = core.find_alternatives(title, domain)
    return core.translate_titles(items), note


def _alt_cards(items):
    for a in items:
        lnk = f"?view={quote(a['url'], safe='')}&seen={a.get('seendate', '')}&t={quote(a['title'][:200], safe='')}{auth_qs()}"
        st.markdown(
            f"<div class='card'><div class='ar-title'>{html.escape(a.get('title_ar', ''))}</div>"
            f"<div class='ltr' dir='ltr'>{html.escape(a['title'])}</div>"
            f"<div class='meta'>🌐 {src_label(a['domain'])} · 🕒 {fmt_seen(a.get('seendate', ''))} · نص كامل ({a['chars']} حرف)</div>"
            f"<a class='btn' href='{html.escape(lnk)}' target='_blank' rel='noopener'>ترجم المقال</a></div>",
            unsafe_allow_html=True,
        )


def alt_block(title, url):
    st.markdown("### 🔁 تغطية بديلة مجانية للموضوع نفسه")
    host = core._host(url)
    with st.spinner("جارٍ البحث عن مصادر مفتوحة تغطي الخبر نفسه…"):
        items, note = alt_cached(title, host)
    if items:
        st.caption(f"{note} هذه مقالات من مواقع أخرى عن الموضوع نفسه (قد تختلف في الزاوية والتفاصيل عن المقال المغلق).")
        _alt_cards(items)
    else:
        st.info(f"لم أجد بديلاً مفتوحاً بنص كامل. {note}")
    # بحث يدوي: العنوان المستخرج من الرابط قد لا يكفي، فاكتب أنت كلمات الخبر
    st.markdown("**🔎 ابحث بكلماتك أنت عن بدائل:**")
    q = st.text_input("كلمات الخبر (بالإنجليزية أو أي لغة)", value="" if len(title) < 12 else title, key="alt_q",
                      placeholder="مثال: Ethiopia Egypt dam talks")
    if st.button("🔎 ابحث عن بدائل", key="alt_go", type="primary"):
        if len(q.strip()) < 6:
            st.warning("اكتب كلمات أكثر قليلاً.")
        else:
            with st.spinner("جارٍ البحث…"):
                st.session_state["alt_manual"] = alt_cached(q.strip(), host)
    man = st.session_state.get("alt_manual")
    if man:
        m_items, m_note = man
        if m_items:
            st.caption(m_note)
            _alt_cards(m_items)
        else:
            st.warning(f"لا نتائج بنص كامل. {m_note}")
    if q.strip():
        from urllib.parse import quote_plus
        qq = quote_plus(q.strip())
        st.markdown(f"أو افتح البحث في موقع خارجي: [أخبار Google](https://news.google.com/search?q={qq}) · "
                    f"[Google](https://www.google.com/search?q={qq}) · [Bing أخبار](https://www.bing.com/news/search?q={qq})")


def translate_proxy_url(url, tl="ar"):
    """رابط نسخة مترجمة من الصفحة عبر ترجمة جوجل (translate.goog)"""
    from urllib.parse import urlsplit
    s = urlsplit(url)
    host = (s.hostname or "").replace("-", "--").replace(".", "-")
    q = (s.query + "&" if s.query else "") + f"_x_tr_sl=auto&_x_tr_tl={tl}&_x_tr_hl={tl}&_x_tr_pto=wapp"
    return f"https://{host}.translate.goog{s.path or '/'}?{q}"


def embed_browser(url):
    """فتح الصفحة الأصلية مترجمة: أزرار تاب جديد (الأضمن) + إطار داخلي اختياري"""
    import streamlit.components.v1 as components
    with st.expander("🌐 افتح الصفحة الأصلية مترجمة للعربية", expanded=True):
        c1, c2 = st.columns(2)
        c1.link_button("🌐 مترجمة (ترجمة جوجل) ↗️", translate_proxy_url(url), use_container_width=True, type="primary")
        c2.link_button("📄 الأصلية ↗️", url, use_container_width=True)
        st.caption("لو الأصلية فتحت عندك، اضغط بيمين الماوس ← «ترجمة إلى العربية» (متصفح كروم بيترجم أي لغة). "
                   "الزرارين بيفتحوا في تاب جديد وده أضمن من الإطار.")
        if st.checkbox("جرّب عرضها داخل هذه الصفحة (قد لا يعمل مع بعض المواقع)", key="emb_on"):
            mode = st.radio("العرض", ["مترجمة للعربية", "الأصلية بلغتها"], horizontal=True, key="emb_mode")
            src = translate_proxy_url(url) if mode.startswith("مترجمة") else url
            components.html(
                f"<iframe src='{html.escape(src, quote=True)}' style='width:100%;height:690px;border:1px solid #334155;border-radius:8px;background:#fff' "
                "referrerpolicy='no-referrer'></iframe>", height=700, scrolling=False)
            st.caption("لو ظهرت علامة وش حزين، يبقى الموقع مانع العرض داخل صفحات تانية. استخدم الزرارين اللي فوق.")


_SCRIPT_RULES = (
    "القواعد: اكتب بالعامية المصرية البسيطة كأني بحكي لواحد صاحبي، بجمل قصيرة تتقال بصوت عالي من غير تعقيد. "
    "ماتختلقش أي معلومة أو رقم مش موجود في المقالات المرفقة، وكل ما فيه شك قول «حسب ما نشر...» واذكر اسم المصدر والدولة. "
    "فرّق بين اللي المصدر قاله وبين تحليلي أنا. لو في تضارب بين مصدرين وضّحه. ركّز على علاقة الموضوع بمصر. "
    "في الآخر ضيف سطر قصير: «ده تحليل مبني على مصادر مفتوحة ومش تأكيد رسمي».\n\n"
)

SCRIPT_KINDS = {
    "بدون تعليمات (النص بس)": "",
    "تحليل وربط عام": (
        "المطلوب: اقرأ المقال التالي (مترجم للعربية) كمادة تحليل. لخّص أهم ما فيه في 5 نقاط، واستخرج الأطراف والأرقام والتواريخ، "
        "ثم اذكر ما يخص مصر. وإذا أرسلتُ لك مقالات أخرى بعده فاربط بينها: ما الخيط المشترك؟ أين التناقض؟ وما الاستنتاج السياسي المحتمل؟ "
        "ميّز بين ما ورد في النص وما هو استنتاجك.\n\n"
    ),
    "🎬 ريلز فيسبوك (60–90 ثانية)": (
        "المطلوب: اكتب سكريبت ريلز فيسبوك من 150 إلى 220 كلمة (60–90 ثانية) مبني على المقال/المقالات التالية. الهيكل: "
        "(1) خطّاف أول 3 ثواني: سؤال أو معلومة صادمة. (2) الخبر في 3 أو 4 جمل. (3) ليه ده مهم لمصر. (4) جملة ختام + سؤال للمتابعين في التعليقات. "
        "اكتب بجانب كل جزء اقتراح لنص يظهر على الشاشة (3–6 كلمات).\n" + _SCRIPT_RULES
    ),
    "▶️ فيديو يوتيوب (5 دقايق)": (
        "المطلوب: اكتب سكريبت فيديو يوتيوب مدته 5 دقايق (حوالي 700 كلمة) مبني على المقال/المقالات التالية. الهيكل: "
        "(1) خطّاف 10 ثواني. (2) مقدمة قصيرة: إيه اللي حصل؟ (3) الخلفية في فقرة. (4) التحليل: أهم 3 نقاط، لكل واحدة عنوان فرعي. "
        "(5) إيه علاقة ده بمصر؟ (6) الخلاصة + سؤال للتعليقات. حدّد تقريباً الوقت لكل جزء، واقترح لقطات أو صور تظهر مع كل جزء.\n" + _SCRIPT_RULES
    ),
    "▶️ فيديو يوتيوب (9 دقايق)": (
        "المطلوب: اكتب سكريبت فيديو يوتيوب مدته حوالي 9 دقايق (1200 إلى 1300 كلمة) مبني على المقال/المقالات التالية. الهيكل: "
        "(1) خطّاف 10–15 ثانية. (2) مقدمة: إيه اللي حصل. (3) الخلفية التاريخية أو السياق. (4) عرض كل مصدر وروايته على حدة. "
        "(5) الربط: ما الخيط المشترك بين المصادر؟ وأين التناقض؟ (6) السيناريوهات المحتملة (2 أو 3) بدون جزم. (7) إيه معنى ده بالنسبة لمصر. "
        "(8) خلاصة + سؤال للتعليقات. حدّد تقريباً الوقت لكل جزء، واقترح لقطات وخرائط أو صور مناسبة.\n" + _SCRIPT_RULES
    ),
}


def copy_block(url, title, title_ar, art, body_ar):
    """نص جاهز للنسخ (نوت / ذكاء اصطناعي): العنوان والمصدر والتاريخ والرابط ثم النص المترجم"""
    dom = core._host(url)
    with st.expander("📋 انسخ المقال المترجم (للنوت أو لأي ذكاء اصطناعي)", expanded=False):
        kind = st.selectbox("أضف في أول النص تعليمات جاهزة للذكاء الاصطناعي", list(SCRIPT_KINDS), key="cp_kind")
        st.caption("لو هتبعت أكتر من مقال: اختار التعليمات مع **أول** مقال بس، ولمّا تخلّص المقالات كلها اكتب: «دلوقتي اكتب السكريبت».")
        with_orig = st.checkbox("أضف النص الأصلي بعد الترجمة", value=False, key="cp_orig")
        head = (f"العنوان: {title_ar}\nالعنوان الأصلي: {title}\nالمصدر: {source_name(dom)} ({dom}) · {source_country(dom)}\n"
                f"التاريخ: {art.get('date') or 'غير معروف'}\nالرابط: {url}\n\n")
        txt = SCRIPT_KINDS[kind] + head + body_ar.strip()
        if with_orig:
            txt += "\n\n----- النص الأصلي -----\n" + art["text"].strip()
        st.caption("اضغط أيقونة النسخ 📋 في الركن العلوي من الصندوق (بتظهر لما تقف عليه أو تلمسه)، وبعدين الصق في أي مكان. "
                   "كرر نفس الشيء مع كل مقال ولصقهم ورا بعض عشان يحصل الربط بينهم.")
        try:
            st.code(txt, language=None, wrap_lines=True)
        except TypeError:
            st.code(txt, language=None)
        st.download_button("⬇️ نزّله كملف نصي (.txt)", txt, file_name="article.txt", mime="text/plain", use_container_width=True, key="cp_dl")


def reader_head(title_en, url, wr, outlet, title_ar=""):
    """رأس صفحة المقال: العنوان بالعربي والأصلي + الجريدة + الكاتب + الموقع"""
    if title_en:
        title_ar = title_ar or tr(title_en, "auto", "ar")
        st.markdown(f"### {title_ar}")
        st.markdown(f"<div class='ltr' dir='ltr'>{html.escape(title_en)}</div>", unsafe_allow_html=True)
    bits = []
    if outlet:
        bits.append(f"📰 **الجريدة:** {html.escape(outlet)}")
    if wr:
        bits.append(f"✍️ **الكاتب:** {html.escape(wr)}")
    host = core._host(url)
    if host and host != "news.google.com":
        bits.append(f"🌐 **الموقع:** {src_label(host)}")
    if bits:
        st.markdown("  \n".join(bits), unsafe_allow_html=True)


def search_suggestions(title):
    """اقتراحات بحث بالعنوان في مصادر تانية (روابط تفتح في تاب جديد)"""
    q = re.sub(r"\s+[-|–]\s+[^-|–]{2,40}$", "", (title or "").strip())[:140]
    if len(q) < 6:
        return
    from urllib.parse import quote_plus
    qq = quote_plus(q)
    st.markdown("### 🔎 اقتراحات بحث بالعنوان في مصادر تانية")
    sites = [("Google", f"https://www.google.com/search?q={qq}"), ("أخبار Google", f"https://news.google.com/search?q={qq}"),
             ("Bing أخبار", f"https://www.bing.com/news/search?q={qq}"),
             ("AP", f"https://www.google.com/search?q={qq}+site:apnews.com"), ("Reuters", f"https://www.google.com/search?q={qq}+site:reuters.com"),
             ("BBC", f"https://www.google.com/search?q={qq}+site:bbc.com"), ("الجزيرة", f"https://www.google.com/search?q={qq}+site:aljazeera.net"),
             ("Times of Israel", f"https://www.google.com/search?q={qq}+site:timesofisrael.com"),
             ("Axios", f"https://www.google.com/search?q={qq}+site:axios.com"), ("Al-Monitor", f"https://www.google.com/search?q={qq}+site:al-monitor.com"),
             ("Middle East Eye", f"https://www.google.com/search?q={qq}+site:middleeasteye.net"), ("X (تويتر)", f"https://x.com/search?q={qq}&f=live")]
    st.markdown(" · ".join(f"[{n}]({u})" for n, u in sites))
    st.caption("كل رابط بيفتح تاب جديد ببحث بعنوان المقال، علشان تلاقي نفس الخبر عند ناس تانية.")


def reader_scroll_tool():
    """ازرار عائمة للتحكم الدقيق في التمرير اثناء قراءة المقال (الشريط الجانبي وعجلة الماوس بيقفزوا جمل كاملة)"""
    import streamlit.components.v1 as components
    components.html("""
<script>
(function(){
  try{
    var P=window.parent, D=P.document;
    var old=D.getElementById('rd-scroll-tool'); if(old) old.remove();
    var box=D.createElement('div'); box.id='rd-scroll-tool';
    box.style.cssText='position:fixed;left:10px;bottom:90px;z-index:99999;display:flex;flex-direction:column;gap:6px;direction:ltr;font-family:sans-serif';
    function btn(t,title){var b=D.createElement('button');b.textContent=t;b.title=title;
      b.style.cssText='width:56px;height:56px;border-radius:14px;border:2px solid rgba(255,255,255,.6);background:rgba(30,30,40,.92);color:#fff;font-size:26px;cursor:pointer;touch-action:manipulation;user-select:none;-webkit-user-select:none';
      return b;}
    function area(){return D.querySelector('[data-testid="stMain"]')||D.querySelector('section.main')||D.scrollingElement||D.documentElement;}
    var speed=14, timer=null, auto=false, autoTimer=null, autoSpeed=1;
    function step(dy){var el=area(); el.scrollBy({top:dy,behavior:'auto'});}
    function holdStart(dir){step(dir*speed); stopHold(); timer=setInterval(function(){step(dir*speed);},40);}
    function stopHold(){if(timer){clearInterval(timer);timer=null;}}
    function bindHold(b,dir){
      ['mousedown','touchstart'].forEach(function(e){b.addEventListener(e,function(ev){ev.preventDefault();holdStart(dir);},{passive:false});});
      ['mouseup','mouseleave','touchend','touchcancel'].forEach(function(e){b.addEventListener(e,stopHold);});
    }
    var up=btn('▲','لفوق (اضغط واستمر)'), down=btn('▼','لتحت (اضغط واستمر)');
    var play=btn('▶','تمرير تلقائي بطيء'), plus=btn('+','أسرع'), minus=btn('−','أبطأ');
    bindHold(up,-1); bindHold(down,1);
    function setAuto(on){
      auto=on; play.textContent=on?'⏸':'▶';
      if(autoTimer){clearInterval(autoTimer);autoTimer=null;}
      if(on){autoTimer=setInterval(function(){step(autoSpeed);},40);}
    }
    play.onclick=function(){setAuto(!auto);};
    plus.onclick=function(){autoSpeed=Math.min(8,autoSpeed+0.5);speed=Math.min(40,speed+4);};
    minus.onclick=function(){autoSpeed=Math.max(0.5,autoSpeed-0.5);speed=Math.max(4,speed-4);};
    [up,play,plus,minus,down].forEach(function(b){box.appendChild(b);});
    D.body.appendChild(box);
  }catch(e){}
})();
</script>""", height=0)


def reader_page():
    url = unquote(st.query_params.get("view", ""))
    seen = st.query_params.get("seen", "")
    orig_title = unquote(st.query_params.get("t", ""))
    wr = unquote(st.query_params.get("wr", ""))
    outlet = unquote(st.query_params.get("o", ""))

    st.markdown("## 📖 قراءة المقال مترجماً")
    reader_scroll_tool()
    if not url.startswith(("http://", "https://")):
        st.error("رابط غير صالح.")
        return
    gnews_link = core._host(url) == "news.google.com"
    if gnews_link:  # رابط أخبار جوجل: نحاول نوصل للرابط الاصلي للجريدة
        with st.spinner("جارٍ الوصول للرابط الاصلي للمقال…"):
            real = core.decode_gnews(url)
        if core._host(real) != "news.google.com":
            url, gnews_link = real, False
    st.markdown(f"🔗 **الرابط الأصلي:** [{html.escape(url)}]({url})")
    reader_head(orig_title, url, wr, outlet)

    embed_browser(url)

    with st.spinner("جارٍ جلب المقال وترجمته…"):
        art = None if gnews_link else core.fetch_article(url)
        if not art:
            if gnews_link:
                st.warning("رابط أخبار جوجل ما اتفكش (جوجل بيمنع فكّه من التطبيق). العنوان اللي فوق هو العنوان الحقيقي للمقال. "
                           "افتح «الأصلية» من فوق في متصفحك، او استخدم الاقتراحات تحت.")
            else:
                st.warning("تعذّر استخراج نص المقال: " + core.FETCH_WHY.get(url, "جدار اشتراك أو حجب") +
                           ". (الصفحة قد تفتح في متصفحك عادي لكن الموقع يعامل التطبيق كزائر آلي.)")
            search_suggestions(orig_title or core.title_from_url(url))
            alt_block(orig_title or core.title_from_url(url), url)
            return
        title = art["title"] if art["title"] and art["title"].lower() not in ("google news", "أخبار جوجل") else orig_title
        title = title or orig_title
        title_ar = tr(title, "auto", "ar")
        body_ar = art["text"] if art.get("pre_ar") else core.translate_long(art["text"])
        body_ok = core.translated_ok(art["text"], body_ar)

    if not body_ok:
        st.warning("⚠️ الترجمة التلقائية للنص لم تكتمل الآن (غالباً جوجل مشغول). اضغط «أعد الترجمة» بعد لحظات، "
                   "أو استخدم زرار «مترجمة (ترجمة جوجل)» فوق في التاب.")
        if st.button("🔁 أعد الترجمة", key="rd_retry"):
            st.rerun()
    trunc_alt = False
    tail = art["text"][-300:].lower()
    if len(art["text"]) < 1800 or re.search(r"loading\.\.\.|subscribe|log in to|טוען|למנויים|הרשמה", tail):
        st.warning(
            f"⚠️ النص الذي وصل التطبيق قصير ({len(art['text'])} حرفاً) ويبدو أنه المقدّمة المتاحة للزوار فقط؛ "
            "الموقع يخفي بقية المقال خلف اشتراك أو تحميل بالجافاسكربت، ولا يمكن للتطبيق تجاوز ذلك. "
            "لقراءته كاملاً: افتح الرابط الأصلي بحسابك المشترك، أو اقرأ التغطية البديلة المفتوحة أسفل الصفحة."
        )
        trunc_alt = True
    via = art.get("via") or "غير معروفة (نسخة محفوظة من قبل)"
    if via.startswith("الفتح المباشر"):
        st.success(f"🟢 طريقة جلب المقال: {via}")
    else:
        st.info(f"🟡 طريقة جلب المقال: {via} — لأن الموقع رفض فتحه مباشرة. (النص قد يختلف شكله قليلاً عن الأصل.)")
    if core._host(url) and core._host(url) != "news.google.com":
        st.markdown(f"📰 **الجريدة والبلد:** {src_label(core._host(url), with_domain=False)}", unsafe_allow_html=True)
    if art.get("authors") and not wr:
        st.markdown("✍️ **الكاتب (من توقيع المقال):** " + html.escape("، ".join(art["authors"])))
    elif not wr and not art.get("authors"):
        st.caption("✍️ اسم الكاتب مش ظاهر في بيانات الصفحة اللي وصلت للتطبيق. شوفه في الصفحة الاصلية.")
    if art["date"]:
        st.markdown(f"🕒 **تاريخ النشر (حسب بيانات المصدر):** {art['date']}")
    if seen:
        st.markdown(f"🛰️ **وقت رصد المقال (توقيت القاهرة):** {fmt_seen(seen)}")

    if not orig_title or title.strip().lower() != orig_title.strip().lower():  # العنوان ظهر فوق؛ نكرره فقط لو الصفحة لها عنوان مختلف
        st.markdown(f"### {title_ar}")
        st.markdown(f"<div class='ltr' dir='ltr'>{html.escape(title)}</div>", unsafe_allow_html=True)

    if st.button("📝 ملخص المقال في نقاط"):
        with st.spinner("جارٍ التلخيص…"):
            st.info(core.summarize(url))

    copy_block(url, title, title_ar, art, body_ar)

    with st.expander("🎧 استمع للمقال بصوت مسموع", expanded=False):
        voice, rate = tts_settings("rd")
        part = st.radio("ما الذي يُقرأ؟", ["المقال كاملاً", "أول فقرات فقط (حوالي دقيقتين)"], horizontal=True, key="rd_part")
        rd_aud = st.session_state.setdefault("rd_audio", {})
        if st.button("🔊 ولّد الصوت", key="rd_go", use_container_width=True):
            txt = f"{title_ar}. {body_ar}"
            if part != "المقال كاملاً":
                txt = txt[:1800].rsplit(".", 1)[0] + "."
            with st.spinner("جارٍ تجهيز الصوت…"):
                res = make_audio(txt, voice, rate)
            if res:
                rd_aud.clear()
                rd_aud[url] = res
        if url in rd_aud:
            audio_block(rd_aud[url], "rd")

    st.divider()
    paras = "".join(
        f"<p>{html.escape(p)}</p>" for p in body_ar.split("\n") if p.strip() and p.strip().strip(".…") not in ("تحميل", "جار التحميل", "جارٍ التحميل")
    )
    st.markdown(f"<div class='article-body'>{paras}</div>", unsafe_allow_html=True)
    with st.expander("النص الأصلي"):
        st.text(art["text"])
    search_suggestions(title)
    if trunc_alt:
        st.divider()
        alt_block(title, url)



import base64 as _b64

_LOGO_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 520 140" width="520" height="140" role="img" aria-label="Ehab Ibrahim"> <defs> <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0f2a47"/><stop offset="1" stop-color="#0a1626"/></linearGradient> <linearGradient id="sw" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#22d3ee" stop-opacity="0"/><stop offset="1" stop-color="#22d3ee" stop-opacity=".75"/></linearGradient> </defs> <rect x="6" y="6" width="128" height="128" rx="28" fill="url(#bg)"/> <g transform="translate(70 70)" fill="none" stroke="#22d3ee" stroke-width="2.2" opacity=".9"> <circle r="46"/><circle r="31"/><circle r="16"/> <path d="M-46 0H46M0 -46V46" stroke-opacity=".35"/> </g> <path d="M70 70 L70 24 A46 46 0 0 1 110 47 Z" fill="url(#sw)"/> <line x1="70" y1="70" x2="110" y2="47" stroke="#67e8f9" stroke-width="2.5" stroke-linecap="round"/> <circle cx="94" cy="52" r="4.5" fill="#fbbf24"/><circle cx="52" cy="88" r="3.2" fill="#f87171"/> <text x="156" y="68" font-family="Georgia, \'Times New Roman\', serif" font-size="46" font-weight="700" fill="#e2e8f0">Ehab Ibrahim</text> <rect x="158" y="80" width="64" height="4" rx="2" fill="#22d3ee"/> <text x="158" y="112" font-family="Tahoma, Arial, sans-serif" font-size="21" fill="#94a3b8" letter-spacing=".5">رادار الأخبار العالمية</text> </svg> '


def show_logo(width=300):
    """شعار المالك (Ehab Ibrahim) فوق في التاب"""
    b = _b64.b64encode(_LOGO_SVG.encode("utf-8")).decode()
    st.markdown(f"<div style='direction:ltr;text-align:left;margin:0 0 6px'><img alt='Ehab Ibrahim' width='{width}' src='data:image/svg+xml;base64,{b}'></div>",
                unsafe_allow_html=True)


def show_footer():
    st.divider()
    st.markdown("<div style='text-align:center;color:#94a3b8;font-size:.85rem'>© Ehab Ibrahim — رادار الأخبار العالمية · جميع الحقوق محفوظة</div>",
                unsafe_allow_html=True)


# ───────────────────────── بوابة الشفرات (اختيارية: تعمل فقط إن وُجد ADMIN_KEY في Secrets) ─────────────────────────

def _sec(name):
    try:
        v = st.secrets.get(name)
    except Exception:
        v = None
    return v or os.getenv(name)


ADMIN_KEY, _GT, _GG = _sec("ADMIN_KEY"), _sec("GITHUB_TOKEN"), _sec("GIST_ID")
GATE_ON = bool(ADMIN_KEY and _GT and _GG)


def _adm_tok():
    """رمز جلسة المالك المشتق من ADMIN_KEY (لا يكشف المفتاح نفسه): يوضع في الرابط فيُعاد الدخول تلقائياً بعد انقطاع الجلسة"""
    import hashlib
    return hashlib.sha256(("marsad-session|" + (ADMIN_KEY or "")).encode("utf-8")).hexdigest()[:40]


def auth_qs():
    """يُلحق الشفرة بروابط صفحة القراءة (تُفتح في تبويب جديد = جلسة جديدة)"""
    a = st.session_state.get("auth") or {}
    return f"&k={quote(a['token'], safe='')}" if a.get("token") else ""


def _try_code(code):
    """يحاول الدخول بالشفرة؛ يعيد رسالة الخطأ أو '' عند النجاح"""
    code = (code or "").strip()
    if not code:
        return ""
    if hmac.compare_digest(code, ADMIN_KEY) or hmac.compare_digest(code, _adm_tok()):
        st.session_state["auth"] = {"role": "admin", "token": _adm_tok()}
        return ""
    try:
        k, why = keys_mod.touch(_GT, _GG, code)
    except Exception as e:
        return f"تعذّر التحقق الآن ({type(e).__name__}). أعد المحاولة بعد لحظات."
    if not k:
        return why
    st.session_state["auth"] = {"role": "guest", "token": keys_mod.norm(code), "label": k.get("label", ""),
                                "exp": keys_mod.iso(keys_mod.expires_at(k)), "checked": time.time(),
                                "scope": k.get("scope", "full")}
    return ""


def gate():
    ss = st.session_state
    if not GATE_ON:
        ss["auth"] = {"role": "admin", "token": ""}
        return
    a = ss.get("auth")
    msg = ""
    if a and a["role"] == "guest":
        exp = keys_mod.parse(a.get("exp"))
        if exp and keys_mod.now() > exp:
            ss.pop("auth")
            a, msg = None, "انتهت مدة التجربة."
        elif time.time() - a["checked"] > keys_mod.RECHECK_SECONDS:
            try:
                ok = keys_mod.recheck(_GT, _GG, a["token"])
            except Exception:
                ok = True  # تعذّر الفحص مؤقتاً: لا نطرد الضيف
            a["checked"] = time.time()
            if not ok:
                ss.pop("auth")
                a, msg = None, "أُلغيت هذه الشفرة أو انتهت مدتها."
    if a:
        # ثبّت الرمز في رابط الصفحة: لو انقطعت الجلسة (قفل شاشة الموبايل مثلاً) يُعاد الدخول تلقائياً بدل طلب الشفرة
        if a.get("token") and st.query_params.get("k", "") != a["token"]:
            st.query_params["k"] = a["token"]
        return
    code = st.query_params.get("k", "")
    if code and not ss.get("k_tried") == code:
        ss["k_tried"] = code
        msg = _try_code(code) or msg
        if ss.get("auth"):
            if ss["auth"].get("token"):
                st.query_params["k"] = ss["auth"]["token"]
            return
    show_logo()
    st.title("🔒 رادار الأخبار العالمية")
    st.markdown("هذه النسخة بالدعوة فقط. اكتب الشفرة التي وصلتك مع الرابط.")
    if msg:
        st.error(msg)
    entered = st.text_input("الشفرة", key="gate_code", type="password", placeholder="MR-XXXX-XXXX")
    if st.button("دخول", type="primary"):
        err = _try_code(entered)
        if err:
            st.error(err)
        else:
            st.rerun()
    st.stop()


gate()
IS_ADMIN = st.session_state["auth"]["role"] == "admin"

if "view" in st.query_params:
    reader_page()
    st.stop()

# ───────────────────────── التخزين: المحفوظات + المصادر المضافة ─────────────────────────

DOMAIN_RE = re.compile(r"^[a-z0-9][a-z0-9\-\.]*\.[a-z]{2,}$")
# فواصل العبارات: , ، ; سطر جديد، وكذلك النقطة بعد حرف عربي (مثل: مصر. الجيش المصري.) دون المساس بالاختصارات الإنجليزية
TERM_SPLIT = re.compile(r"[,،;\n]+|(?<=[\u0600-\u06FF])\.+(?=\s|$)")



def _secret(name):
    try:
        v = st.secrets.get(name)
    except Exception:
        v = None
    return v or os.getenv(name)


GH_TOKEN, GH_GIST = _secret("GITHUB_TOKEN"), _secret("GIST_ID")
PERSIST = bool(GH_TOKEN and GH_GIST) and IS_ADMIN  # الضيف لا يرى بيانات المالك ولا يكتب فيها

if "store" not in st.session_state:
    _data, _err = store.empty(), None
    if PERSIST:
        try:
            _data = store.load(GH_TOKEN, GH_GIST)
        except Exception as _e:
            _err = f"تعذّر تحميل التخزين الدائم ({type(_e).__name__})"
    st.session_state["store"] = _data
    st.session_state["store_err"] = _err


def S():
    return st.session_state["store"]


def persist():
    if not PERSIST:
        return
    try:
        fresh = store.load(GH_TOKEN, GH_GIST)  # حتى لا نمحو شفرات أُنشئت أو دخولات سُجّلت من جلسة أخرى
        S()["keys"] = fresh["keys"]
        store.save(GH_TOKEN, GH_GIST, S())
        st.session_state["store_err"] = None
    except Exception as e:
        st.session_state["store_err"] = f"تعذّر الحفظ الدائم ({type(e).__name__})"


for _s in S()["sources"]:
    DOMAIN_LABELS[_s["domain"]] = _s["label"]

SAVE_KEYS = [
    "url", "title", "title_ar", "title_en", "seendate", "domain", "sourcecountry", "country_ar", "language",
    "ctype", "ctype_sure", "writer", "outlet", "wsrc", "snips", "snip_ar", "found", "fetched", "checked",
]


def flash(msg):
    st.session_state["flash"] = msg


def clean_domain(x):
    return (x or "").strip().lower().replace("https://", "").replace("http://", "").replace("www.", "").strip("/").split("/")[0]


def save_item(a, tab=""):
    s = S()
    if any(x.get("url") == a.get("url") for x in s["saved"]):
        return
    it = {k: a[k] for k in SAVE_KEYS if k in a}
    it["saved_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    it["note"], it["tab"] = "", tab
    s["saved"].insert(0, it)
    persist()


def delete_item(url):
    S()["saved"] = [x for x in S()["saved"] if x.get("url") != url]
    persist()


def set_note(url, wkey):
    for x in S()["saved"]:
        if x.get("url") == url:
            x["note"] = st.session_state.get(wkey, "")
    persist()


def add_source():
    ss = st.session_state
    dom = clean_domain(ss.get("ms_domain", ""))
    if not DOMAIN_RE.match(dom):
        return flash("⚠️ الدومين غير صالح (مثال: example.com).")
    name = (ss.get("ms_name", "") or "").strip() or dom
    gname = ss.get("ms_group", "أمريكية")
    group = {"إسرائيلية": "il", "أمريكية": "us", "بريطانية": "uk", "تركيا/إيران/إثيوبيا": "rg"}[gname]
    lang = {"عبري": "he", "إنجليزي": "en", "كلاهما": "both", "تركي": "tr", "فارسي": "fa", "أمهري": "am", "عربي": "ar"}[ss.get("ms_lang", "إنجليزي")]
    if any(x["domain"] == dom and x["group"] == group for x in S()["sources"]):
        return flash("هذا المصدر مضاف مسبقاً.")
    S()["sources"].append({"label": name, "domain": dom, "lang": lang, "group": group})
    DOMAIN_LABELS[dom] = name
    persist()
    flash(f"✅ أُضيف «{name}» إلى مصادر التاب ({gname}) — يظهر هناك ضمن «مصادر أضفتَها».")


def add_writer():
    ss = st.session_state
    en = (ss.get("mw_en", "") or "").strip()
    ar = (ss.get("mw_ar", "") or "").strip()
    tw = core.twitter_handle(ss.get("mw_tw", ""))
    sites = [d for d in (clean_domain(x) for x in re.split(r"[,\s]+", ss.get("mw_sites", ""))) if DOMAIN_RE.match(d) and d not in ("x.com", "twitter.com")]
    country = {"أمريكي": "US", "بريطاني": "UK", "إسرائيلي": "IL", "سعودي": "SA", "خليجي": "GCC", "مصري": "EG", "عربي آخر": "AR"}[ss.get("mw_country", "أمريكي")]
    msg = lambda m: ss.__setitem__("mw_msg", m)
    if not (en or ar):
        return msg("⚠️ اكتب اسم الكاتب (بالعربي او بالانجليزي).")
    if country in ("US", "UK", "IL") and not sites:
        return msg("⚠️ الكاتب الاجنبي محتاج دومين موقع نشر واحد على الاقل (مثل nytimes.com).")
    if country not in ("US", "UK", "IL") and not (tw or sites):
        return msg("⚠️ للكاتب العربي لازم تكتب حساب تويتر (مثل @alfihrest) او موقع نشر.")
    if ss.get("mw_tw", "").strip() and not tw:
        return msg("⚠️ حساب تويتر مش مفهوم. اكتبه زي @name او الصق رابط الحساب.")
    ar = ar or (tr(en, "en", "ar") if en else "")
    en = en or ar
    heb = (ss.get("mw_heb", "") or "").strip()
    wid = "c_" + hashlib.md5((en + tw + ",".join(sites)).encode()).hexdigest()[:8]
    if any(w["id"] == wid for w in S()["writers"]):
        return msg("الكاتب ده مضاف قبل كده.")
    S()["writers"].append(
        {"id": wid, "name_ar": ar, "name_en": en, "outlet": (ss.get("mw_outlet", "") or "").strip() or (f"تويتر @{tw}" if tw else sites[0]),
         "country": country, "kind": ss.get("mw_kind", "رأي"), "sites": sites, "aliases": [],
         "heb": [heb, sites] if heb and sites else None, "twitter": tw}
    )
    persist()
    msg(f"✅ اتضاف الكاتب «{ar}»" + (f" (تويتر @{tw})" if tw else "") + " — هتلاقيه في تاب «كتّاب ومحللون» تحت قسم "
        + GROUP_LABELS.get(country, "") + ". وتقدر تلاقيه تحت في «ما أضفتَه».")


def remove_source(dom, group):
    S()["sources"] = [x for x in S()["sources"] if not (x["domain"] == dom and x["group"] == group)]
    persist()


def remove_writer(wid):
    S()["writers"] = [x for x in S()["writers"] if x["id"] != wid]
    persist()


def fill_author(idx):
    ss = st.session_state
    a = (ss.get("analysis") or {}).get("authors", [])[idx]
    ss["mw_en"] = a.get("en") or a["raw"]
    ss["mw_ar"] = a.get("ar", "")
    ss["mw_heb"] = a["raw"] if a.get("heb") else ""


def pick_author():
    names = [a["raw"] for a in (st.session_state.get("analysis") or {}).get("authors", [])]
    if st.session_state.get("mw_pick") in names:
        fill_author(names.index(st.session_state["mw_pick"]))


def do_analyze():
    ss = st.session_state
    url = (ss.get("ms_url", "") or "").strip()
    if not url:
        return
    try:
        res = core.analyze_url(url)
    except Exception as e:
        res = {"error": f"تعذّر التحليل ({type(e).__name__})", "authors": []}
    ss["analysis"] = res
    if res.get("domain"):
        ss["ms_domain"] = res["domain"]
        ss["ms_name"] = res.get("site_name") or res["domain"]
        g = res.get("group", "us")
        ss["ms_group"] = {"il": "إسرائيلية", "uk": "بريطانية", "us": "أمريكية"}[g]
        ss["ms_lang"] = "عبري" if res.get("lang") == "he" else "إنجليزي"
        ss["mw_sites"], ss["mw_outlet"] = res["domain"], ss["ms_name"]
        ss["mw_country"] = {"il": "إسرائيلي", "uk": "بريطاني", "us": "أمريكي"}[g]
    if (res.get("tweet") or {}).get("handle"):
        ss["mw_tw"] = res["tweet"]["handle"]
    if res.get("authors"):
        ss["mw_pick"] = res["authors"][0]["raw"]
        fill_author(0)


# ───────────────────────── الواجهة الرئيسية ─────────────────────────

show_logo()
st.title("🛰️ مرصد الأخبار")
st.caption("منصة رصد وتحليل الأخبار والمعلومات من مصادر متعددة")
if not IS_ADMIN:
    _a = st.session_state["auth"]
    st.info(f"🎟️ نسخة تجريبية لـ «{_a.get('label', '')}» — "
            f"تنتهي {keys_mod.parse(_a['exp']).astimezone(core.TZ).strftime('%Y-%m-%d %H:%M')} بتوقيت القاهرة. "
            "لا يُحفظ شيء بعد إغلاق الصفحة.")


def render_about():
    """قسم «ما هذا التطبيق؟»: يُبنى من بيانات التطبيق نفسها فيتحدّث تلقائياً"""
    n_src = len({d for g in (ISRAEL, USA, UK, REGION, ARABIC, EGYPT) for ents in g.values() for _, d, _ in ents})
    stats = {"n_sources": n_src, "langs": [core.LANG_NAME_AR.get(c, c) for c, _, _, _ in core.LANGS],
             "n_writers": len(WRITERS), "n_files": len(intel.FILES), "file_names": list(intel.FILES), "threads": list(links_mod.THREADS)}
    with st.expander(about_plain("ما هذا التطبيق؟ وايه اللي بيعمله؟")):
        for title, body in about_sections(stats):
            st.markdown(f"**{about_plain(title)}**")
            if body is None:  # قائمة التابات من TAB_HELP
                st.markdown("\n".join(f"- **{about_plain(n)}:** {about_plain(TAB_HELP[n])}" for n in TAB_NAMES))
            else:
                st.markdown(about_plain(body))


def render_run_report():
    """زر المالك: تشغيل التقرير اليومي الآن من التطبيق (يستدعي GitHub Actions)"""
    tok, repo, branch = _sec("ACTIONS_TOKEN"), _sec("GH_REPO") or gh_actions.DEFAULT_REPO, _sec("GH_BRANCH") or "main"
    with st.expander("🔄 تحديث التقرير الآن (للمالك فقط)"):
        if not tok:
            st.info("لتفعيل الزر أضف في Secrets قيمة **ACTIONS_TOKEN**. أنشئ توكن من GitHub ← الصورة الشخصية ← Settings ← Developer settings ← "
                    "Personal access tokens ← Tokens (classic) ← Generate new token، وفعّل صلاحيتين: **repo** و**workflow**، ثم الصق قيمته. "
                    f"(المستودع الحالي: {repo})")
            return
        try:
            lr = gh_actions.last_run(tok, repo)
        except Exception as e:
            st.error(f"تعذّر قراءة حالة التشغيل ({type(e).__name__}). غالباً التوكن ناقص الصلاحية.")
            lr = None
        busy = bool(lr and lr["status"] in ("queued", "in_progress", "waiting", "requested"))
        if lr:
            ico = {"success": "✅ نجح", "failure": "❌ فشل", "cancelled": "⚪ أُلغي"}.get(lr["conclusion"] or "", "⏳ يعمل الآن" if busy else "—")
            when = keys_mod.parse(lr["created"])
            when_txt = when.astimezone(core.TZ).strftime("%Y-%m-%d %H:%M") if when else ""
            st.markdown(f"آخر تشغيل: **{ico}** — بدأ {when_txt} (القاهرة) · [تفاصيله على GitHub]({lr['url']})")
        c1, c2 = st.columns(2)
        if c1.button("▶️ شغّل التقرير الآن", type="primary", disabled=busy, key="run_rep", use_container_width=True):
            ok, msg = gh_actions.dispatch(tok, repo, branch)
            (st.success if ok else st.error)(msg)
        if c2.button("🔁 حدّث الحالة", key="run_status", use_container_width=True):
            st.rerun()
        if busy:
            st.caption("هناك تشغيل جارٍ، لذلك الزر معطّل حتى ينتهي. اضغط «حدّث الحالة» بين فترة وأخرى، ثم أعد تحميل الصفحة ليظهر التقرير الجديد.")


def render_daily():
    st.caption("نشرة تُولَّد تلقائياً كل صباح (نحو 6 بتوقيت القاهرة) لكل ملف، من عناوين عشرات المصادر العالمية والعربية، "
               "مع ما يخص مصر. ترتيب وتجميع للعناوين نفسها (بلا ذكاء اصطناعي)، وليس حكماً على صحة الأخبار.")
    if IS_ADMIN:
        render_run_report()
    if not (_GT and _GG):
        st.info("التقرير اليومي يحتاج التخزين الدائم (GITHUB_TOKEN وGIST_ID).")
        return
    if "reports" not in st.session_state or time.time() - st.session_state.get("reports_t", 0) > 600:
        try:
            st.session_state["reports"] = store.load_reports(_GT, _GG)
        except Exception as e:
            st.error(f"تعذّر تحميل التقارير ({type(e).__name__}).")
            return
        st.session_state["reports_t"] = time.time()
    rp = st.session_state["reports"]
    days = sorted((rp.get("archive") or {}).keys(), reverse=True)
    if not days:
        st.info("لا يوجد تقرير بعد. شغّل خطوة «التقرير اليومي» من GitHub Actions أول مرة (راجع README)، وبعدها يتجدد وحده كل صباح.")
        return
    day = st.selectbox("التاريخ", days, key="dr_day")
    rep = rp["archive"][day]
    gen = keys_mod.parse(rep.get("generated"))
    if gen:
        st.caption(f"آخر تحديث: {gen.astimezone(core.TZ).strftime('%Y-%m-%d %H:%M')} بتوقيت القاهرة")
    names = list(rep["files"].keys())
    pick_ = st.radio("الملف", (["📌 نشرة اليوم"] if rep.get("overview") else []) + names, horizontal=True, key="dr_file")
    if pick_.startswith("📌"):
        st.markdown(rep["overview"])
        return
    f = rep["files"][pick_]
    st.caption(f"عدد العناوين التي فُحصت: {f.get('total', '—')} · منها يخص مصر: {f.get('egypt', '—')}")
    if f.get("brief"):
        st.markdown(f["brief"])
    elif f.get("error"):
        st.warning("تعذّر توليد هذا الملف اليوم.")
    else:
        st.info("لا ملخص لهذا الملف (العناوين أدناه).")
    shown = f.get("items", [])
    if not shown:
        return
    only_eg = st.checkbox("🇪🇬 المتعلق بمصر فقط", value=False, key="dr_eg")
    with st.expander(f"📋 العناوين ({len(shown)})", expanded=not f.get("brief")):
        for a in shown:
            if only_eg and not a.get("egypt"):
                continue
            try:
                lnk = f"?view={quote(a['url'], safe='')}&seen={a.get('seendate', '')}&t={quote(a['title'][:200], safe='')}{auth_qs()}"
                eg_mark = "🇪🇬 " if a.get("egypt") else ""
                side_txt = intel.SIDES.get(a.get("side", ""), "")
                line = (f"- {eg_mark}**{a.get('title_ar', '')}** — {src_label(a.get('domain', ''))} · {a.get('ctype', '')} · "
                        f"{side_txt}  \n  [ترجم المقال]({lnk}) · [الأصل]({a.get('url', '')})")
                if a.get("ents"):
                    line += "  \n  🏷️ " + "، ".join(str(x) for x in a["ents"])
                if a.get("snip_ar"):
                    line += "  \n  > " + str(a["snip_ar"])
                st.markdown(line)
            except Exception as e:
                st.caption(f"⚠️ تعذّر عرض عنوان ({type(e).__name__}: {e})")


render_about()
if not IS_ADMIN and st.session_state["auth"].get("scope") == "reports":
    render_daily()  # اشتراك «تقرير فقط»: لا يرى بقية التطبيق
    show_footer()
    st.stop()

# ───────── حفظ نتائج البحث: تبقى (للمالك) حتى تبحث من جديد، حتى لو انقطع الاتصال او فتحت التطبيق لاحقا ─────────
RES_FILE = "marsad_results.json"


def _res_sig(d):
    its = d.get("items") or []
    return [len(its), its[0].get("url", "") if its else "", len(d.get("summaries") or {}), len(d.get("used") or [])]


if PERSIST and "_res_loaded" not in st.session_state:
    st.session_state["_res_loaded"] = True
    st.session_state["_res_loaded_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    st.session_state["_res_sigs"] = {}
    try:
        for _k, _v in (store.load_file(GH_TOKEN, GH_GIST, RES_FILE, {}) or {}).items():
            if isinstance(_v, dict) and f"res_{_k}" not in st.session_state:
                st.session_state[f"res_{_k}"] = _v
                st.session_state["_res_sigs"][_k] = _res_sig(_v)
    except Exception:
        pass


def _pack_res(v):
    out = {**v, "items": (v.get("items") or [])[:200], "saved_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    return json.loads(json.dumps(out, ensure_ascii=False, default=str))


def reload_results():
    """يجيب آخر نتائج محفوظة (بما فيها نتيجة البحث الشامل اللي اشتغل على GitHub) ويستبدل بيها اللي في الصفحة"""
    got = store.load_file(GH_TOKEN, GH_GIST, RES_FILE, {}) or {}
    st.session_state["_res_sigs"] = {}
    n = 0
    for _k, _v in got.items():
        if isinstance(_v, dict) and "items" in _v:
            st.session_state[f"res_{_k}"] = _v
            st.session_state["_res_sigs"][_k] = _res_sig(_v)
            n += 1
    st.session_state["_res_loaded_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    return n


def auto_pull_jobs():
    """لو بحث GitHub (الشامل أو تتبّع موضوع) خلص بعد ما فتحت الصفحة، بنحمّل نتيجته لوحدنا (بنبص كل دقيقتين بس)"""
    ss = st.session_state
    if not PERSIST or time.time() - ss.get("_jobs_chk", 0) < 120:
        return False
    ss["_jobs_chk"] = time.time()
    loaded = keys_mod.parse(ss.get("_res_loaded_at") or "")
    newest = None
    for fname in (SEARCH_STATUS, TOPIC_STATUS):
        try:
            stt = store.load_file(GH_TOKEN, GH_GIST, fname, {}) or {}
        except Exception:
            continue
        fin = keys_mod.parse(stt.get("finished") or "") if stt.get("state") == "done" else None
        if fin and (newest is None or fin > newest):
            newest = fin
    if newest and (loaded is None or newest > loaded):
        try:
            reload_results()
            ss["_res_loaded_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
            ss["sa_status"] = store.load_file(GH_TOKEN, GH_GIST, SEARCH_STATUS, {}) or {}
            return True
        except Exception:
            return False
    return False


def save_results():
    """بيحفظ بس التابات اللي اتغيرت في الصفحة دي، وبيدمجها فوق المحفوظ (عشان ما يمسحش نتايج البحث الشامل بتاع GitHub)"""
    if not PERSIST:
        return
    sigs = st.session_state.setdefault("_res_sigs", {})
    cur = {k[4:]: v for k, v in st.session_state.items() if k.startswith("res_") and isinstance(v, dict) and "items" in v}
    changed = {k: v for k, v in cur.items() if sigs.get(k) != _res_sig(v)}
    if not changed:
        return
    try:
        remote = store.load_file(GH_TOKEN, GH_GIST, RES_FILE, {}) or {}
        remote.update({k: _pack_res(v) for k, v in changed.items()})
        store.save_file(GH_TOKEN, GH_GIST, RES_FILE, remote)
        for k, v in changed.items():
            st.session_state["_res_sigs"][k] = _res_sig(v)
    except Exception:
        pass


# ───────── التابات فوق، وكل تاب بحث يعرض فلاترَه داخله (القيم تُقرأ كمتغيرات عامة وقت تنفيذ التاب) ─────────
_now0 = datetime.now(timezone.utc)
query, match, joiner, ctype = "", core.MATCH_MODES[0], "AND", "الكل"
start_utc, end_utc, max_rec, verify, hide_nomatch = _now0 - timedelta(days=7), _now0, 30, True, False

# تنقّل رئيسي مختصر: الوظائف مجمّعة حسب المهمة بدل 14 تبويباً متزاحماً.
tab_home, tab_search, tab_intel, tab_ops, tab_library, tab_settings = st.tabs([
    "🏠 الرئيسية", "🔎 البحث والرصد", "🛰️ التحليل والاستخبارات",
    "⏱️ غرفة العمليات", "🗂️ الملفات والأرشيف", "⚙️ المصادر والإعدادات"
])
with tab_search:
    tab_geo, tab_eg, tab_ml, tab_br, tab_gd = st.tabs([
        "🌍 بحث حسب المنطقة", "🇪🇬 الشأن المصري", "🔤 ترجمة ثم بحث", "🗞️ تصفح المصادر", "🌐 بحث GDELT"
    ])
with tab_intel:
    tab_wr, tab_in = st.tabs(["✍️ كتّاب ومحللون", "🛰️ مكتب الاستخبارات"])
with tab_library:
    tab_dos, tab_sv = st.tabs(["🧵 الملفات والخيوط", "📌 المحفوظات"])
tab_dr = tab_ops
tab_ms = tab_settings
home_box = tab_home


def use_filters(p, level="full"):
    """يرسم فلاتر هذا التاب (مفاتيحها تبدأ بـ p) ويضبط المتغيرات العامة التي تقرأها دوال البحث.
    level: full = كلمات + وقت + نوع، kw = كلمات + نوع فقط"""
    g = globals()
    g["query"] = st.text_input(
        "🔎 كلمات البحث", key=f"{p}_q",
        placeholder="مثال: وزير الخارجية المصري   —   او عدة مواضيع بفاصلة: اليمن، الحوثيين، مصر",
        help="كل ما بين فاصلتين (، او , او . بعد كلمة عربية) يُعامل كموضوع مستقل. بدون فاصلة تُعتبر الجملة كلها عبارة واحدة. للعرض بدون كلمات استخدم «اعرض كل ما نُشر».",
    )
    with st.expander("⚙️ فلاتر متقدمة (المطابقة، الوقت، نوع المحتوى)" if level == "full" else "⚙️ فلاتر (نوع المحتوى وربط العبارات)"):
        c1, c2 = st.columns(2)
        if level == "full":
            g["match"] = c1.radio("طريقة مطابقة كل عبارة", core.MATCH_MODES, key=f"{p}_match",
                                  help="Near: الكلمات متقاربة بأي ترتيب (الأنسب للجمل). Exact: العبارة بنصها المترجم حرفياً. AND: الكلمات موجودة في المقال في أي موضع.")
        jl = c2.radio("عند وجود أكثر من عبارة", ["كلها معاً (AND)", "أيٌّ منها (OR)"], key=f"{p}_join")
        g["joiner"] = "OR" if "OR" in jl else "AND"
        g["ctype"] = st.selectbox("نوع المحتوى", ["الكل", "خبر", "تحليل", "رأي"], key=f"{p}_ct0")
        if level == "full":
            mode = st.radio("النطاق الزمني", ["آخر ساعات", "آخر أيام", "تواريخ محددة"], horizontal=True, key=f"{p}_mode")
            now_utc = datetime.now(timezone.utc)
            if mode == "آخر ساعات":
                h = pick(st, "عدد الساعات", [1, 2, 3, 6, 12, 24, 36, 48, 72], 24, f"{p}_h")
                g["start_utc"], g["end_utc"] = now_utc - timedelta(hours=h), now_utc
            elif mode == "آخر أيام":
                d = pick(st, "عدد الأيام", [1, 2, 3, 5, 7, 10, 14, 21, 30, 45, 60, 90], 7, f"{p}_d")
                g["start_utc"], g["end_utc"] = now_utc - timedelta(days=d), now_utc
            else:
                today = datetime.now(core.TZ).date()
                rng = st.date_input("من – إلى", value=(today - timedelta(days=3), today), max_value=today, key=f"{p}_rng")
                if isinstance(rng, (list, tuple)) and len(rng) == 2:
                    s, e = rng
                else:
                    s = e = rng[0] if isinstance(rng, (list, tuple)) else rng
                g["start_utc"] = datetime(s.year, s.month, s.day, tzinfo=core.TZ).astimezone(timezone.utc)
                g["end_utc"] = datetime(e.year, e.month, e.day, 23, 59, 59, tzinfo=core.TZ).astimezone(timezone.utc)
            g["max_rec"] = pick(st, "عدد النتائج الأقصى", range(10, 110, 10), 30, f"{p}_max")
            g["verify"] = st.checkbox("🔍 افحص نص كل مقال واعرض جملة ذُكرت فيها كلمتك (أبطأ)", value=True, key=f"{p}_ver")
            g["hide_nomatch"] = st.checkbox("🚫 أخفِ المقالات التي لا تظهر كلمتك في نصها (موصى به)", value=True, key=f"{p}_hide",
                                            help="أخبار جوجل وGDELT أحياناً يرجّعوا مقالات الكلمة فيها بعيدة عن العنوان او مش موجودة. الفحص بيقرا نص المقال ويشيل اللي مفيهوش كلمتك.")
    if level == "full":
        st.caption("النتايج اللي تطلع بتفضل محفوظة، ومبتتمسحش غير لما تبحث من جديد.")


def pick_sources(key, groups, allow_custom=True):
    custom_lang = "en" if key == "rg" else ("ar" if key == "eg" else "both")
    """يعرض اختيار المصادر ويعيد قائمة (label, domains, lang)"""
    chosen = []
    extra_src = [(x["label"], x["domain"], x["lang"]) for x in S()["sources"] if x["group"] == key]
    if extra_src:
        groups = {**groups, "➕ مصادر أضفتَها": extra_src}
    for gname, entries in groups.items():
        labels = [e[0] for e in entries]
        sel = st.multiselect(gname, labels, default=labels, key=f"{key}_{gname}")
        chosen += [e for e in entries if e[0] in sel]
    if allow_custom:
        extra = st.text_input(
            "➕ مواقع إضافية (دومين واحد أو أكثر، بفاصلة)", placeholder="example.com, another.org", key=f"{key}_extra"
        )
        for dmn in re.split(r"[,\s]+", extra.strip().lower()):
            dmn = dmn.replace("https://", "").replace("http://", "").replace("www.", "").strip("/")
            if dmn and DOMAIN_RE.match(dmn):
                chosen.append((dmn, dmn, custom_lang))
    return chosen


def update_meta(data, sel):
    counts, ctry = {}, {}
    for a in data["items"]:
        n = source_name(a.get("domain", ""))
        counts[n] = counts.get(n, 0) + 1
        ctry[n] = source_country(a.get("domain", ""))
    data["counts"], data["ctry"] = counts, ctry
    data["silent"] = [lbl for lbl, _, _ in (sel or []) if lbl not in counts]


def do_search(key, jobs, sel=None, terms=None, pre=False, seed=None):
    terms = terms or [t.strip() for t in TERM_SPLIT.split(query) if t.strip()]
    if not terms:
        st.warning("اكتب كلمة بحث أولاً (في الخانة فوق في التاب).")
        return
    if not jobs:
        st.warning("اختر مصدراً واحداً على الأقل.")
        return
    # زر الإيقاف: الضغط عليه يقطع التنفيذ الجاري، وما ظهر حتى الآن محفوظ في session_state ويُعرض كاملاً
    st.button("⏹ إيقاف البحث والاكتفاء بالنتائج الظاهرة", key=f"stop_{key}")
    status_ph, live_ph = st.empty(), st.empty()
    status_ph.info("⏳ جارٍ التحضير والترجمة…")
    matchers = core.make_matchers_pre(jobs) if pre else core.make_matchers(terms, [j["code"] for j in jobs])
    hl = sorted({st_ for alts in matchers for stems in alts for st_ in stems}, key=len, reverse=True)
    data = {
        "items": [], "errors": [], "used": [], "summaries": {}, "counts": {}, "silent": [],
        "hidden": 0, "hl": hl, "partial": True,
    }
    st.session_state[f"res_{key}"] = data
    seed = seed or []

    def merged(items):
        have = {a["url"] for a in items}
        return sorted(items + [a for a in seed if a["url"] not in have], key=lambda a: a.get("seendate", ""), reverse=True)

    if seed:
        data["items"] = merged([])
        update_meta(data, sel)
        live_ph.markdown(live_html(data["items"], hl), unsafe_allow_html=True)
    for ev in core.search_iter(terms, joiner, match, jobs, start_utc, end_utc, max_rec, ctype):
        status_ph.info(f"⏳ {ev['msg']}")
        data["errors"], data["used"] = ev["errors"], ev["used"]
        if ev["items"] is not None:
            core.translate_titles([a for a in ev["items"] if "title_ar" not in a])
            data["items"] = merged(ev["items"])
            update_meta(data, sel)
            live_ph.markdown(live_html(data["items"], hl), unsafe_allow_html=True)
    if verify and data["items"]:
        items = data["items"]
        total = min(len(items), 80)
        for i in range(0, total, 8):
            status_ph.info(f"🔍 جارٍ فحص نصوص المقالات… ({i}/{total})")
            core.enrich_items(items[i:i + 8], matchers, joiner, limit=8)
            live_ph.markdown(live_html(items, hl), unsafe_allow_html=True)
    update_meta(data, sel)
    if hide_nomatch:
        raw = data["items"]
        data["items"] = [a for a in raw if not (a.get("fetched") and not a.get("found"))]
        data["hidden"] = len(raw) - len(data["items"])
    data["partial"] = False
    status_ph.success(f"✅ تم — {len(data['items'])} نتيجة")
    live_ph.empty()


def highlight(text, stems):
    out = html.escape(text)
    for st_ in stems:
        out = re.sub(f"({re.escape(html.escape(st_))})", r"<b>\1</b>", out, flags=re.I)
    return out


def card_html(a):
    url = a.get("url", "")
    link = (f"?view={quote(url, safe='')}&seen={a.get('seendate', '')}&t={quote(a.get('title', '')[:200], safe='')}"
            f"&wr={quote(a.get('writer', '') or '', safe='')}&o={quote(a.get('outlet', '') or '', safe='')}{auth_qs()}")
    orig = html.escape(a.get("title", ""))
    en = a.get("title_en", "")
    en_line = f"<div class='ltr' dir='ltr'>EN: {html.escape(en)}</div>" if en and en != a.get("title") else ""
    dom = a.get("domain", "")
    src = src_label(dom)
    ctag = a.get("ctype", "") + ("" if a.get("ctype_sure") else " (تقدير)")
    wline = (
        f"✍️ الكاتب: <b>{html.escape(a['writer'])}</b> — {html.escape(a.get('outlet', ''))} "
        + ("· 📌 من صفحة الكاتب" if a.get("wsrc") == "feed" else "· 🔎 بحث باسم الكاتب")
        + {True: " · ✅ الاسم مؤكَّد في توقيع المقال", False: " · ⚠️ الاسم لم يظهر في توقيع الصفحة"}.get(a.get("byline"), "")
        + "<br>"
        if a.get("writer")
        else ""
    )
    return (
        f"<div class='ar-title'>{html.escape(a.get('title_ar', ''))}</div>"
        f"<div class='ltr' dir='ltr'>{orig}</div>{en_line}"
        f"<div class='meta'>🕒 {fmt_seen(a.get('seendate', ''))} (القاهرة)<br>{wline}"
        f"🌐 المصدر: {src}"
        + (f" · 🧭 {html.escape(a['country_ar'])}" if a.get("side") and a.get("country_ar") else "")
        + f" · <span class='badge'>{html.escape(ctag)}</span></div>"
        f"<a class='btn' href='{html.escape(link)}' target='_blank' rel='noopener'>ترجم المقال</a>"
    )


_MLVL = {"محوري": "🟢 المقال عن كلمتك فعلاً", "ملحوظ": "🟡 ذُكرت بشكل ملحوظ", "عابر": "⚪ ذكر عابر غالباً (مش موضوع المقال)"}


def mention_line(a):
    if a.get("mcount") is None or not a.get("fetched"):
        return ""
    n, w = a["mcount"], max(1, a.get("words", 1))
    return f"🔢 كلمتك ذُكرت **{n}** مرة في مقال حوالي {w} كلمة — {_MLVL.get(a.get('mlevel'), '')}"


def snippet_html(a, hl):
    if not a.get("checked"):
        return ""
    if not a.get("fetched"):
        return "<div class='meta'>ℹ️ تعذّر فحص نص المقال (قد يكون خلف اشتراك أو يحجب الزحف).</div>"
    if a.get("found"):
        ml = mention_line(a).replace("**", "")
        out = f"<div class='meta'>✅ ذُكرت كلمتك في نص المقال:</div>" + (f"<div class='meta'>{html.escape(ml)}</div>" if ml else "") + f"<div>{html.escape(a.get('snip_ar', ''))}</div>"
        for sn in a.get("snips", []):
            out += f"<div class='ltr' dir='ltr'>{highlight(sn, hl)}</div>"
        return out
    return "<div class='meta'>⚠️ كلمتك لم تظهر في نص هذا المقال.</div>"


def live_html(items, hl):
    """عرض خفيف (بدون أزرار) أثناء البحث؛ تُرسم الأزرار الكاملة بعد الانتهاء أو الإيقاف"""
    return "".join(f"<div class='card'>{card_html(a)}{snippet_html(a, hl)}</div>" for a in items)


def render_results(key):
    data = st.session_state.get(f"res_{key}")
    if data is None:
        return
    if data.get("partial"):
        st.warning("⏹ توقّف البحث قبل اكتماله — هذه هي النتائج التي وُجدت حتى الآن (وقد لا تشمل فحص النصوص كاملاً).")
    for err in data["errors"]:
        st.warning(f"تنبيه من مصدر البيانات: {err}")
    with st.expander("الاستعلام المُرسل فعلياً (بعد الترجمة)"):
        for u in data["used"]:
            st.code(u, language=None)
    with st.expander("📊 توزيع النتائج على المصادر"):
        if data["counts"]:
            st.markdown("  \n".join(f"- **{n}** ({FLAGS.get(data.get('ctry', {}).get(n, ''), '🏳️')} {data.get('ctry', {}).get(n, '') or 'غير محددة'}): {c}" for n, c in sorted(data["counts"].items(), key=lambda x: -x[1])))
        if data["silent"]:
            st.markdown("**مصادر مختارة لم تُرجع نتائج:** " + "، ".join(data["silent"]))
            st.caption("غياب مصدر يعني أن GDELT لم يرصد له مقالات مطابقة في هذه الفترة، وليس أنه غير مدعوم في التطبيق.")
    if data.get("hidden"):
        st.caption(f"تم إخفاء {data['hidden']} مقالاً لم تظهر كلمتك في نصّه.")
    if not data["items"]:
        st.info("لا نتائج ضمن هذه الفلاتر. جرّب «كل الكلمات (AND)» أو وسّع النطاق الزمني أو زِد المصادر.")
    view_items = data["items"]
    if (view_items and not data.get("tr_retry") and time.time() > st.session_state.get("tr_down_until", 0)
            and untranslated(view_items[:20])):  # مرة واحدة لكل نتيجة: ترجم اللي فضل بلغته في أول صفحة
        data["tr_retry"] = True
        with st.spinner("جارٍ ترجمة العناوين اللي لسه مش مترجمة…"):
            if not fix_untranslated(view_items[:20], limit=20):
                st.session_state["tr_down_until"] = time.time() + 180  # خدمة الترجمة واقعة: ماتعطلش باقي التابات
    left_tr = len(untranslated(view_items))
    if left_tr:
        if st.button(f"🔁 ترجم العناوين اللي لسه مش مترجمة ({left_tr})", key=f"trfix_{key}"):
            with st.spinner("جارٍ الترجمة…"):
                n_fx = fix_untranslated(view_items, limit=80)
            st.caption(f"اتترجم {n_fx} عنوان." if n_fx else "خدمة الترجمة مش بترد دلوقتي. جرّب تاني بعد دقيقة.")
    if any(x.get("mcount") for x in view_items):
        if st.checkbox("🔢 رتّب حسب عدد مرات ذكر كلمتك (الأكثر ذكراً أولاً)", value=False, key=f"msort_{key}"):
            view_items = sorted(view_items, key=lambda x: (x.get("mcount") or 0), reverse=True)
    n_show = int(st.session_state.get(f"more_{key}", 20))
    total_items = len(view_items)
    for i, a in enumerate(view_items[:n_show]):
        url = a.get("url", "")
        with st.container(border=True):
            st.markdown(card_html(a), unsafe_allow_html=True)
            if a.get("checked"):
                if not a.get("fetched"):
                    st.caption("ℹ️ تعذّر فحص نص المقال (قد يكون خلف اشتراك أو يحجب الزحف).")
                elif a.get("found"):
                    st.success("✅ ذُكرت كلمتك في نص المقال:")
                    if mention_line(a):
                        st.markdown(mention_line(a))
                    st.markdown(a.get("snip_ar", ""))
                    for sn in a.get("snips", []):
                        st.markdown(f"<div class='ltr' dir='ltr'>{highlight(sn, data['hl'])}</div>", unsafe_allow_html=True)
                else:
                    st.warning("⚠️ كلمتك لم تظهر في نص هذا المقال — ربما تطابق GDELT مع الصفحة أو الروابط الجانبية.")
            if st.button("📝 ملخص المقال في نقاط", key=f"sum_{key}_{i}"):
                with st.spinner("جارٍ التلخيص…"):
                    data["summaries"][url] = core.summarize(url)
            if url in data["summaries"]:
                st.info(data["summaries"][url])
            listen_widget(a, f"{key}_{i}")
            if any(x.get("url") == url for x in S()["saved"]):
                st.caption("✅ محفوظ — تجده في تاب «المحفوظات»")
            else:
                st.button("💾 حفظ للقراءة لاحقاً", key=f"save_{key}_{i}", on_click=save_item, args=(a, key))
    if total_items > n_show:
        st.caption(f"معروض {n_show} من {total_items} نتيجة (بنعرضهم على دفعات عشان الصفحة تفضل خفيفة).")
        if st.button(f"⬇️ اعرض 20 كمان (باقي {total_items - n_show})", key=f"morebtn_{key}", use_container_width=True):
            st.session_state[f"more_{key}"] = n_show + 20
            st.rerun()


def all_entries(key, groups):
    out = []
    for entries in groups.values():
        out += list(entries)
    out += [(x["label"], x["domain"], x["lang"]) for x in S()["sources"] if x["group"] == key]
    return out


def author_variants(raw):
    """يعيد (الاسم بالإنجليزية، الاسم بالعبرية أو '') من أي لغة يكتبها المستخدم"""
    raw = raw.strip()
    if core._HAS_AR.search(raw):
        return tr(raw, "ar", "en"), tr(raw, "ar", "iw")
    if core._HEB.search(raw):
        return tr(raw, "iw", "en"), raw
    return raw, ""


def days_in_range():
    return max(1, int(-(-(end_utc - start_utc).total_seconds() // 86400)))


def add_gnews(key, sel, country, terms):
    """يضمّ نتائج أخبار Google (site:) إلى نتائج GDELT المعروضة"""
    data = st.session_state.get(f"res_{key}")
    if data is None or not terms:
        return
    with st.spinner("جارٍ ضمّ نتائج أخبار Google…"):
        items, notes = core.gnews_site_search(sel, days_in_range(), terms=terms, joiner=joiner, country=country)
    have = {a["url"] for a in data["items"]}
    new = [a for a in items if a["url"] not in have]
    if ctype != "الكل":
        new = [a for a in new if a.get("ctype") == ctype]
    if new:
        core.translate_titles(new)
        if verify:
            matchers = core.make_matchers(terms, core.codes_for(sel))
            core.enrich_items(new[:16], matchers, joiner, limit=16)
            if hide_nomatch:
                new = [a for a in new if not (a.get("fetched") and not a.get("found"))]
        data["items"] = sorted(data["items"] + new, key=lambda a: a.get("seendate", ""), reverse=True)
    data["used"] = data["used"] + notes
    update_meta(data, sel)


def gn_seed(sel, country, terms):
    """نتائج أخبار Google (سريعة) تُعرض فوراً بينما يعمل GDELT"""
    items, notes = core.gnews_site_search(sel, days_in_range(), terms=terms, joiner=joiner, country=country)
    if ctype != "الكل":
        items = [a for a in items if a.get("ctype") == ctype]
    core.translate_titles(items)
    return items, notes


def author_search(key, sel, country, author_raw, he_raw, only_confirmed, with_terms, terms):
    en, he = author_variants(author_raw)
    he = he_raw.strip() or he
    with st.spinner(f"جارٍ البحث عن مقالات «{author_raw}» في {len(sel)} مصدراً والتحقق من التوقيع…"):
        items, notes = core.gnews_site_search(
            sel, days_in_range(), terms=terms if with_terms else None, joiner=joiner,
            author=en, author_he=he or None, country=country,
        )
        if ctype != "الكل":
            items = [a for a in items if a.get("ctype") == ctype]
        core.translate_titles(items)
    hidden = 0
    if only_confirmed:
        kept = [a for a in items if a.get("byline") is not False]
        hidden, items = len(items) - len(kept), kept
    data = {
        "items": items, "errors": [] if items else ["لم يُعثر على مقالات بهذا الاسم — جرّب كتابته بالإنجليزية كما يظهر في توقيع المقال، أو وسّع النطاق الزمني."],
        "used": notes, "summaries": {}, "counts": {}, "silent": [], "hidden": hidden,
        "hl": sorted({t for t in core._name_tokens(en + " " + he)}, key=len, reverse=True),
    }
    st.session_state[f"res_{key}"] = data
    update_meta(data, sel)


def direct_title_hits(key, sel, terms):
    """بحث سريع بالكلمات في عناوين خلاصات المصادر المباشرة (RSS/الصفحة الرئيسية)، لأن GDELT وأخبار Google لا يغطيان كل المواقع"""
    d_items, d_notes = core.direct_headlines(sel, days_in_range())
    if ctype != "الكل":
        d_items = [a for a in d_items if a.get("ctype") == ctype]
    matchers = core.make_matchers(terms, core.codes_for(sel))
    hits = [a for a in d_items if core.find_mentions(a.get("title", ""), matchers, joiner)[0]]
    core.translate_titles(hits)
    data = st.session_state.get(f"res_{key}") or {"items": [], "errors": [], "used": [], "summaries": {}, "counts": {}, "silent": [], "hidden": 0, "hl": []}
    have = {x["url"].split("?")[0].rstrip("/") for x in data["items"]}
    new = [a for a in hits if a["url"].split("?")[0].rstrip("/") not in have]
    hl = sorted({st_ for alts in matchers for stems in alts for st_ in stems}, key=len, reverse=True)
    data["items"] = sorted(data["items"] + new, key=lambda a: a.get("seendate", ""), reverse=True)
    data["used"] = list(data.get("used", [])) + d_notes + [f"بحث العناوين المباشر ⟵ فُحص {len(d_items)} عنواناً من خلاصات المصادر ⟵ طابق {len(hits)} (جديد: {len(new)})"]
    data["hl"] = sorted(set(data.get("hl", [])) | set(hl), key=len, reverse=True)
    data["partial"] = False
    if new:
        data["errors"] = []  # وُجدت نتائج، فلا داعي لتحذير «لا نتائج»
    st.session_state[f"res_{key}"] = data
    update_meta(data, sel)
    if new:
        st.success(f"📡 لقيت {len(new)} نتيجة إضافية من خلاصة المصدر المباشرة (غير موجودة في GDELT ولا أخبار Google).")


def body_search(key, sel, terms, gn_country, n):
    """بحث في نص المقالات: يجمع أحدث عناوين المصادر (من مواقعها ثم أخبار Google) ويقرأ نص كل مقال ويُبقي ما ذُكرت فيه كلماتك"""
    bar = st.progress(0.0, text="جارٍ جمع أحدث مقالات المصادر…")
    d_items, d_notes = core.direct_headlines(sel, days_in_range())
    g_items, g_notes = core.gnews_site_search(sel, days_in_range(), terms=None, joiner=joiner, country=gn_country, max_items=200)
    pool = core.merge_items(d_items, g_items)
    if ctype != "الكل":
        pool = [a for a in pool if a.get("ctype") == ctype]
    pool = pool[:n]
    matchers = core.make_matchers(terms, core.codes_for(sel))
    hl = sorted({st_ for alts in matchers for stems in alts for st_ in stems}, key=len, reverse=True)
    for i in range(0, len(pool), 8):
        bar.progress(min(1.0, i / max(1, len(pool))), text=f"🔬 جارٍ قراءة نصوص المقالات… ({i}/{len(pool)})")
        core.enrich_items(pool[i:i + 8], matchers, joiner, limit=8)
    bar.empty()
    hits = [a for a in pool if a.get("found")]
    unread = sum(1 for a in pool if a.get("checked") and not a.get("fetched"))
    core.translate_titles(hits)
    note = f"بحث النص ⟵ قُرئ {len(pool) - unread} مقالاً من {len(pool)} ⟵ وُجدت الكلمات في {len(hits)}" + (f" ⟵ تعذّر فتح {unread} (حجب أو اشتراك)" if unread else "")
    data = st.session_state.get(f"res_{key}") or {"items": [], "errors": [], "used": [], "summaries": {}, "counts": {}, "silent": [], "hidden": 0, "hl": []}
    have = {x["url"] for x in data["items"]}
    data["items"] = sorted(data["items"] + [a for a in hits if a["url"] not in have], key=lambda a: a.get("seendate", ""), reverse=True)
    data["used"] = list(data.get("used", [])) + d_notes + [note]
    data["hl"] = sorted(set(data.get("hl", [])) | set(hl), key=len, reverse=True)
    data["partial"] = False
    st.session_state[f"res_{key}"] = data
    update_meta(data, sel)
    if hits:
        st.success(f"🔬 لقيت {len(hits)} مقال بيذكر كلمتك داخل النص (من {len(pool) - unread} مقال اتقرا).")
    else:
        st.info(f"🔬 قرأت {len(pool) - unread} مقال ومالقيتش كلمتك في نصوصهم." + (f" وتعذّر فتح {unread}." if unread else ""))


def curated_tab(key, groups, gd_country, gn_country, btn_label):
    with st.expander("🗂️ اختيار المصادر ونطاق التغطية", expanded=False):
        sel = pick_sources(key, groups)
    st.caption(f"المصادر المحددة: {len(sel)} — افتح اختيار المصادر لتخصيص الصحف والمواقع.")
    pool = all_entries(key, groups)
    scope = st.radio("نطاق البحث", ["كل المصادر المختارة أعلاه", "🎯 داخل مصدر واحد فقط"], horizontal=True, key=f"{key}_scope")
    if scope.startswith("🎯"):
        names = [e[0] for e in pool]
        one = st.selectbox("اختر المصدر الذي تبحث بداخله", names, key=f"{key}_one")
        sel = [e for e in pool if e[0] == one][:1]
        st.caption("سيُبحث عن كلمتك داخل هذا الموقع وحده (عبر GDELT وأخبار Google معاً). المصادر التي أضفتَها من رابط تظهر أيضاً في القائمة.")
    qm = st.radio("طريقة البحث", ["🔎 بكلمة البحث (فوق في التاب)", "📰 اعرض كل ما نُشر (بدون كلمات)"], horizontal=True, key=f"{key}_qm")
    if qm.startswith("📰"):
        st.caption("هيقرا عناوين المصادر اللي اخترتها (أو المصدر الواحد) من مواقعها مباشرة (خلاصة RSS أو الصفحة الرئيسية)، ويكمّلها من أخبار Google، خلال الفترة المحددة فوق في التاب، من غير ما تكتب كلمة. "
                   f"عدد المصادر دلوقتي: {len(sel)}.")
        if st.button("📰 اعرض كل ما نُشر", type="primary", use_container_width=True, key=f"goall_{key}"):
            if not sel:
                st.warning("اختر مصدراً واحداً على الأقل.")
            else:
                with st.spinner(f"جارٍ قراءة عناوين {len(sel)} مصدراً من مواقعها مباشرة ثم تكميلها من أخبار Google…"):
                    d_items, d_notes = core.direct_headlines(sel, days_in_range())
                    g_items, g_notes = core.gnews_site_search(sel, days_in_range(), terms=None, joiner=joiner, country=gn_country, max_items=200)
                    items, notes = core.merge_items(d_items, g_items), d_notes + g_notes
                    if key in ("eg", "egt"):
                        items = egypt_only(items)
                    if ctype != "الكل":
                        items = [a for a in items if a.get("ctype") == ctype]
                    core.translate_titles(items)
                dd = {"items": items, "errors": [] if items else ["لم تُرجع أخبار Google عناوين لهذه المصادر في الفترة. وسّع الفترة أو غيّر المصادر."],
                      "used": notes, "summaries": {}, "counts": {}, "silent": [], "hidden": 0, "hl": []}
                st.session_state[f"res_{key}"] = dd
                update_meta(dd, sel)
        render_results(key)
        return
    c1_, c2_ = st.columns(2)
    author_raw = c1_.text_input(
        "✍️ اسم كاتب أو مراسل (اختياري)", key=f"{key}_author",
        placeholder="مثال: Barak Ravid أو باراك رافيد", help="عند كتابته يُبحث عن مقالات هذا الشخص داخل المصادر أعلاه. يمكن الكتابة بالعربية أو الإنجليزية أو العبرية.",
    )
    he_raw = c2_.text_input("اسمه بالعبرية (اختياري، لدقة أعلى)", key=f"{key}_author_he") if key == "il" else ""
    if author_raw.strip():
        o1, o2 = st.columns(2)
        with_terms = o1.checkbox("قيّد بكلمة البحث فوق في التاب أيضاً", value=False, key=f"{key}_awt")
        only_conf = o2.checkbox("أخفِ ما ثبت أن اسمه ليس في توقيع المقال", value=False, key=f"{key}_aoc")
    else:
        with_terms = only_conf = False
        use_gn = st.checkbox("➕ ضمّ نتائج أخبار Google إلى GDELT (يغطي ما يفوته GDELT)", value=True, key=f"{key}_gn")
        use_body = st.checkbox("🔬 ابحث كمان داخل نص المقالات (يقرا أحدث مقالات المصدر ويدوّر فيها؛ أبطأ بس بيلقط اللي كلمتك في وسطه)", value=False, key=f"{key}_body")
        body_n = pick(st, "عدد المقالات اللي هتتقرا", range(20, 130, 10), 60, f"{key}_bn") if use_body else 0
    if st.button(btn_label, type="primary", use_container_width=True, key=f"go_{key}"):
        terms = [t.strip() for t in TERM_SPLIT.split(query) if t.strip()]
        if author_raw.strip():
            if with_terms and not terms:
                st.warning("اكتب كلمة البحث فوق في التاب أو ألغِ التقييد بها.")
            elif not sel:
                st.warning("اختر مصدراً واحداً على الأقل.")
            else:
                author_search(key, sel, gn_country, author_raw, he_raw, only_conf, with_terms, terms)
        else:
            seed, gnotes = [], []
            if use_gn and sel and terms:
                with st.spinner("جارٍ جلب نتائج أخبار Google أولاً (سريعة)…"):
                    try:
                        seed, gnotes = gn_seed(sel, gn_country, terms)
                    except Exception as ex:
                        gnotes = [f"Google News تعذّر: {type(ex).__name__}"]
            do_search(key, core.jobs_for_sources(sel, gd_country), sel, seed=seed)
            if gnotes and st.session_state.get(f"res_{key}"):
                st.session_state[f"res_{key}"]["used"] += gnotes
            if use_body and sel and terms:
                body_search(key, sel, terms, gn_country, body_n)
            elif sel and terms:
                with st.spinner("جارٍ البحث كمان في عناوين خلاصات المصادر مباشرة…"):
                    try:
                        direct_title_hits(key, sel, terms)
                    except Exception as ex:
                        st.caption(f"تعذّر البحث المباشر في الخلاصات: {type(ex).__name__}")
            if use_body and not terms:
                st.warning("اكتب كلمة بحث فوق في التاب عشان البحث داخل النص.")
    render_results(key)


def style_tabs():
    """يلوّن التابات الرئيسية ويكبّرها بجافاسكربت (لأن الـCSS وحده مش بيمسك في كل نسخ Streamlit)"""
    import streamlit.components.v1 as components
    components.html("""
<script>
(function(){
  var COL=["#c0392b","#2563c9","#d9822b","#2a8f55","#8a5a00"];
  function paint(){
    try{
      var doc=window.parent.document;
      var lists=doc.querySelectorAll('[role="tablist"]');
      if(!lists.length) return;
      var tabs=lists[0].querySelectorAll('[role="tab"]');
      tabs.forEach(function(t,i){
        t.style.setProperty('border-radius','14px','important');
        t.style.setProperty('padding','10px 14px','important');
        t.style.setProperty('min-height','48px','important');
        t.style.setProperty('border','1px solid rgba(128,128,128,.4)','important');
        t.style.setProperty('margin','3px','important');
        if(i>=3&&i<=7){
          t.style.setProperty('background',COL[i-3],'important');
          t.style.setProperty('color','#fff','important');
          t.style.setProperty('font-weight','700','important');
          t.style.setProperty('min-height','54px','important');
          var sel=t.getAttribute('aria-selected')==='true';
          t.style.setProperty('box-shadow',sel?'0 0 0 3px rgba(255,255,255,.7),0 4px 14px rgba(0,0,0,.5)':'none','important');
          t.style.setProperty('opacity',sel?'1':'.85','important');
        } else {
          var s2=t.getAttribute('aria-selected')==='true';
          t.style.setProperty('background',s2?'rgba(255,75,75,.25)':'rgba(128,128,128,.12)','important');
        }
      });
      lists[0].style.setProperty('flex-wrap','wrap','important');
    }catch(e){}
  }
  paint(); setInterval(paint,700);
})();
</script>""", height=0)


HOME_SECTIONS = {"il": ("اسرائيلي", ISRAEL, "IL", "#c0392b"), "us": ("امريكي", USA, "US", "#2563c9"),
                 "uk": ("بريطاني", UK, "UK", "#d9822b"), "rg": ("تركيا وايران واثيوبيا", REGION, "US", "#2a8f55")}
HOME_GD = {"il": "IS", "us": "US", "uk": "UK", "rg": None}


def _ago(seen):
    try:
        dt = datetime.strptime(seen, "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc)
        m = int((datetime.now(timezone.utc) - dt).total_seconds() // 60)
        return f"منذ {m} دقيقة" if m < 60 else (f"منذ {m // 60} ساعة" if m < 2880 else f"منذ {m // 1440} يوم")
    except Exception:
        return ""


def home_search(q, keys, days, join, bar, use_gd=False):
    terms = [t.strip() for t in TERM_SPLIT.split(q) if t.strip()]
    got = {}
    for n, key in enumerate(keys):
        label, groups, gn_c, _col = HOME_SECTIONS[key]
        bar.progress(n / max(1, len(keys)), text=f"جارٍ البحث في القسم {label}…")
        sel = all_entries(key, groups)
        try:
            g_items, g_notes = core.gnews_site_search(sel, days, terms=terms, joiner=join, country=gn_c, max_items=80)
            d_items, d_notes = core.direct_headlines(sel, days)
            m = core.make_matchers(terms, core.codes_for(sel))
            d_hits = [a for a in d_items if core.find_mentions(a.get("title", ""), m, join)[0]]
            gd_items = []
            if use_gd:
                now_ = datetime.now(timezone.utc)
                last = None
                for ev in core.search_iter(terms, join, core.MATCH_MODES[0], core.jobs_for_sources(sel, HOME_GD[key]),
                                           now_ - timedelta(days=days), now_, 60, "الكل"):
                    if ev["items"] is not None:
                        last = ev["items"]
                gd_items = last or []
                g_notes = g_notes + [f"GDELT ⟵ {len(gd_items)} نتيجة"]
            items = core.merge_items(g_items, d_hits, gd_items)
            core.translate_titles(items)
        except Exception as ex:
            items, g_notes, d_notes = [], [f"تعذّر ({type(ex).__name__})"], []
        dd = {"items": items, "errors": [] if items else ["لا نتائج في الفترة دي. جرب فترة اطول او كلمات تانية."],
              "used": g_notes + d_notes, "summaries": {}, "counts": {}, "silent": [], "hidden": 0, "hl": []}
        update_meta(dd, sel)
        st.session_state[f"res_{key}"] = dd
        got[key] = items
    bar.progress(1.0, text="تم")
    merged = []
    for key, its in got.items():
        for a in its:
            merged.append({**a, "_sec": key})
    merged.sort(key=lambda a: a.get("seendate", ""), reverse=True)
    st.session_state["res_home"] = {"items": merged[:150], "q": q, "counts": {k: len(v) for k, v in got.items()},
                                    "days": days, "errors": [], "used": [], "summaries": {}}


def render_home():
    st.markdown("#### 🏠 الرئيسية")
    q = st.text_input("🔎 ابحث في كل الاقسام مرة واحدة", key="home_q", placeholder="مثال: سد النهضة، مصر السعودية، سيناء")
    c1, c2, c3 = st.columns([3, 2, 2])
    keys = c1.multiselect("الاقسام", list(HOME_SECTIONS), default=list(HOME_SECTIONS), format_func=lambda k: HOME_SECTIONS[k][0], key="home_secs")
    days = pick(c2, "الفترة (ايام)", [1, 2, 3, 5, 7, 14, 30], 3, "home_days")
    jl = c3.radio("لو اكتر من كلمة", ["اي منها", "كلها"], key="home_join")
    use_gd = st.checkbox("🌐 ضم GDELT (ادق وابطأ)", value=False, key="home_gd",
                         help="بيضيف نتايج GDELT لكل قسم. اتأخر من 3 لـ 8 دقايق. استخدمه للمواضيع المهمة.")
    if st.button("🔎 ابحث في كل الاقسام", type="primary", use_container_width=True, key="home_go"):
        if not q.strip() or not keys:
            st.warning("اكتب كلمة بحث واختار قسم واحد على الاقل.")
        else:
            bar = st.progress(0.0, text="بدأنا…")
            home_search(q, keys, days, "AND" if jl == "كلها" else "OR", bar, use_gd)
            bar.empty()
    h = st.session_state.get("res_home")
    now_utc0 = datetime.now(timezone.utc).strftime("%Y%m%d")
    all_items = [a for k in HOME_SECTIONS for a in (st.session_state.get(f"res_{k}") or {}).get("items", [])]
    today_n = sum(1 for a in all_items if str(a.get("seendate", "")).startswith(now_utc0))
    s1, s2, s3 = st.columns(3)
    n_src = len({d for g in (ISRAEL, USA, UK, REGION) for ents in g.values() for _, d, _ in ents})
    for col, num, lab in ((s1, today_n, "خبر النهارده (في نتايجك)"), (s2, len(all_items), "خبر محفوظ في الاقسام"), (s3, n_src, "مصدر مراقب")):
        col.markdown(f"<div class='hm-stat'><b>{num}</b>{lab}</div>", unsafe_allow_html=True)
    if not h:
        st.caption("اكتب موضوعك مرة واحدة، وهتظهر النتائج مجمعة زمنياً. باقي أدوات الرصد والتحليل موجودة في الأقسام الرئيسية أعلى الصفحة.")
        return
    cnt = " · ".join(f"{HOME_SECTIONS[k][0]}: {n}" for k, n in h.get("counts", {}).items())
    st.markdown(f"**نتيجة «{html.escape(h.get('q', ''))}»** — اخر {h.get('days')} يوم — {cnt}")
    st.caption("دي آخر الأخبار مجمعة. للتفاصيل (ملخص، ترجمة المقال، حفظ) افتح قسم البحث والرصد.")
    for a in h["items"][:25]:
        sec = HOME_SECTIONS.get(a.get("_sec"), ("", None, "", "#555"))
        ttl = html.escape(a.get("title_ar") or a.get("title") or "")
        st.markdown(
            f"<div class='hm-row'><span class='hm-tag' style='background:{sec[3]}'>{sec[0]}</span>"
            f"<a href='{html.escape(a.get('url', ''))}' target='_blank'><b>{ttl}</b></a><br>"
            f"<span class='meta'>{src_label(a.get('domain', ''), False)} · {_ago(a.get('seendate', ''))}</span></div>",
            unsafe_allow_html=True)


with home_box:
    render_home()
with tab_geo:
    geo_options = {
        "🇮🇱 إسرائيل": ("il", ISRAEL, "IS", "IL", "ابحث في المصادر الإسرائيلية",
                         "يُترجم بحثك إلى العبرية للمصادر العبرية، وإلى الإنجليزية للنسخ الإنجليزية."),
        "🇺🇸 الولايات المتحدة": ("us", USA, "US", "US", "ابحث في المصادر الأمريكية",
                                  "مصادر أمريكية ومراكز أبحاث وصحافة دولية ناطقة بالإنجليزية."),
        "🇬🇧 بريطانيا": ("uk", UK, "UK", "UK", "ابحث في المصادر البريطانية",
                          "صحف وقنوات بريطانية ومصادر متخصصة بالشرق الأوسط."),
        "🌍 تركيا وإيران وإثيوبيا": ("rg", REGION, None, "US", "ابحث في مصادر تركيا وإيران وإثيوبيا",
                                     "مصادر محلية بلغاتها: التركية والفارسية والأمهرية والإنجليزية.")
    }
    geo_choice = st.radio("نطاق الرصد", list(geo_options), horizontal=True, key="geo_scope")
    geo_key, geo_groups, geo_gd, geo_gn, geo_label, geo_help = geo_options[geo_choice]
    use_filters(geo_key, "full")
    st.caption(geo_help)
    if geo_key == "rg":
        st.caption("اختر مصدراً واحداً أو عدة مصادر أو كلها، أو ابحث داخل مصدر واحد.")
    curated_tab(geo_key, geo_groups, geo_gd, geo_gn, geo_label)

DAY_OPTS = {"آخر 24 ساعة": 1, "آخر 3 أيام": 3, "آخر 7 أيام": 7, "آخر 14 يوماً": 14, "آخر 30 يوماً": 30}


def browse_run(label, doms, lang, sec_name, url, kind):
    with st.spinner("جارٍ فتح القسم وترجمة العناوين…"):
        items, err = core.browse_section(url, doms)
        how = "فتح الصفحة مباشرة"
        if not items:
            pu = urlparse_path(url)
            items, notes = core.gnews_site_search([(label, pu, lang)], 14, country="IL" if lang == "he" else "US", max_items=40)
            how = "أخبار Google (الموقع يحجب الفتح المباشر)"
            err = err + " " + " | ".join(notes[:1])
        for a in items:
            ct, sure = core.classify(a["url"], a["title"])
            a["ctype"], a["ctype_sure"] = (kind, True) if kind else (ct, sure)
        core.translate_titles(items)
    data = {"items": items, "errors": [] if items else [f"تعذّر جلب القسم. {err}"], "used": [f"{url} ⟵ {how}: {len(items)}"],
            "summaries": {}, "counts": {}, "silent": [], "hidden": 0, "hl": []}
    st.session_state["res_br"] = data
    update_meta(data, None)


def urlparse_path(url):
    p = urlparse(url)
    host = p.netloc.replace("www.", "")
    path = p.path.rstrip("/")
    return host + path


with tab_br:
    use_filters("br", "kw")
    st.caption("افتح مصدراً وتصفّح أقسامه (الرأي، الأخبار…) بعناوين مترجمة للعربية؛ اضغط «ترجم المقال» على أي عنوان لقراءته مترجماً، أو احفظه. "
               "بعض المواقع المدفوعة تحجب الفتح المباشر فيُستعان بأخبار Google بدلاً منه.")
    pool_all = {}
    for grp_key, groups in (("il", ISRAEL), ("us", USA), ("uk", UK), ("rg", REGION)):
        for e in all_entries(grp_key, groups):
            pool_all[e[0]] = e
    bmode = st.radio("طريقة العرض", ["📂 أقسام موقع واحد", "📅 عناوين عدة مصادر خلال فترة"], horizontal=True, key="br_mode")
    if bmode.startswith("📅"):
        scope_all = st.radio("المصادر", ["كل المصادر", "أختار مصادر بعينها"], horizontal=True, key="br_scope")
        chosen_src = list(pool_all.keys())
        if scope_all.startswith("أختار"):
            chosen_src = st.multiselect("اختر المصادر", list(pool_all.keys()), default=["تايمز أوف إسرائيل", "جيروزاليم بوست", "Axios", "Al-Monitor", "The Guardian"], key="br_multi")
        bdays = st.selectbox("الفترة", list(DAY_OPTS.keys()), index=1, key="br_days")
        use_kw = st.checkbox("اقتصر على كلمة البحث فوق في التاب (اتركه فارغاً لعرض كل العناوين)", value=False, key="br_kw")
        if st.button("اعرض العناوين", type="primary", use_container_width=True, key="go_br2"):
            kw = [t.strip() for t in TERM_SPLIT.split(query) if t.strip()] if use_kw else None
            sel_b = [pool_all[n] for n in chosen_src]
            if not sel_b:
                st.warning("اختر مصدراً واحداً على الأقل.")
            else:
                with st.spinner(f"جارٍ جلب عناوين {len(sel_b)} مصدراً…"):
                    items, notes = core.gnews_site_search(sel_b, DAY_OPTS[bdays], terms=kw, joiner=joiner, country="US", max_items=150)
                    if ctype != "الكل":
                        items = [a for a in items if a.get("ctype") == ctype]
                    core.translate_titles(items)
                dd = {"items": items, "errors": [] if items else ["لم تُرجع أخبار Google عناوين لهذه المصادر في الفترة."],
                      "used": notes, "summaries": {}, "counts": {}, "silent": [], "hidden": 0, "hl": []}
                st.session_state["res_br"] = dd
                update_meta(dd, sel_b)
        render_results("br")
    else:
        br_pick = st.selectbox("المصدر", list(pool_all.keys()), key="br_src")
        lbl, dom_s, lang_s = pool_all[br_pick]
        dlist = [d for d in dom_s.split("|") if d]
        secs = []
        for d in dlist:
            secs += [(n, u, k) for n, u, k in SECTIONS.get(d, [])]
        secs.append(("الصفحة الرئيسية", f"https://{dlist[0]}/", None))
        secs.append(("🔗 رابط قسم آخر (أدخله بنفسك)", "", None))
        sec_names = [x[0] for x in secs]
        sec_pick = st.radio("القسم", sec_names, horizontal=True, key="br_sec")
        sname_, surl_, skind_ = secs[sec_names.index(sec_pick)]
        if not surl_:
            surl_ = st.text_input("رابط صفحة القسم (من موقع هذا المصدر)", key="br_url", placeholder=f"https://{dlist[0]}/opinion").strip()
        if st.button("افتح القسم وترجمه", type="primary", use_container_width=True, key="go_br"):
            if not surl_.startswith("http"):
                st.warning("أدخل رابطاً صحيحاً.")
            else:
                browse_run(lbl, dlist, "he" if lang_s == "he" else "en", sname_, surl_, skind_)
        render_results("br")

for _n, _d, _sd, _k, _f in intel.SOURCES:
    DOMAIN_LABELS.setdefault(_d, _n)


def intel_run(file_name, terms, days, picked, with_media, media_sel, ar_sel=()):
    meta = {}
    for n, d, sd, k, f in intel.SOURCES:
        if n in picked:
            meta[d] = (sd, k)
    sel = [(n, d, "en") for n, d, sd, k, f in intel.SOURCES if n in picked]
    media = []
    if with_media:
        for grp, groups, sd in (("il", ISRAEL, "il"), ("us", USA, "us"), ("uk", UK, "uk")):
            for e in all_entries(grp, groups):
                if e[0] in media_sel and e[2] in ("en", "both"):
                    media.append((e[0], e[1], "en"))
                    for dd in e[1].split("|"):
                        meta.setdefault(dd, (sd, "media"))
    for grp in ARABIC.values():
        for lbl_, dom_, _l in grp:
            if lbl_ in ar_sel:
                media.append((lbl_, dom_, "ar"))
                meta.setdefault(dom_, ("eg" if dom_ in EGYPT_ARABIC else "ar", "media"))
    allsel = sel + [m for m in media if m[1] not in {x[1] for x in sel}]
    with st.spinner("جارٍ البحث في المؤسسات والمصادر وتصنيف النتائج…"):
        items, notes = core.gnews_site_search(allsel, days, terms=terms or None, joiner="OR", country="US", max_items=200)
        for a in items:
            sd, k = next(((v[0], v[1]) for dd, v in meta.items() if core.domain_match(a["domain"], [dd])), ("osint", "think"))
            a["ctype"], a["ctype_sure"] = intel.classify_intel(a["title"], a["url"], k), False
            a["side"] = sd
            a["egypt"] = bool(intel.EGYPT_RE.search(a["title"]))
        core.translate_titles(items)
        for a in items:
            a["country_ar"] = intel.SIDES.get(a["side"], "") + (" · 🇪🇬 يخص مصر" if a["egypt"] else "")
    data = {"items": items, "errors": [] if items else ["لم تُرجع أخبار Google نتائج — وسّع الفترة أو غيّر الكلمات."],
            "used": notes, "summaries": {}, "counts": {}, "silent": [], "hidden": 0, "hl": [],
            "meta": {"file": file_name, "terms": terms or ["(كل ما نُشر)"], "days": days}}
    update_meta(data, None)
    st.session_state["res_in_all"] = data


def intel_matrix(view):
    """جدول ربط: المنظورات × أنواع المعلومة، وما يقوله كل منظور عن مصر"""
    rows = ["| المنظور | " + " | ".join(intel.INTEL_TYPES) + " | يخص مصر |", "|" + "---|" * (len(intel.INTEL_TYPES) + 2)]
    for code, name in intel.SIDES.items():
        sub = [a for a in view if a.get("side") == code]
        if not sub:
            continue
        cells = [str(sum(1 for a in sub if a.get("ctype") == t)) for t in intel.INTEL_TYPES]
        rows.append(f"| {name} | " + " | ".join(cells) + f" | {sum(1 for a in sub if a.get('egypt'))} |")
    st.markdown("\n".join(rows))
    eg_items = [a for a in view if a.get("egypt")]
    if eg_items:
        st.markdown("**🇪🇬 ما تقوله كل جهة عن مصر في هذا الملف:**")
        for code, name in intel.SIDES.items():
            sub = [a for a in eg_items if a.get("side") == code][:6]
            if sub:
                st.markdown(f"*{name}*")
                st.markdown("\n".join(f"- [{a.get('title_ar', '')}]({a['url']}) — {src_label(a['domain'])}" for a in sub))
    else:
        st.caption("لا توجد عناوين تخص مصر ضمن النتائج الحالية.")


with tab_in:
    st.caption("مكتب استخبارات مفتوح المصدر للشرق الأوسط والقرن الأفريقي: تصفّح مؤسسة واحدة أو عدة مؤسسات أو كلها، وأضف التحركات المصرية لأي ملف، "
               "وقارن المنظورات في جدول ربط، ثم اصنع تقريراً. التصنيف تقديري من العنوان والرابط ولا يُغني عن مراجعة المصدر.")
    all_files = list(intel.FILES.keys())
    if st.checkbox("اختر كل الملفات دفعة واحدة", value=False, key="in_allfiles"):
        fnames = all_files
    else:
        fnames = st.multiselect("الملفات (اختر ملفاً أو أكثر، وسيُبحث فيها كلها معاً)", all_files, default=all_files[:1], key="in_files")
    if not fnames:
        st.warning("اختر ملفاً واحداً على الأقل.")
        fnames = all_files[:1]
    fname = " + ".join(fnames)
    fmeta = {"terms": list(dict.fromkeys(t for f in fnames for t in intel.FILES[f]["terms"])),
             "egypt": list(dict.fromkeys(t for f in fnames for t in intel.FILES[f]["egypt"])),
             "axes": "؛ ".join(intel.FILES[f]["axes"] for f in fnames)}
    st.markdown(f"**المحاور:** {fmeta['axes']}")
    egm = st.radio("التحركات المصرية", ["الملف + التحركات المصرية", "الملف فقط", "التحركات المصرية فقط"], horizontal=True, key="in_eg")
    base_terms = fmeta["terms"] if egm != "التحركات المصرية فقط" else []
    eg_terms = fmeta["egypt"] if egm != "الملف فقط" else []
    qmode = st.radio("طريقة العرض", ["🔎 بحث بكلمات الملف", "📰 اعرض كل ما نُشر (بدون كلمات)"], horizontal=True, key="in_qmode")
    terms_txt = ""
    if qmode.startswith("🔎"):
        terms_txt = st.text_input("كلمات البحث (يمكن تعديلها؛ بالإنجليزية أو العربية، بفاصلة)", value="، ".join(base_terms + eg_terms),
                                  key=f"in_terms_{fname}_{egm}")
        if len(fnames) > 1:
            st.caption(f"سيُبحث في {len(fnames)} ملفات معاً بكلماتها مجتمعة؛ قصّ الكلمات إن كانت كثيرة.")
    names = [x[0] for x in intel.SOURCES]
    side_list = [v for k, v in intel.SIDES.items() if k != "uk"]
    side_codes = {v: k for k, v in intel.SIDES.items()}
    scope_i = st.radio("المؤسسات", ["مؤسسة واحدة", "عدة مؤسسات", "كل المؤسسات"], horizontal=True, key="in_scope", index=1)
    if scope_i == "مؤسسة واحدة":
        picked = [st.selectbox("المؤسسة", names, key="in_one")]
    elif scope_i == "كل المؤسسات":
        picked = names
    else:
        sides_pick = st.multiselect("المنظورات", side_list, default=side_list, key="in_sides")
        default_src = [x[0] for x in intel.SOURCES if intel.SIDES[x[2]] in sides_pick]
        picked = st.multiselect("المؤسسات", names, default=default_src, key=f"in_src_{'_'.join(sorted(side_codes[x] for x in sides_pick))}")
    days_i = st.selectbox("الفترة", ["آخر 7 أيام", "آخر 14 يوماً", "آخر 30 يوماً", "آخر 90 يوماً"], index=1, key="in_days")
    days_n = int(re.findall(r"\d+", days_i)[0])
    with_media = st.checkbox("➕ ضمّ تغطية الإعلام الإسرائيلي والأمريكي والبريطاني (للمقارنة)", value=True, key="in_media")
    media_sel = []
    if with_media:
        media_pool = [e[0] for g, gr in (("il", ISRAEL), ("us", USA), ("uk", UK)) for e in all_entries(g, gr) if e[2] in ("en", "both")]
        media_sel = st.multiselect("الصحف المضمومة", media_pool, default=[m for m in media_pool if m in (
            "تايمز أوف إسرائيل", "جيروزاليم بوست", "Axios", "Al-Monitor", "BBC", "The Guardian", "Reuters",
            "Foreign Policy", "Middle East Eye", "Ynetnews (إنجليزي)", "هآرتس (إنجليزي)")], key="in_media_sel")
    use_ar = st.checkbox("➕ ضمّ الصحافة العربية (مصرية وخليجية) للمقارنة", value=False, key="in_ar")
    ar_sel = []
    if use_ar:
        ar_pool = [e[0] for grp in ARABIC.values() for e in grp]
        ar_sel = st.multiselect("الصحف العربية", ar_pool, default=ar_pool[:5] + ["الشرق الأوسط", "العربية", "الجزيرة"], key="in_ar_sel")
        st.caption("تُترجم كلمات البحث تلقائياً إلى العربية. بحث اسم الكاتب لا يشمل الصحف العربية.")
    if st.button("🛰️ ابحث / اعرض", type="primary", use_container_width=True, key="go_in"):
        tl = [t.strip() for t in TERM_SPLIT.split(terms_txt) if t.strip()]
        if qmode.startswith("🔎") and not tl:
            st.warning("اكتب كلمات البحث أو اختر «اعرض كل ما نُشر».")
        elif not picked:
            st.warning("اختر مؤسسة واحدة على الأقل.")
        else:
            intel_run(fname, tl, days_n, picked, with_media, media_sel, ar_sel)

    allr = st.session_state.get("res_in_all")
    if allr:
        items = allr["items"]
        c1_, c2_ = st.columns(2)
        f_type = c1_.multiselect("نوع المعلومة", intel.INTEL_TYPES, default=intel.INTEL_TYPES, key="in_ftype")
        f_side = c2_.multiselect("المنظور", list(intel.SIDES.values()), default=list(intel.SIDES.values()), key="in_fside")
        only_eg = st.checkbox("🇪🇬 اعرض ما يخص مصر فقط", value=False, key="in_onlyeg")
        view = [a for a in items if a.get("ctype") in f_type and intel.SIDES.get(a.get("side"), "") in f_side and (a.get("egypt") or not only_eg)]
        st.caption(f"{len(view)} نتيجة من {len(items)}")
        with st.expander("🔗 خريطة الربط: المنظورات × أنواع المعلومة، وما يخص مصر"):
            intel_matrix(view)
        st.session_state["res_in"] = {**allr, "items": sorted(view, key=lambda a: a.get("seendate", ""), reverse=True)}
        m = allr["meta"]
        rep = intel.build_report(f"تقرير: {m['file']}", m["file"], m["terms"], m["days"], view)
        d1_, d2_ = st.columns(2)
        d1_.download_button("📄 نزّل التقرير التجميعي (Markdown)", rep, file_name="intel_report.md", mime="text/markdown", use_container_width=True)
        with d2_.popover("👁️ معاينة التقرير", use_container_width=True):
            st.markdown(rep)
        with st.expander("🧩 أسئلة الربط: كيف يتقاطع هذا الملف مع غيره؟"):
            st.markdown("لكل خبر أو تقرير مهم اسأل:\n" + "\n".join(f"- {q}" for q in intel.LINK_QUESTIONS))
            st.caption("تلميح: غيّر «الملف» أعلاه وأعد البحث بنفس الأطراف لترى كيف يتقاطع البحر الأحمر مع القرن الأفريقي والخليج.")
        render_results("in")

    with st.expander("🔎 العثور على التقارير المجانية (PDF ومستودعات الأبحاث)"):
        q_free = st.text_input("عنوان التقرير أو موضوعه", key="in_free", placeholder="Egypt military assessment")
        if q_free.strip():
            for lbl_, u_ in intel.search_links(q_free):
                st.markdown(f"- [{lbl_}]({u_})")
            st.caption("ابحث عن النسخ المنشورة بإذن أصحابها أو الملخصات العلنية، أو اطلب نسخة من المؤلف.")
        else:
            st.caption("اكتب موضوعاً لتظهر روابط البحث الجاهزة.")
    with st.expander("📚 دليل المؤسسات"):
        for sd_code, sd_name in intel.SIDES.items():
            rows = [x for x in intel.SOURCES if x[2] == sd_code]
            if rows:
                st.markdown(f"**{sd_name}**")
                st.markdown("\n".join(f"- [{n}](https://{d}) — {f}" for n, d, _s, _k, f in rows))
        st.markdown("- [SIPRI — قاعدة صفقات السلاح (تصدير CSV)](https://armstransfers.sipri.org/ArmsTransfer/TransferRegister)")
        st.caption("الدومينات كتبتُها من معرفتي ولم أجرّبها كلها؛ إن لم يظهر مصدر في البحث فتحقق من دومينه.")

with tab_gd:
    use_filters("gd", "full")
    st.caption("بحث واسع في كل ما يرصده GDELT حسب بلد المصدر، دون تحديد مواقع بعينها.")
    scope = st.selectbox("المصادر", list(core.GLOBAL_SCOPES.keys()), key="gd_scope")
    if st.button("ابحث (GDELT عام)", type="primary", use_container_width=True, key="go_gd"):
        do_search("gd", core.GLOBAL_SCOPES[scope])
    render_results("gd")

COUNTRIES = {"كل الدول": None, "الولايات المتحدة": "US", "بريطانيا": "UK", "إسرائيل": "IS", "البرازيل": "BR", "البرتغال": "PO", "فرنسا": "FR", "إسبانيا": "SP"}

with tab_ml:
    query = ""
    st.caption(
        "ترجم كلماتك إلى عدة لغات، **عدّل أي ترجمة بيدك أو اكتبها بنفسك**، ثم ابحث بها. "
        "كل لغة تُبحث في المقالات المنشورة بها. التركية والفارسية والأمهرية تعرض ما تقوله تلك الدول بلسانها؛ تغطية GDELT لها أضعف، فإن لم تظهر نتائج فوسّع الفترة."
    )
    src_txt = st.text_input(
        "العبارة بالعربية", key="ml_src",
        help="افصل بين المواضيع بفاصلة.",
    )
    base_terms = [x.strip() for x in TERM_SPLIT.split(src_txt or query) if x.strip()]
    if st.button("🔤 ترجم إلى اللغات المختارة", use_container_width=True, key="ml_tr"):
        if not base_terms:
            st.warning("اكتب كلمة أو جملة بالعربية أولاً.")
        else:
            with st.spinner("جارٍ الترجمة…"):
                for code, _, _, _ in core.LANGS:
                    if st.session_state.get(f"ml_use_{code}", dict((c, d) for c, _, _, d in core.LANGS)[code]):
                        out, ok = core.translate_terms(base_terms, code)
                        st.session_state[f"ml_txt_{code}"] = "، ".join(out) if ok else ""
                        st.session_state[f"ml_fail_{code}"] = not ok
    chosen = []
    for code, name, gl, default in core.LANGS:
        c1_, c2_ = st.columns([1, 3])
        use = c1_.checkbox(name, value=default, key=f"ml_use_{code}")
        txt = c2_.text_input(f"الترجمة إلى {name}", key=f"ml_txt_{code}", label_visibility="collapsed",
                             placeholder=f"اكتب أو عدّل الترجمة ({name})")
        if st.session_state.get(f"ml_fail_{code}"):
            c2_.caption("⚠️ فشلت الترجمة الآلية — اكتبها بنفسك.")
        if use and txt.strip():
            chosen.append((code, gl, [x.strip() for x in TERM_SPLIT.split(txt) if x.strip()]))
    country_label = st.selectbox("حصر في مصادر بلد معيّن (اختياري)", list(COUNTRIES.keys()), key="ml_country")
    if st.button("ابحث بهذه الترجمات", type="primary", use_container_width=True, key="go_ml"):
        cc = COUNTRIES[country_label]
        jobs = [
            {"code": code, "extra": f"sourcelang:{gl}" + (f" sourcecountry:{cc}" if cc else ""), "terms": terms_}
            for code, gl, terms_ in chosen
        ]
        if not jobs:
            st.warning("اختر لغة واحدة على الأقل واكتب ترجمتها (اضغط «ترجم» أولاً).")
        else:
            do_search("ml", jobs, None, terms=base_terms or ["x"], pre=True)
    render_results("ml")



GROUP_LABELS = {"US": "🇺🇸 أمريكيون", "UK": "🇬🇧 بريطانيون", "IL": "🇮🇱 إسرائيليون", "SA": "🇸🇦 سعوديون (حسابات تويتر وغيرها)",
                "GCC": "🌍 خليجيون", "EG": "🇪🇬 مصريون", "AR": "🌍 عرب آخرون"}


def current_writers():
    return WRITERS + [writers_mod.W(**dict(sp, default=True)) for sp in S()["writers"]]


@st.cache_data(ttl=1800, show_spinner=False)
def cached_writers(ids, days, extra_json="[]"):
    allw = WRITERS + [writers_mod.W(**dict(sp, default=True)) for sp in json.loads(extra_json)]
    ws = [w for w in allw if w["id"] in ids]
    items, notes = core.fetch_writers(ws, days)
    return core.translate_titles(items), notes


def writers_panel(pfx, gcodes, btn_label, codes):
    """قائمة كتّاب لمجموعة جنسيات + زرها الخاص ونتائجها المستقلة (pfx يفصل بين الاجانب والعرب)"""
    days_label = st.selectbox("الفترة", list(DAY_OPTS.keys()), index=2, key=f"{pfx}_days")
    sel_ids = []
    all_w = current_writers()
    with st.expander("👥 اختيار الكُتّاب والمحللين", expanded=False):
        kinds = st.multiselect("تخصص الكاتب", ["رأي", "تحليل", "خبر"], default=["رأي", "تحليل", "خبر"],
                               key=f"{pfx}_writer_kinds", help="فلتر الكُتّاب حسب طبيعة إنتاجهم، وليس نوع المقال وحده.")
        for gcode in gcodes:
            gname = GROUP_LABELS[gcode]
            ws_ = [w for w in all_w if w["country"] == gcode and w.get("kind", "رأي") in kinds]
            if not ws_:
                continue
            label_to_id = {f"{w['name_ar']} — {w['outlet']} · {w.get('kind', 'رأي')}": w["id"] for w in ws_}
            picked = st.multiselect(
                gname, list(label_to_id), default=[l for l, i in label_to_id.items() if next(w for w in ws_ if w["id"] == i)["default"]],
                key=f"{pfx}_{gname}",
            )
            sel_ids += [label_to_id[p] for p in picked]
    st.caption(f"عدد الكُتّاب المختارين: {len(sel_ids)} من {sum(1 for w in all_w if w['country'] in gcodes)}")
    if pfx == "wa" and not sel_ids:
        st.info("لسه ما اضفتش كتّاب عرب. روح تاب «مصادري» ← «إضافة ككاتب» واكتب الاسم وحساب تويتر واختار الجنسية.")
    if pfx == "wa":
        links_ = [f"[🐦 @{w['twitter']}](https://x.com/{w['twitter']})" for w in all_w if w["id"] in sel_ids and w.get("twitter")]
        if links_:
            st.markdown("افتح حساباتهم على X مباشرة: " + " · ".join(links_))
    qm_w = st.radio("طريقة البحث", ["📰 اعرض آخر ما كتبوه (بدون كلمات بحث)", "🔎 اعرض بس اللي يذكر كلماتي (الخانة فوق)"],
                    horizontal=True, key=f"{pfx}_qm")
    use_kw = qm_w.startswith("🔎")
    if use_kw:
        st.caption("هيفحص نص كل مقال/تغريدة ويعرض بس اللي فيه كلماتك. اكتب الكلمات في خانة «🔎 كلمات البحث» اللي فوق. وده ابطأ.")
    else:
        st.caption("هيعرض كل ما نشروه في الفترة من غير ما تكتب كلمة، مرتب بالأحدث.")
    use_ctype = st.checkbox("طبّق فلتر «نوع المحتوى» (من الفلاتر فوق)", value=False, key=f"{pfx}_ct")
    if st.button(btn_label, type="primary", use_container_width=True, key=f"go_{pfx}"):
        if not sel_ids:
            st.warning("اختر كاتباً واحداً على الأقل.")
        else:
            with st.spinner("جارٍ جلب المقالات والتغريدات وترجمة العناوين…"):
                items, notes = cached_writers(
                    tuple(sorted(sel_ids)), DAY_OPTS[days_label], json.dumps(S()["writers"], ensure_ascii=False, sort_keys=True)
                )
                items = [dict(a) for a in items]
            kw_terms = [t_.strip() for t_ in TERM_SPLIT.split(query) if t_.strip()]
            if use_ctype and ctype != "الكل":
                items = [a for a in items if a.get("ctype") == ctype]
            matchers = []
            if use_kw and not kw_terms:
                st.warning("اكتب كلمات البحث في الخانة فوق، او غيّر الطريقة لـ «اعرض آخر ما كتبوه».")
            if use_kw and kw_terms and items:
                with st.spinner("جارٍ فحص النصوص…"):
                    matchers = core.make_matchers(kw_terms, codes)
                    if pfx == "wa":  # التغريدة نصها هو العنوان: نفحص العنوان بلا جلب صفحات
                        for a in items:
                            a["found"] = core.find_mentions(a.get("title", ""), matchers, joiner)[0]
                        items = [a for a in items if a["found"]]
                    else:
                        core.enrich_items(items, matchers, joiner, limit=60)
                        items = [a for a in items if not (a.get("fetched") and not a.get("found"))]
            counts = {}
            for a in items:
                counts[a["writer"]] = counts.get(a["writer"], 0) + 1
            chosen = [w["name_ar"] for w in all_w if w["id"] in sel_ids]
            hl = sorted({s_ for alts in matchers for stems in alts for s_ in stems}, key=len, reverse=True)
            st.session_state[f"res_{pfx}"] = {
                "items": items, "errors": [] if items else ["لم يُعثر على شيء — راجع «الاستعلام المُرسل فعلياً» لمعرفة ما جُرّب (وهل تويتر رد)."],
                "used": notes, "summaries": {}, "counts": counts,
                "silent": [n for n in chosen if n not in counts], "hidden": 0, "hl": hl,
            }
    render_results(pfx)


with tab_wr:
    use_filters("wr", "kw")
    st.caption(
        "أحدث مقالات الرأي والتحليل لكتّاب ومراسلين مهتمين بالشرق الأوسط، بعناوين مترجمة، وزر «ترجم المقال» لقراءة النص مترجماً. "
        "النتائج تُحفظ نصف ساعة، فالفتح المتكرر سريع."
    )
    sub_f, sub_a = st.tabs(["🌐 الكتّاب الأجانب", "🇸🇦 الكتّاب العرب (تويتر وغيره)"])
    with sub_f:
        writers_panel("wr", ["US", "UK", "IL"], "اعرض أحدث مقالات الكتّاب الأجانب", ["en", "iw"])
        st.caption("ℹ️ مواقع مثل نيويورك تايمز وواشنطن بوست وفاينانشال تايمز وهآرتس مدفوعة: يظهر عنوانها مترجماً، وقد يتعذّر عرض نصها الكامل.")
    with sub_a:
        st.caption("هنا الكتّاب العرب اللي ضفتهم (سعوديون وخليجيون ومصريون وغيرهم): آخر تغريداتهم ومقالاتهم باسمهم. "
                   "الإضافة من تاب «مصادري» ← «إضافة ككاتب». تويتر بيحجب الأدوات الآلية، فممكن التغريدات تتأخر أو متظهرش في بعض الأوقات.")
        writers_panel("wa", ["SA", "GCC", "EG", "AR"], "🐦 اعرض أحدث ما كتبه الكتّاب العرب", ["ar"])


def render_saved():
    s = S()
    if not PERSIST:
        st.warning(
            "💡 التخزين الدائم غير مفعّل: ما تحفظه هنا يضيع عند تحديث الصفحة أو إعادة تشغيل التطبيق. "
            "فعّله بخطوتين (الشرح في README: GITHUB_TOKEN و GIST_ID) أو نزّل نسخة احتياطية من الأسفل."
        )
    if st.session_state.get("store_err"):
        st.error(st.session_state["store_err"])
    c1, c2 = st.columns([2, 1])
    q = c1.text_input("🔎 ابحث داخل المحفوظات (عنوان، كاتب، موقع، ملاحظة)", key="sv_q")
    order = c2.selectbox("الترتيب", ["الأحدث حفظاً", "الأحدث نشراً", "الأقدم نشراً (خط زمني)"], key="sv_order")
    items = list(s["saved"])
    if q.strip():
        ql = q.strip().lower()
        items = [
            x for x in items
            if ql in " ".join(str(x.get(k, "")) for k in ("title_ar", "title", "writer", "domain", "note", "outlet")).lower()
        ]
    if order == "الأحدث نشراً":
        items.sort(key=lambda x: x.get("seendate", ""), reverse=True)
    elif order.startswith("الأقدم"):
        items.sort(key=lambda x: x.get("seendate", ""))
    with st.expander("🎙️ نشرة صوتية من المحفوظات (مثالية للمترو)"):
        labels = {f"{n + 1}. {x.get('title_ar', '')[:70]}": x for n, x in enumerate(s["saved"])}
        picked = st.multiselect("اختر المقالات (بالترتيب الذي تُقرأ به)", list(labels), default=list(labels)[:5], key="bl_pick")
        st.caption("تُقرأ حسب إعدادات «🎧 إعدادات القراءة الصوتية» فوق في التاب (الصوت والسرعة وما يُقرأ).")
        if st.button("🎙️ اصنع النشرة", key="bl_go", use_container_width=True):
            if not picked:
                st.warning("اختر مقالاً واحداً على الأقل.")
            else:
                ss = st.session_state
                prog = st.progress(0.0, text="جارٍ تجهيز النصوص…")
                parts = []
                for n, lab in enumerate(picked):
                    x = labels[lab]
                    txt, _ = speech_text(x["url"], x.get("title_ar", ""), ss.get("tts_mode", TTS_MODES[0]))
                    num = ORDINALS[n] if n < len(ORDINALS) else str(n + 1)
                    parts.append(f"الخبر {num}. من {_ar_name(source_name(x.get('domain', '')))}، {source_country(x.get('domain', ''))}. {txt}")
                    prog.progress((n + 1) / (len(picked) + 1), text=f"جُهّز {n + 1} من {len(picked)}")
                full = "نشرة رادار الأخبار. " + " ... ".join(parts) + " ... انتهت النشرة."
                prog.progress(0.95, text=f"جارٍ النطق (حوالي {len(full) / 13 / 60:.0f} دقيقة صوت)…")
                res = make_audio(full, core.VOICES[ss.get("tts_voice", list(core.VOICES)[0])], ss.get("tts_rate", 0))
                prog.empty()
                if res:
                    ss["bulletin"] = res
        if st.session_state.get("bulletin"):
            audio_block(st.session_state["bulletin"], "bulletin", "marsad_bulletin")
    st.caption(f"عدد المحفوظات: {len(s['saved'])}" + (f" — المعروض: {len(items)}" if q.strip() else ""))
    sums = st.session_state.setdefault("sv_sum", {})
    for it in items:
        h = hashlib.md5(it["url"].encode()).hexdigest()[:10]
        with st.container(border=True):
            st.markdown(card_html(it) + snippet_html(it, []), unsafe_allow_html=True)
            try:
                when = datetime.fromisoformat(it.get("saved_at", "")).astimezone(core.TZ).strftime("%Y-%m-%d %H:%M")
                st.caption(f"📌 حُفظ: {when}")
            except Exception:
                pass
            st.text_area(
                "📝 ملاحظتي (لربط الأحداث ببعضها)", value=it.get("note", ""), key=f"note_{h}", height=80,
                on_change=set_note, args=(it["url"], f"note_{h}"),
            )
            b1, b2 = st.columns(2)
            if b1.button("📝 ملخص سريع للمقال", key=f"svsum_{h}"):
                with st.spinner("جارٍ التلخيص…"):
                    sums[it["url"]] = core.summarize(it["url"])
            b2.button("🗑️ حذف من المحفوظات", key=f"del_{h}", on_click=delete_item, args=(it["url"],))
            listen_widget(it, f"sv_{h}")
            if it["url"] in sums:
                st.info(sums[it["url"]])
    with st.expander("💾 نسخة احتياطية (تنزيل / استيراد) — تشمل المحفوظات والمصادر والكتّاب المضافين"):
        st.download_button(
            "⬇️ تنزيل كل بياناتي (JSON)", data=json.dumps(s, ensure_ascii=False, indent=1),
            file_name="marsad_backup.json", mime="application/json",
        )
        up = st.file_uploader("⬆️ استيراد نسخة احتياطية", type=["json"], key="sv_up")
        if up is not None and st.session_state.get("sv_up_done") != (up.name, up.size):
            try:
                st.session_state["store"] = store.merge(s, json.loads(up.getvalue().decode("utf-8")))
                persist()
                st.session_state["sv_up_done"] = (up.name, up.size)
                st.rerun()
            except ValueError:
                st.error("الملف ليس نسخة احتياطية صالحة.")
        if PERSIST and st.button("🔄 تحديث من التخزين الدائم (لو حفظت من جهاز آخر)", key="sv_reload"):
            try:
                st.session_state["store"] = store.load(GH_TOKEN, GH_GIST)
                st.rerun()
            except Exception as e:
                st.error(f"تعذّر التحديث ({type(e).__name__})")


def render_manage():
    if st.session_state.get("flash"):
        st.success(st.session_state.pop("flash"))
    st.markdown("### 🔗 أضف مصدراً أو كاتباً من رابط")
    st.caption(
        "الصق رابط خبر، أو رابط تغريدة (تويتر/X)، أو منشور/صفحة فيسبوك تحوي رابط مقال، وسيستخرج التطبيق الموقع والكاتب لتضيفهما بضغطة. "
        "يمكنك أيضاً تعبئة الخانات يدوياً."
    )
    st.text_input("رابط الخبر أو التغريدة", key="ms_url", placeholder="https://...")
    st.button("🔍 حلّل الرابط", on_click=do_analyze, use_container_width=True, key="ms_an")
    an = st.session_state.get("analysis")
    if an:
        if an.get("error"):
            st.warning(an["error"])
        tw = an.get("tweet")
        if tw:
            st.info(f"🐦 تغريدة {tw.get('author', '')} (@{tw.get('handle', '')}): {tw.get('text', '')}")
        if an.get("domain"):
            st.markdown(f"**الموقع:** {an.get('site_name')} (`{an['domain']}`)  \n**العنوان:** {an.get('title', '')}")
        if an.get("authors"):
            st.selectbox("الكتّاب المكتشفون (اختر لتعبئة بياناته)", [a["raw"] for a in an["authors"]], key="mw_pick", on_change=pick_author)
    st.markdown("#### ➕ إضافة كمصدر إخباري")
    st.text_input("اسم المصدر", key="ms_name")
    st.text_input("الدومين (مثال: example.com)", key="ms_domain")
    st.radio("يُضاف إلى تاب", ["إسرائيلية", "أمريكية", "بريطانية", "تركيا/إيران/إثيوبيا"], key="ms_group", horizontal=True)
    st.radio("لغة المصدر", ["إنجليزي", "عبري", "كلاهما", "تركي", "فارسي", "أمهري", "عربي"], key="ms_lang", horizontal=True)
    st.button("➕ أضف المصدر", on_click=add_source, use_container_width=True, key="ms_add")
    st.markdown("#### ➕ إضافة ككاتب")
    st.caption("للكاتب العربي من تويتر: اكتب اسمه بالعربي + حسابه (@name) + اختار الجنسية «سعودي» او «خليجي»... ومش لازم دومين. "
               "للكاتب الاجنبي: اسمه بالانجليزي + دومين موقع النشر.")
    st.text_input("الاسم بالعربية (للعرض والبحث)", key="mw_ar")
    st.text_input("حساب تويتر/X (مثال: @alfihrest او رابط الحساب)", key="mw_tw", placeholder="@alfihrest")
    st.text_input("اسم الكاتب بالإنجليزية (للكاتب الاجنبي، او اختياري)", key="mw_en")
    st.text_input("المنفذ / الصحيفة (اختياري)", key="mw_outlet")
    st.text_input("مواقع نشره (اختياري للعربي — دومين او اكتر بفاصلة)", key="mw_sites")
    st.text_input("الاسم بالعبرية (اختياري — لمواقع عبرية)", key="mw_heb")
    st.radio("جنسية الكاتب / المنفذ", ["سعودي", "خليجي", "مصري", "عربي آخر", "أمريكي", "بريطاني", "إسرائيلي"], key="mw_country", horizontal=True)
    st.radio("نوع كتاباته", ["رأي", "تحليل", "خبر"], key="mw_kind", horizontal=True)
    st.button("➕ أضف الكاتب", on_click=add_writer, use_container_width=True, key="mw_add")
    if st.session_state.get("mw_msg"):
        (st.success if st.session_state["mw_msg"].startswith("✅") else st.warning)(st.session_state["mw_msg"])
    st.markdown("#### ما أضفتَه")
    if not S()["sources"] and not S()["writers"]:
        st.caption("لم تضف شيئاً بعد.")
    for x in S()["sources"]:
        r1, r2 = st.columns([4, 1])
        r1.markdown(f"🌐 **{x['label']}** — `{x['domain']}` — تاب: {x['group']} — لغة: {x['lang']}")
        r2.button("حذف", key=f"rs_{x['domain']}_{x['group']}", on_click=remove_source, args=(x["domain"], x["group"]))
    for w in S()["writers"]:
        r1, r2 = st.columns([4, 1])
        r1.markdown(f"✍️ **{w['name_ar']}** ({w['name_en']}) — {w['outlet']} — `{', '.join(w['sites'])}`" + (f" — 🐦 @{w['twitter']}" if w.get("twitter") else ""))
        r2.button("حذف", key=f"rw_{w['id']}", on_click=remove_writer, args=(w["id"],))
    if not PERSIST:
        st.caption("⚠️ بدون التخزين الدائم تضيع هذه الإضافات عند تحديث الصفحة؛ نزّل نسخة احتياطية من تاب «المحفوظات».")


def render_keys_admin():
    st.markdown("#### 🔑 شفرات التجربة (للمالك فقط)")
    if not GATE_ON:
        st.info("البوابة غير مفعّلة. لتفعيلها أضف في Secrets قيمة **ADMIN_KEY** (كلمة سر طويلة تخصّك) إلى جانب GITHUB_TOKEN وGIST_ID، "
                "ثم أعد تشغيل التطبيق. بعد التفعيل لن يفتح التطبيق إلا بشفرة، وتدخل أنت بكلمة ADMIN_KEY.")
        return
    def _host_url():
        try:
            h = st.context.headers.get("Host", "")
            return f"https://{h}" if h and not h.startswith(("localhost", "127.")) else ""
        except Exception:
            return ""

    base = (_sec("APP_URL") or _host_url() or st.session_state.get("app_url", "")).strip().rstrip("/")
    if not base:
        base = st.text_input("رابط التطبيق (اكتبه مرة واحدة)", placeholder="https://اسم-تطبيقك.streamlit.app", key="app_url").strip().rstrip("/")
    c1, c2 = st.columns(2)
    label = c1.text_input("اسم الشخص / الجهة (لتعرف لمن أعطيتها)", key="k_label")
    durs = {"6 ساعات": 6, "يوم": 24, "3 أيام": 72, "أسبوع": 168, "أسبوعان": 336, "شهر": 720, "مدة أخرى (بالساعات)": 0}
    dur = c2.selectbox("مدة التجربة (تبدأ من أول فتح)", list(durs), index=3, key="k_dur")
    scope_lbl = c1.selectbox("الصلاحية", ["كاملة (كل التطبيق)", "تقرير يومي فقط (اشتراك)"], key="k_scope")
    hours = durs[dur] or st.number_input("عدد الساعات", min_value=1, max_value=24 * 365, value=48, key="k_hours")
    if st.button("➕ ولّد شفرة جديدة", type="primary", key="k_new"):
        try:
            _, k = keys_mod.mutate(_GT, _GG, lambda ks: keys_mod.create(ks, label, hours, "reports" if scope_lbl.startswith("تقرير") else "full"))
            st.session_state["k_last"] = k["code"]
        except Exception as e:
            st.error(f"تعذّر الحفظ ({type(e).__name__}).")
    try:
        ks = store.load(_GT, _GG)["keys"]
    except Exception as e:
        st.error(f"تعذّر تحميل الشفرات ({type(e).__name__}).")
        return
    def link(c):
        return f"{base}/?k={c}" if base else f"?k={c}"
    if st.session_state.get("k_last"):
        st.success("تم التوليد. انسخ الرابط وأرسله:")
        st.code(link(st.session_state["k_last"]), language=None)
    icons = {"active": "🟢 فعّالة", "unused": "🟡 لم تُفتح", "expired": "⚪ انتهت", "revoked": "🔴 ملغاة", "unused_expired": "⚪ سقطت (لم تُفتح)"}
    for k in sorted(ks, key=lambda x: x.get("created", ""), reverse=True):
        stt = keys_mod.status(k)
        with st.container(border=True):
            seen = keys_mod.parse(k.get("last_seen"))
            seen_txt = seen.astimezone(core.TZ).strftime("%m-%d %H:%M") if seen else "—"
            st.markdown(f"**{k.get('label', '')}** — {icons.get(stt, stt)} — {keys_mod.human_left(k)}  \n"
                        f"{'📰 تقرير فقط' if k.get('scope') == 'reports' else 'صلاحية كاملة'} · فتحها {k.get('visits', 0)} مرة · آخر دخول: {seen_txt} (القاهرة) · المدة: {int(k.get('hours', 0))} ساعة")
            st.code(link(k["code"]), language=None)
            b1, b2 = st.columns(2)
            if stt in ("active", "unused") and b1.button("⛔ إلغاء الآن", key=f"krv_{k['code']}"):
                keys_mod.mutate(_GT, _GG, lambda ks_, c=k["code"]: keys_mod.find(ks_, c).update(revoked=True))
                st.rerun()
            if b2.button("🗑️ حذف من القائمة", key=f"kdl_{k['code']}"):
                keys_mod.mutate(_GT, _GG, lambda ks_, c=k["code"]: ks_.remove(keys_mod.find(ks_, c)))
                st.rerun()
    st.caption("ملاحظة: الضيف لا يرى محفوظاتك ولا مصادرك المضافة، وما يحفظه يزول بإغلاق الصفحة. الإلغاء يسري خلال ~10 دقائق على من هو داخل التطبيق.")


WATCH_SCOPES = {"il": "🇮🇱 اسرائيلي", "us": "🇺🇸 امريكي", "uk": "🇬🇧 بريطاني", "ar": "🇪🇬 عربي", "rg": "🌍 تركيا وايران واثيوبيا"}
WATCH_CFG, WATCH_OUT = "marsad_watch_cfg.json", "marsad_watch.json"


def _watch_load(force=False):
    if not (GH_TOKEN and GH_GIST):
        return None, {}
    if force or "watch_data" not in st.session_state or time.time() - st.session_state.get("watch_t", 0) > 300:
        try:
            st.session_state["watch_data"] = store.load_file(GH_TOKEN, GH_GIST, WATCH_OUT, None)
            st.session_state["watch_cfg"] = store.load_file(GH_TOKEN, GH_GIST, WATCH_CFG, {}) or {}
        except Exception as ex:
            st.error(f"تعذّر قراءة التقرير المحفوظ ({type(ex).__name__}).")
            return st.session_state.get("watch_data"), st.session_state.get("watch_cfg", {})
        st.session_state["watch_t"] = time.time()
    return st.session_state.get("watch_data"), st.session_state.get("watch_cfg", {})


@st.cache_data(ttl=86400, show_spinner=False)
def _tr_cached(p):
    r = tr(p, "auto", "ar")
    return r if core._HAS_AR.search(r) else p


def _watch_done_toggle(url):
    cfg = st.session_state.get("watch_cfg", {})
    done = set(cfg.get("done") or [])
    (done.discard if url in done else done.add)(url)
    cfg["done"] = sorted(done)
    st.session_state["watch_cfg"] = cfg
    try:
        store.save_file(GH_TOKEN, GH_GIST, WATCH_CFG, cfg)
    except Exception as ex:
        st.session_state["watch_err"] = f"تعذّر حفظ علامة «خلصته» ({type(ex).__name__})"


def render_watch():
    """تقرير مخصص بالكلمات والعلاقات: زر واحد يشغّله على GitHub Actions، والنتيجة محفوظة (للمالك)"""
    with st.expander("🎯 تقرير مخصص بكلمات ومواضيع معينة (زرار واحد، والنتيجة بتفضل محفوظة)", expanded=False):
        if not (GH_TOKEN and GH_GIST):
            st.info("محتاج التخزين الدائم (GITHUB_TOKEN وGIST_ID).")
            return
        data, cfg = _watch_load()
        tok, repo, branch = _sec("ACTIONS_TOKEN"), _sec("GH_REPO") or gh_actions.DEFAULT_REPO, _sec("GH_BRANCH") or "main"
        st.caption("اكتب مواضيعك، دوس زرار «شغّل»، وسيبه يشتغل على GitHub (ممكن ياخد من ربع ساعة لساعة، مش لازم تفضل فاتح التطبيق). "
                   "لما يخلص هتلاقي كل الاخبار هنا: ترجمة العنوان والمقال والملخص وعدد مرات ذكر الكلمات. وبتفضل محفوظة لحد ما تشغّل بحث جديد.")
        with st.expander("⚙️ المواضيع والاعدادات", expanded=data is None):
            txt = st.text_area("المواضيع (سطر لكل موضوع. + يعني الكلمتين مع بعض، | يعني بدائل، # تعليق)", height=280, key="watch_txt",
                               value=cfg.get("topics") or watch_mod.DEFAULT_TOPICS)
            c1, c2, c3 = st.columns(3)
            wdays = pick(c1, "الفترة (ايام)", [1, 2, 3, 4], int(cfg.get("days") or 2), "watch_days")
            per = pick(c2, "اخبار لكل موضوع", range(3, 21), int(cfg.get("per") or 10), "watch_per")
            deep = pick(c3, "اقرا وترجم اول كام خبر", range(0, 11), int(cfg["deep"]) if cfg.get("deep") is not None else 5, "watch_deep")
            keys_sel = st.multiselect("ادور في ايه؟", list(WATCH_SCOPES), default=[k for k in (cfg.get("scopes") or list(WATCH_SCOPES)) if k in WATCH_SCOPES],
                                      format_func=lambda k: WATCH_SCOPES[k], key="watch_scopes")
        if not tok:
            st.warning("زرار التشغيل محتاج ACTIONS_TOKEN في Secrets (نفس اللي عملناه للتقرير اليومي).")
        lr = None
        if tok:
            try:
                lr = gh_actions.last_run(tok, repo, "watch.yml")
            except Exception as ex:
                st.caption(f"تعذّر قراءة حالة التشغيل ({type(ex).__name__}). اتأكد انك رفعت ملف watch.yml.")
        busy = bool(lr and lr["status"] in ("queued", "in_progress", "waiting", "requested"))
        if lr:
            ico = {"success": "✅ خلص", "failure": "❌ فشل", "cancelled": "⚪ اتلغى"}.get(lr["conclusion"] or "", "⏳ شغال دلوقتي" if busy else "—")
            when = keys_mod.parse(lr["created"])
            wt = when.astimezone(core.TZ).strftime("%Y-%m-%d %H:%M") if when else ""
            upd = keys_mod.parse(lr.get("updated"))
            ut = upd.astimezone(core.TZ).strftime("%H:%M") if upd else ""
            st.markdown(f"آخر تشغيل: **{ico}** — بدأ {wt} (القاهرة)" + (f" · آخر نشاط {ut}" if busy else f" · انتهى {ut}") + f" · [افتح التفاصيل على GitHub]({lr['url']})")
        elif tok:
            st.markdown("آخر تشغيل: **لسه مفيش** (لو لسه دايس من ثواني دوس «حدّث» تحت)")
        if tok:
            st.markdown(f"[📂 صفحة التقرير المخصص على GitHub](https://github.com/{repo}/actions/workflows/watch.yml)")
        if st.session_state.get("watch_msg"):
            st.success(st.session_state["watch_msg"])
        b1, b2 = st.columns(2)
        if b1.button("▶️ شغّل البحث الكبير دلوقتي", type="primary", disabled=busy or not tok, key="watch_go", use_container_width=True):
            ts = watch_mod.parse_topics(txt)
            if not ts or not keys_sel:
                st.warning("اكتب موضوع واحد على الاقل واختار قسم واحد.")
            else:
                new_cfg = {**cfg, "topics": txt, "days": wdays, "per": per, "deep": deep, "scopes": keys_sel}
                try:
                    store.save_file(GH_TOKEN, GH_GIST, WATCH_CFG, new_cfg)
                    st.session_state["watch_cfg"] = new_cfg
                    ok, msg = gh_actions.dispatch(tok, repo, branch, "watch.yml")
                    if ok:
                        time.sleep(4)
                        st.session_state["watch_msg"] = f"✅ اتبعت الامر لـ GitHub الساعة {datetime.now(core.TZ).strftime('%H:%M')}. " + msg + " ولما يخلص دوس «حدّث»."
                        st.rerun()
                    st.error(msg)
                except Exception as ex:
                    st.error(f"مقدرتش ابدأ ({type(ex).__name__}).")
        if b2.button("🔁 حدّث (هات اخر نتيجة)", key="watch_refresh", use_container_width=True):
            st.session_state.pop("watch_msg", None)
            _watch_load(force=True)
            st.rerun()
        if st.session_state.pop("watch_err", None):
            st.warning("علامة «خلصته» ما اتحفظتش في المرة الاخيرة.")
        if not data:
            st.info("لسه مفيش نتيجة محفوظة. دوس «شغّل» وبعد ما يخلص دوس «حدّث». (اخر تحديث للنتيجة: لسه مفيش)")
            return
        done = set(cfg.get("done") or [])
        created = keys_mod.parse(data.get("created"))
        ct = created.astimezone(core.TZ).strftime("%Y-%m-%d %H:%M") if created else ""
        st.markdown(f"### النتيجة المحفوظة — اتعملت {ct} (القاهرة) · اخر {data.get('days')} يوم")
        if not data.get("done", True):
            st.warning("ده تقرير مبدئي: الروابط والعناوين جاهزة، والمقالات المترجمة والملخصات لسه بتتجهز. دوس «حدّث» بعد شوية.")
        st.caption(f"اتفحص {data.get('n_sources')} موقع، وقريت {data.get('n_pool')} عنوان مباشرة.")
        scope_names = data.get("scope_names") or []
        f1, f2, f3 = st.columns([2, 2, 1])
        scope_f = f1.selectbox("القسم", ["الكل"] + scope_names, key="watch_f_scope")
        topic_f = f2.selectbox("الموضوع", ["الكل"] + [t["title"] for t in data["topics"]], key="watch_f_topic")
        hide_done = f3.checkbox("اخفي اللي خلصته", value=False, key="watch_f_done")
        shown = 0
        for t in data["topics"]:
            if topic_f != "الكل" and t["title"] != topic_f:
                continue
            items = [a for a in t["items"] if (scope_f == "الكل" or scope_f in (a.get("scopes") or [])) and not (hide_done and a["url"] in done)]
            if not items and topic_f == "الكل":
                continue
            with st.expander(f"{t['title']} — {len(items)} خبر", expanded=topic_f != "الكل"):
                for i, a in enumerate(items):
                    shown += 1
                    ttl = (a.get("title_ar") or a.get("title") or "").replace("[", "(").replace("]", ")")
                    mark = "✅ " if a["url"] in done else ""
                    st.markdown(f"**{mark}[{ttl}]({a['url']})**  \n{source_name(a.get('domain', ''))} · {fmt_seen(a.get('seendate', ''))}")
                    if a.get("fetched") and a.get("mcount") is not None:
                        st.caption(f"الكلمات اتذكرت {a['mcount']} مرة في مقال حوالي {a.get('words', 0)} كلمة — مستوى: {a.get('mlevel', '')}" + (f" — اتجاب بـ: {a['via']}" if a.get("via") else ""))
                    for p in a.get("points_ar", []):
                        st.markdown(f"- {p if core._HAS_AR.search(p) else _tr_cached(p)}")
                    rl = f"?view={quote(a['url'], safe='')}&seen={a.get('seendate', '')}&t={quote(a.get('title', '')[:200], safe='')}{auth_qs()}"
                    st.markdown(f"[📖 افتح المقال مترجم]({rl})")
                    if a.get("full_ar"):
                        with st.expander("المقال مترجم (اول جزء)"):
                            st.write(a["full_ar"])
                    st.checkbox("خلصته", value=a["url"] in done, key=f"wd_{t['title']}_{i}_{abs(hash(a['url']))}",
                                on_change=_watch_done_toggle, args=(a["url"],))
        if not shown:
            st.caption("مفيش اخبار بالفلاتر دي.")
        if data.get("overlap"):
            with st.expander("🔗 اخبار تخص اكتر من موضوع"):
                for a, ts in data["overlap"]:
                    ttl = (a.get("title_ar") or a.get("title") or "").replace("[", "(").replace("]", ")")
                    st.markdown(f"- [{ttl}]({a['url']}) ⟵ {' | '.join(ts)}")
        with st.expander("ملاحظات فنية"):
            for n in (data.get("notes") or [])[:40]:
                st.caption(n)
        md = watch_mod.to_markdown(data, source_name, fmt_seen)
        st.download_button("⬇️ نزّل التقرير (ملف نصي)", md, file_name="custom_report.md", key="watch_dl")
        with st.expander("📋 نسخ التقرير كنص (تلصقه عند اي ذكاء اصطناعي)"):
            st.code(md, language=None)


# ───────── 🧵 الملفات والخيوط: ربط كل الأخبار في ملفات وخيوط + منشورات فيس وتويتر + برومبت تحليل جاهز ─────────
DOS_RES_FILE, DOS_CFG_FILE = "marsad_dossiers.json", "marsad_dossiers_cfg.json"
TOPIC_CFG, TOPIC_STATUS = "marsad_topic_cfg.json", "marsad_topic_job.json"
EG_TABS = {"eg", "egt"}  # تابات الشأن المصري: نتايجها بتروح لربط الشأن المصري بس، ومبتتخلطش بالسياسة الإقليمية
PROFS = {"pol": {"sx": "", "cfg_file": DOS_CFG_FILE, "res_file": DOS_RES_FILE, "cfg_key": "dos_cfg", "res_key": "dos_res"},
         "eg": {"sx": "_eg", "cfg_file": "marsad_dossiers_eg_cfg.json", "res_file": "marsad_dossiers_eg.json", "cfg_key": "dos_cfg_eg", "res_key": "dos_res_eg"}}
TAB_LABELS = {"il": "الإسرائيلية", "us": "الأمريكية", "uk": "البريطانية", "rg": "تركيا وإيران وإثيوبيا", "eg": "الشأن المصري", "egt": "تتبّع موضوع", "trend": "ترند/موضوع طارئ", "ml": "ترجمة ثم بحث",
              "wr": "الكتّاب", "gd": "GDELT", "br": "تصفّح مصدر", "in": "مكتب الاستخبارات",
              "in_all": "مكتب الاستخبارات", "home": "البحث السريع"}
DOS_HELP = """
**الفكرة:** التبويب ده مش بيدور على أخبار جديدة بنفسه. هو بيرتب الأخبار اللي التطبيق جابها قبل كده، زي واحد بيرتب الجرايد اللي على الترابيزة في ملفات.

**1️⃣ جهّز الأخبار (مش لازم كلها):**
- **🚀 الأسرع:** افتح «بحث شامل في كل المصادر مرة واحدة»، اكتب كلماتك (أو سيبها فاضية)، اختار الفترة، ودوس الزرار. GitHub بيدور في كل المصادر لوحده، ولما يخلص دوس «حدّث وحمّل النتايج». هتلاقي نتيجة كل تاب جواه زي ما هي، وكلها داخلة في الربط، وبتفضل لحد ما تبحث تاني.
- **أسهل حاجة:** ما تعملش حاجة. التقرير اليومي بيتعمل لوحده كل صبح، والتبويب بياخد آخر 7 أيام منه.
- **بحثك في المصادر:** ابحث في أي تاب (أمريكية، بريطانية، إسرائيلية، تركيا وإيران...). كل نتيجة بتتحفظ لوحدها في **أرشيف البحث** (العداد اللي تحت)، حتى لو عملت بحث تاني أو قفلت التطبيق.
- **موضوع معين بعمق:** تاب «التقرير اليومي» ← «🎯 تقرير مخصص» ← اكتب المواضيع (زي `إيران + أمريكا`) ← «شغّل». بياخد من ربع ساعة لساعة على GitHub.
- **خبر عجبك:** احفظه في المحفوظات، وهو كمان بيدخل.
- **تحركات أمريكا وتصريحات ترامب:** ملف جاهز بالروابط بيدخل لوحده (فيه الحرب الأمريكية الإيرانية وأوكرانيا والسودان والقرن الأفريقي).
- **📅 مدة الأخبار:** من 6 ساعات لحد 30 يوم (الافتراضي 7 أيام)، وأي خبر أقدم بيتشال.
- **🔗 اللينكات:** تختار تفتح الصفحة الأصلية (للتصوير) أو صفحة الترجمة، وجنب كل خبر لينك للتاني.
- **ملحوظة:** لو النتيجة المعروضة قديمة، دوس «اربط واعرض» تاني عشان تتحدّث بالفترة اللي اخترتها.

**2️⃣ لو فيه ترند على فيس أو تويتر:** افتح «💬 منشورات فيس وتويتر»، الصق المنشور، ودوس «➕ أضف». المنشورات بتتعامل كادعاءات مش حقايق.

**3️⃣ دوس الزرار الأحمر «🔗 اربط واعرض الملفات والخيوط»** وسيب الأرقام زي ما هي.

**4️⃣ اختار ملف** من «📁 الملفات» (زي «الحرب الأمريكية الإيرانية»). جوه كل ملف: العناصر، والزاوية الأمريكية، و«🤖 برومبت التحليل».

**5️⃣ في «🤖 برومبت التحليل»:** اختار «🎬 اسكريبت 1» أو «اسكريبت 2» أو «🧭 اسكريبت 3» اللي بيطلّع قراءتك للمشهد (جرّب وشوف الأحسن) وحدد المدة، ودوس علامة النسخ، والصقه في شات Claude. هيرجعلك اسكريبت طويل بعامية قاهرية: هوك قاتل في أول 5 ثواني، وأفيهات سودا، وفكّ للمشهد وربط أمريكا وإيران وإسرائيل واليمن ومصر والسعودية ببعض، وأسئلة للمتابع كل نص دقيقة. ولو عايز تحليل مكتوب بس اختار «🧠 تحليل بس».

**نصيحة:** ابعت ملف واحد في المرة عشان التحليل يطلع مركز. ولو عايز كل حاجة، نزّل «⬇️ التقرير كامل» من تحت خالص.
"""
POST_PLATFORMS = ["فيسبوك", "تويتر / X", "تيك توك", "يوتيوب", "تليجرام", "تاني"]


def _dos_cfg_text(P="pol"):
    ss, pf = st.session_state, PROFS[P]
    if pf["cfg_key"] not in ss:
        txt = None
        if PERSIST:
            try:
                txt = (store.load_file(GH_TOKEN, GH_GIST, pf["cfg_file"], {}) or {}).get("text")
            except Exception:
                txt = None
        ss[pf["cfg_key"]] = txt or (dossiers_mod.egypt_config_text() if P == "eg" else dossiers_mod.default_config_text())
    return ss[pf["cfg_key"]]


def _dos_save_cfg(text, P="pol"):
    pf = PROFS[P]
    st.session_state[pf["cfg_key"]] = text
    st.session_state.pop("dos_cfg_edit" + pf["sx"], None)  # عشان مربع التعديل يعرض النسخة الجديدة
    if PERSIST:
        try:
            store.save_file(GH_TOKEN, GH_GIST, pf["cfg_file"], {"text": text})
        except Exception as e:
            st.session_state["dos_msg"] = f"⚠️ اتغيرت الملفات بس ما اتحفظتش في التخزين الدائم ({type(e).__name__})"


def _dos_result(P="pol"):
    ss, pf = st.session_state, PROFS[P]
    if pf["res_key"] not in ss:
        ss[pf["res_key"]] = None
        if PERSIST:
            try:
                ss[pf["res_key"]] = store.load_file(GH_TOKEN, GH_GIST, pf["res_file"], None)
            except Exception:
                pass
    return ss[pf["res_key"]]


DOS_POOL_FILE = "marsad_dos_pool.json"
DOS_PREFS_FILE = "marsad_dos_prefs.json"


def _dos_prefs():
    """آخر اختياراتك في تاب الخيوط (الفترة والربط واللينك)، بتتحفظ عشان تلاقيها زي ما سبتها على الموبايل والكمبيوتر"""
    ss = st.session_state
    if "dos_prefs" not in ss:
        ss["dos_prefs"] = {}
        if PERSIST:
            try:
                ss["dos_prefs"] = store.load_file(GH_TOKEN, GH_GIST, DOS_PREFS_FILE, {}) or {}
            except Exception:
                pass
    return ss["dos_prefs"]


def _dos_save_prefs(P, cur):
    prefs = _dos_prefs()
    if prefs.get(P) == cur:
        return
    prefs[P] = cur
    if PERSIST:
        try:
            store.save_file(GH_TOKEN, GH_GIST, DOS_PREFS_FILE, prefs)
        except Exception:
            pass
POOL_KEYS = ["url", "title", "title_ar", "title_en", "seendate", "domain", "country_ar", "snip_ar", "outlet"]


def _dos_pool():
    """أرشيف البحث: كل نتيجة بحث بتعملها في أي تاب بتتحفظ هنا تلقائياً (آخر 21 يوم)، عشان تدخل في الربط حتى لو بحثت تاني أو قفلت"""
    ss = st.session_state
    if "dos_pool" not in ss:
        ss["dos_pool"] = {}
        if PERSIST:
            try:
                ss["dos_pool"] = store.load_file(GH_TOKEN, GH_GIST, DOS_POOL_FILE, {}) or {}
            except Exception:
                pass
    pool, added = ss["dos_pool"], 0
    now = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    for k, v in list(ss.items()):
        if not (k.startswith("res_") and isinstance(v, dict)) or v.get("partial"):
            continue
        for a in v.get("items") or []:
            if not (isinstance(a, dict) and a.get("url")):
                continue
            if a["url"] not in pool:
                pool[a["url"]] = {**{f: a[f] for f in POOL_KEYS if a.get(f)}, "pooled": now, "tab": k[4:], "tabs": [k[4:]]}
                added += 1
            else:
                tl = pool[a["url"]].setdefault("tabs", [pool[a["url"]].get("tab", "")])
                if k[4:] not in tl:
                    tl.append(k[4:])
                    added += 1
    if added:
        cut = (datetime.now(timezone.utc) - timedelta(days=21)).strftime("%Y%m%d")
        keep = sorted(pool.values(), key=lambda a: a.get("pooled", ""), reverse=True)
        keep = [a for a in keep if (a.get("seendate") or a.get("pooled", ""))[:8] >= cut][:3000]
        ss["dos_pool"] = pool = {a["url"]: a for a in keep}
        if PERSIST:
            try:
                store.save_file(GH_TOKEN, GH_GIST, DOS_POOL_FILE, pool)
            except Exception:
                pass
    return pool


def _pool_for(P):
    """أخبار الأرشيف بتاعة القسم ده بس: الشأن المصري لوحده، والسياسة الإقليمية لوحدها"""
    out = []
    for a in _dos_pool().values():
        tabs = set(a.get("tabs") or [a.get("tab", "")])
        if (P == "eg" and tabs & EG_TABS) or (P != "eg" and tabs - EG_TABS):
            out.append(a)
    return out


def _dos_collect(use, uploads, P="pol"):
    """يجمع الأخبار من كل الأماكن اللي اخترتها في التطبيق"""
    lab = lambda d: about_plain(re.sub(r"<[^>]+>", "", html.unescape(src_label(d, with_domain=False))).split("·")[0])
    out, counts = [], {}

    def add(items, origin):
        n = 0
        for a in items or []:
            if isinstance(a, dict) and a.get("url") and (a.get("title") or a.get("title_ar")):
                out.append(dossiers_mod.from_app_item(a, lab, source_country, origin))
                n += 1
        counts[origin] = counts.get(origin, 0) + n

    if "بحث" in use:
        add(_pool_for(P), "نتايج البحث")
    if P == "eg":
        use = [u for u in use if u == "بحث"]
    if "يومي" in use and _GT and _GG:
        try:
            if "reports" not in st.session_state:
                st.session_state["reports"] = store.load_reports(_GT, _GG)
                st.session_state["reports_t"] = time.time()
            for rep in (st.session_state["reports"].get("archive") or {}).values():
                for f in (rep.get("files") or {}).values():
                    add(f.get("items"), "التقرير اليومي")
        except Exception as e:
            st.warning(f"تعذّر تحميل التقارير اليومية ({type(e).__name__})")
    if "مخصص" in use and GH_TOKEN and GH_GIST:
        data, _cfg = _watch_load()
        for t in (data or {}).get("topics") or []:
            add(t.get("items"), "التقرير المخصص")
    if "محفوظات" in use:
        add(S()["saved"], "المحفوظات")
    if "أمريكا" in use:
        us = dossiers_mod.us_moves_items()
        out += us
        counts["تحركات أمريكا"] = len(us)
    for up in uploads or []:
        try:
            got = dossiers_mod.items_from_csv(up.getvalue(), f"ملف: {up.name}")
            out += got
            counts[f"ملف: {up.name}"] = len(got)
        except Exception as e:
            st.warning(f"الملف {up.name} مش مقروء: {e}")
    posts = [dossiers_mod.from_post(p) for p in S().get("posts", []) if (p.get("scope") or "pol") == P]
    out += posts
    counts["منشورات فيس وتويتر"] = len(posts)
    return out, counts


def _dos_item_md(it):
    ttl = (it.get("title") or "").replace("[", "(").replace("]", ")")
    icon = "💬" if it.get("kind") == "منشور" else "📰"
    url = it.get("url") or ""
    if url:
        seen = str(it.get("date", "")).replace("-", "") + "T000000Z"
        tr_link = f"?view={quote(url, safe='')}&seen={seen}&t={quote((it.get('title') or '')[:200], safe='')}{auth_qs()}"
        if st.session_state.get("dos_link", "orig") == "tr":
            head, other = f"[{ttl}]({tr_link})", f" · [🌐 الأصل]({url})"
        else:
            head, other = f"[{ttl}]({url})", f" · [📖 مترجم]({tr_link})"
    else:
        head, other = ttl, ""
    line = f"- {icon} **{head}**  \n  {it.get('date', '')} · {it.get('source', '')} · {it.get('country') or 'بلد غير محدد'}{other}"
    if it.get("statement"):
        line += " · 🎤 فيه تصريح"
    if it.get("summary"):
        line += f"  \n  > {it['summary'][:300]}"
    return line


def _dos_group(g, scope, key):
    us = g.get("us_items") or []
    st.markdown(f"**{len(g['items'])} عنصر** (أخبار {g['news_count']} · منشورات {g['post_count']}) من **{len(g['sources'])} مصدر** · "
                f"من {g['first']} لحد {g['last']} · تصريحات: {g['statements']}"
                + (f" · 📈 أيام ارتفاع: {'، '.join(g['spikes'])}" if g.get("spikes") else ""))
    if g.get("long"):
        st.caption("⚠️ الخيط ده طويل (أكتر من 14 يوم)، ممكن يكون فيه أكتر من قصة. جرّب «أقل عدد أطراف مشتركة» = 3")
    names = [f"📋 العناصر ({len(g['items'])})"] + ([f"🇺🇸 الزاوية الأمريكية ({len(us)})"] if us else []) + ["🤖 برومبت التحليل"]
    tabs = st.tabs(names)
    with tabs[0]:
        if len(g["items"]) > 60:
            st.caption(f"آخر 60 من {len(g['items'])} (الباقي في التقرير اللي بيتنزل تحت)")
        st.markdown("\n".join(_dos_item_md(it) for it in g["items"][-60:]))
    if us:
        with tabs[1]:
            st.caption("تصريحات وتحركات ترامب وأمريكا اللي تخص الموضوع ده")
            st.markdown("\n".join(_dos_item_md(it) for it in us[-15:]))
    with tabs[-1]:
        st.caption("فيه المبادئ كلها: الدوافع، التبعات، الأحداث، الترابط، التصريحات ونتيجتها، قصد كل جريدة، وجهة نظر تانية، والحبكة.")
        kinds = ["🎬 اسكريبت 1 (عامية قاهرية، هوك وأفيهات وربط)", "🎬 اسكريبت 2 (نفس الروح + جدول وقايع وقواعد دقة)", "🧭 اسكريبت 3 (قراءة المشهد من وجهة نظرك)", "📜 شرح للمواطن (قانون / قرار / اقتصاد / جريمة)", "🧠 تحليل بس"]
        eg_mode_ = key.startswith("_eg") or key.startswith("egt")
        if eg_mode_:
            kinds = ["🇪🇬 اسكريبت شأن مصري (للمواطن، من غير سياسة المنطقة)"] + kinds
        if scope == "الموضوع" or eg_mode_:
            kinds = ["🔎 تقرير تتبّع (خط زمني + مقارنة المصادر + استنتاج)"] + kinds
        kind = st.radio("عايز إيه؟", kinds, horizontal=True, key=f"dos_pk_{key}")
        egy = True
        if kind.startswith("🧭"):  # الزاوية القومية في اسكريبت 3 بس
            egy_lbl = "🇪🇬 اكتب من زاوية قومية مصرية وعربية (المقياس هو مصلحة مصر والعرب)"
            egy = st.checkbox(egy_lbl, value=not eg_mode_, key=f"dos_egy_{key}")
        if kind.startswith("🇪🇬"):
            mins = pick(st, "مدة الفيديو (دقايق)", [3, 5, 8, 10, 15, 20], 8, f"dos_pme_{key}")
            txt = dossiers_mod.eg_script_prompt(g, mins)
        elif kind.startswith("🎬"):
            mins = pick(st, "مدة الفيديو (دقايق)", [3, 5, 8, 10, 15, 20], 8, f"dos_pm_{key}")
            txt = dossiers_mod.script_prompt2(scope, g, mins, egypt=egy) if kind.startswith("🎬 اسكريبت 2") else dossiers_mod.script_prompt(scope, g, mins, egypt=egy)
        elif kind.startswith("🧭"):
            mins = pick(st, "مدة الفيديو (دقايق)", [3, 5, 8, 10, 15, 20], 8, f"dos_pm3_{key}")
            view = st.text_area("رأيك المبدئي في الموضوع (اختياري، جملة أو اتنين)", key=f"dos_view_{key}", height=90,
                                placeholder="مثال: أنا شايف إن ترامب بيستعد لضربة تقيلة بس مستني اللحظة المناسبة اقتصادياً")
            st.caption("لو كتبت رأيك، الذكاء الاصطناعي هيبني عليه لو الأدلة بتسنده، ولو بتعاكسه هيقولك بصراحة. ولو سيبتها فاضية هيطلّع هو أقوى قراءة من الأخبار.")
            txt = dossiers_mod.script_prompt3(scope, g, mins, view, egypt=egy)
        elif kind.startswith("📜"):
            txt = dossiers_mod.explain_prompt(scope, g)
        elif kind.startswith("🔎"):
            txt = dossiers_mod.topic_prompt(g)
        else:
            txt = dossiers_mod.prompt_for(scope, g)
        st.info("📋 دوس علامة النسخ اللي فوق على الشمال في المربع الرمادي، وبعدين الصقه في شات Claude.")
        st.code(txt, language=None)


def render_posts(P="pol"):
    sx = PROFS[P]["sx"]
    s = S()
    s.setdefault("posts", [])
    st.caption("الصق هنا اي منشور من فيس او تويتر عن ترند او قضية، وهيتخلط مع الاخبار في نفس الملفات والخيوط. "
               "المنشورات بتتعامل كادعاءات محتاجة تحقق، مش كأخبار مؤكدة.")
    with st.form(f"dos_post_form{sx}", clear_on_submit=True):
        c1, c2, c3 = st.columns(3)
        pdate = c1.date_input("تاريخ المنشور", value=datetime.now(core.TZ).date())
        plat = c2.selectbox("المنصة", POST_PLATFORMS)
        author = c3.text_input("اسم الحساب")
        text = st.text_area("نص المنشور", height=150)
        c4, c5 = st.columns(2)
        url = c4.text_input("رابط المنشور (اختياري)")
        country = c5.text_input("بلد صاحب الحساب (اختياري)")
        if st.form_submit_button("➕ أضف المنشور", use_container_width=True):
            if text.strip():
                s["posts"].insert(0, {"date": pdate.isoformat(), "platform": plat, "author": author.strip(),
                                      "text": text.strip(), "url": url.strip(), "country": country.strip(), "scope": P})
                persist()
                st.session_state["dos_msg"] = "✅ المنشور اتضاف. دوس «اربط» تاني عشان يدخل في التحليل."
            else:
                st.warning("اكتب نص المنشور الأول.")
    mine = [(i0, p0) for i0, p0 in enumerate(s["posts"]) if (p0.get("scope") or "pol") == P]
    if mine and st.toggle(f"💬 اعرض المنشورات المحفوظة ({len(mine)})", key=f"dos_show_posts{sx}"):
        if True:
            for i, p in mine:
                c1, c2 = st.columns([6, 1])
                c1.markdown(f"**{p.get('platform', '')} · {p.get('author') or 'حساب'}** · {p.get('date', '')}  \n{p.get('text', '')[:400]}")
                if c2.button("🗑️ امسح", key=f"dos_pdel{sx}_{i}"):
                    s["posts"].pop(i)
                    persist()
                    st.rerun()


@_fragment
def render_topic_track(P="eg"):
    """تتبّع موضوع أو ترند: بيدور عليه في المصادر، يجمّع الأخبار في ملف واحد وخيوط، ويطلّعلك برومبت تحليل. P = "eg" للشأن المصري، "pol" للسياسة والمنطقة"""
    egp = P == "eg"
    pk, rk = ("egt", "egt") if egp else ("trd", "trend")
    st.markdown("### 🔎 تتبّع موضوع كامل (من كل المصادر)" if egp else "### 🔎 تتبّع ترند أو موضوع طارئ")
    st.caption("اكتب الموضوع زي ما بتقوله (" + ("مثال: ارتفاع أسعار الطماطم في الأسواق، أو جريمة عروس الإسماعيلية" if egp else
               "مثال: وقف الطيران الأمريكي بين الولايات، أو توقف مايكروسوفت في دول كتير") + "). هيدور عليه في المصادر اللي تختارها، "
               "ويجمّع الأخبار في ملف واحد مرتب بالتاريخ، ويربطها في خيوط، ويجهزلك برومبت تحليل واستنتاج. المنشورات اللي ضفتها في «💬 منشورات فيس وتويتر» بتدخل لو فيها نفس الكلمات. "
               "ولو الموضوع هيفضل معاك، دوس تحت «💾 خلّيه ملف دائم».")
    c1, c2 = st.columns([3, 2])
    topic = c1.text_input("🎯 الموضوع", key=f"{pk}_topic", placeholder="ارتفاع أسعار الطماطم في الأسواق" if egp else "وقف الطيران الأمريكي بين الولايات")
    alts = c2.text_input("كلمات بديلة (بفاصلة)", key=f"{pk}_alts", placeholder="سعر الطماطم، الطماطم، أسعار الخضار" if egp else "ground stop، FAA، تأخير الرحلات، مطارات أمريكا")
    c3, c4 = st.columns(2)
    days = pick(c3, "الفترة (أيام)", [1, 2, 3, 7, 14, 30, 60], 3 if not egp else 7, f"{pk}_days")
    if egp:
        scopes = ["🇪🇬 المصادر المصرية بس", "🇪🇬 + القنوات العربية (تغطيتها لمصر)", "🌐 كل حاجة (مصرية وعربية وإسرائيلية وأمريكية وبريطانية)"]
    else:
        scopes = ["🌍 كل مصادر المنطقة والعالم (إسرائيلية وأمريكية وبريطانية وتركيا وإيران وإثيوبيا وعربية)", "🇺🇸🇬🇧 الأمريكية والبريطانية بس", "🌐 كل ده + المصرية"]
    scope = c4.radio("هدور فين؟", scopes, key=f"{pk}_scope")
    if egp:
        sel = [e for g, ents in EGYPT.items() if g != ARAB_EG_GROUP for e in ents]
        if scope.startswith("🇪🇬 +") or scope.startswith("🌐"):
            sel += list(EGYPT[ARAB_EG_GROUP])
        if scope.startswith("🌐"):
            seen = {e[1] for e in sel}
            sel += [e for gg in (ARABIC, ISRAEL, USA, UK) for ents in gg.values() for e in ents if e[1] not in seen]
        gcode, gn_c = "EG", "EG"
    else:
        groups_ = (USA, UK) if scope.startswith("🇺🇸") else (ISRAEL, USA, UK, REGION, ARABIC)
        sel = [e for gg in groups_ for ents in gg.values() for e in ents]
        if scope.startswith("🌐"):
            sel += [e for g, ents in EGYPT.items() if g != ARAB_EG_GROUP for e in ents]
        seen_d, uniq = set(), []
        for e in sel:
            if e[1] not in seen_d:
                seen_d.add(e[1])
                uniq.append(e)
        sel, gcode, gn_c = uniq, None, "US"
    sel += [(x["label"], x["domain"], x["lang"]) for x in S()["sources"] if x["group"] in (("eg", "egt") if egp else ("il", "us", "uk", "rg", "trend"))]
    st.caption(f"عدد المصادر اللي هيدور فيها: {len(sel)}" + ("" if egp else " (ممكن ياخد كام دقيقة)"))
    tok_ = _sec("ACTIONS_TOKEN")
    gh_ok = bool(tok_ and GH_GIST and GH_TOKEN)
    runmode = st.radio("التشغيل", ["🚀 على GitHub (تقدر تقفل التطبيق وترجع بعدين)", "⚡ هنا في التطبيق دلوقتي (لازم تفضل فاتحه)"],
                       index=0 if gh_ok else 1, horizontal=True, key=f"{pk}_runmode")
    on_gh = runmode.startswith("🚀")
    if on_gh:
        if not gh_ok:
            st.warning("التشغيل على GitHub محتاج ACTIONS_TOKEN في Secrets (نفس اللي عملناه للبحث الشامل) واتأكد إنك رفعت ملف topic.yml.")
        else:
            ss_ = st.session_state
            repo_, branch_ = _sec("GH_REPO") or gh_actions.DEFAULT_REPO, _sec("GH_BRANCH") or "main"
            t0_, lr_ = ss_.get(f"{pk}_lr", (0, None))
            if time.time() - t0_ > 45:
                try:
                    lr_ = gh_actions.last_run(tok_, repo_, "topic.yml")
                except Exception as ex:
                    lr_ = None
                    st.caption(f"تعذّر قراءة حالة التشغيل ({type(ex).__name__}). اتأكد إنك رفعت ملف topic.yml.")
                ss_[f"{pk}_lr"] = (time.time(), lr_)
            busy_ = bool(lr_ and lr_["status"] in ("queued", "in_progress", "waiting", "requested"))
            t1_, tst = ss_.get(f"{pk}_tst", (0, {}))
            if time.time() - t1_ > 60:
                try:
                    tst = store.load_file(GH_TOKEN, GH_GIST, TOPIC_STATUS, {}) or {}
                except Exception:
                    tst = {}
                ss_[f"{pk}_tst"] = (time.time(), tst)
            if lr_:
                ico_ = {"success": "✅ خلص", "failure": "❌ فشل", "cancelled": "⚪ اتلغى"}.get(lr_["conclusion"] or "", "⏳ شغال دلوقتي" if busy_ else "—")
                st.markdown(f"آخر تشغيل على GitHub: **{ico_}** · [التفاصيل]({lr_['url']})")
            if tst.get("topic"):
                st.caption(f"آخر موضوع اتبعت: «{tst['topic']}» · الحالة: {tst.get('state', '')}" + (f" · {tst.get('count', 0)} نتيجة" if tst.get("count") is not None else "")
                           + (f" · {tst.get('error', '')[:100]}" if tst.get("error") else ""))
            b1_, b2_ = st.columns(2)
            if b1_.button("🚀 ابعت التتبّع لـ GitHub", type="primary", disabled=busy_, use_container_width=True, key=f"{pk}_ghgo"):
                if not topic.strip():
                    st.warning("اكتب الموضوع الأول.")
                else:
                    code_ = (["local", "arab", "all"] if egp else ["world", "us_uk", "plus_eg"])[scopes.index(scope)]
                    try:
                        store.save_file(GH_TOKEN, GH_GIST, TOPIC_CFG, {"topic": topic.strip(), "alts": alts.strip(), "days": days, "scope": code_, "profile": P})
                        ok_, msg_ = gh_actions.dispatch(tok_, repo_, branch_, "topic.yml")
                        if ok_:
                            time.sleep(3)
                            ss_.pop(f"{pk}_lr", None)
                            ss_.pop(f"{pk}_tst", None)
                            st.success(f"✅ اتبعت لـ GitHub الساعة {datetime.now(core.TZ).strftime('%H:%M')}. " + msg_ + " ولما يخلص دوس «حدّث وحمّل النتيجة».")
                        else:
                            st.error(msg_)
                    except Exception as ex:
                        st.error(f"مقدرتش أبدأ ({type(ex).__name__}).")
            if b2_.button("🔄 حدّث وحمّل النتيجة", use_container_width=True, key=f"{pk}_ghref"):
                ss_.pop(f"{pk}_lr", None)
                ss_.pop(f"{pk}_tst", None)
                try:
                    n_ = reload_results()
                    st.success(f"✅ اتحمّل آخر نتايج محفوظة ({n_} قسم). النتيجة تحت.")
                except Exception as ex:
                    st.error(f"تعذّر التحميل ({type(ex).__name__}).")
    if (not on_gh) and st.button("🔎 تتبّع الموضوع", type="primary", use_container_width=True, key=f"{pk}_go"):
        if not topic.strip():
            st.warning("اكتب الموضوع الأول.")
        else:
            terms = [topic.strip()] + [t.strip() for t in TERM_SPLIT.split(alts) if t.strip()]
            g_ = globals()
            keep = {k: g_[k] for k in ("query", "match", "joiner", "ctype", "start_utc", "end_utc", "max_rec", "verify", "hide_nomatch")}
            end_ = datetime.now(timezone.utc)
            g_.update(query="، ".join(terms), match=core.MATCH_MODES[0], joiner="OR", ctype="الكل",
                      start_utc=end_ - timedelta(days=days), end_utc=end_, max_rec=40, verify=True, hide_nomatch=True)
            try:
                seed, gnotes = [], []
                with st.spinner("جارٍ جلب نتائج أخبار Google أولاً…"):
                    try:
                        seed, gnotes = gn_seed(sel, gn_c, terms)
                    except Exception as ex:
                        gnotes = [f"Google News تعذّر: {type(ex).__name__}"]
                do_search(rk, core.jobs_for_sources(sel, gcode), sel, terms=terms, seed=seed)
                if gnotes and st.session_state.get(f"res_{rk}"):
                    st.session_state[f"res_{rk}"]["used"] += gnotes
                try:
                    direct_title_hits(rk, sel, terms)
                except Exception as ex:
                    st.caption(f"تعذّر البحث المباشر في الخلاصات: {type(ex).__name__}")
            finally:
                g_.update(keep)
            res_ = st.session_state.get(f"res_{rk}")
            if res_ is not None:
                res_.update(topic=topic.strip(), alts=alts.strip(), days=days, created=datetime.now(timezone.utc).isoformat(timespec="seconds"))
    res = st.session_state.get(f"res_{rk}") or {}
    if not res.get("topic"):
        return
    st.markdown(f"#### 📌 {res['topic']}" + (f" — خلال آخر {res.get('days', '?')} يوم" if res.get("days") else ""))
    lab = lambda d: about_plain(re.sub(r"<[^>]+>", "", html.unescape(src_label(d, with_domain=False))).split("·")[0])
    items = [dossiers_mod.from_app_item(a, lab, source_country, "تتبّع موضوع") for a in res.get("items") or []
             if isinstance(a, dict) and a.get("url") and (a.get("title") or a.get("title_ar"))]
    words = [res["topic"]] + [t.strip() for t in TERM_SPLIT.split(res.get("alts", "")) if t.strip()]
    if st.checkbox("💬 ضمّ منشوراتي (فيس/تويتر) اللي فيها كلمات الموضوع", value=True, key=f"{pk}_posts"):
        pats = [dossiers_mod.make_pattern([w]) for w in words]
        for p_ in S().get("posts", []):
            if (p_.get("scope") or "pol") == P and any(pt is not None and pt.search(dossiers_mod.normalize(p_.get("text", ""))) for pt in pats):
                items.append(dossiers_mod.from_post(p_))
    if not items:
        st.info("مفيش نتائج للموضوع ده في الفترة دي. جرّب كلمات بديلة أو فترة أطول أو مصادر أكتر.")
    else:
        r = dossiers_mod.run(items, [], 3, 2, res.get("days"), topic=res["topic"])
        if r["dossiers"]:
            _dos_group(r["dossiers"][0], "الموضوع", pk)
        if r["threads"]:
            st.markdown(f"**🧵 الخيوط اللي طلعت جوا الموضوع ({r['n_threads']})**")
            labels = [f"{n}. {t['name']} — {len(t['items'])} عنصر · {t['first']} → {t['last']}" for n, t in enumerate(r["threads"][:8], 1)]
            pick_thr = st.selectbox("اختار خيط تشوفه", labels, key=f"{pk}_thread")
            n = labels.index(pick_thr) + 1
            _dos_group(r["threads"][n - 1], "الخيط", f"{pk}_t{n}")
    st.markdown("**💾 خلّيه ملف دائم**")
    st.caption("بيتحفظ في «📁 الملفات» بتاعتك، وأي خبر جديد فيه الكلمات دي (من أي بحث بتعمله بعد كده) يدخله لوحده.")
    d1, d2, d3 = st.columns([3, 3, 1])
    fname = d1.text_input("اسم الملف", value=res["topic"][:60], key=f"{pk}_fname")
    fwords = d2.text_input("كلمات الملف (بفاصلة، كلمة واحدة منهم تكفي)", value="، ".join(w for w in words[1:]) or res["topic"], key=f"{pk}_fwords")
    fkind = d3.radio("النوع", ["ملف", "ترند"], key=f"{pk}_fkind")
    if st.button("💾 احفظه ملف دائم", key=f"{pk}_save"):
        ws = [w.strip() for w in re.split(r"[,،]", fwords) if w.strip()]
        if fname.strip() and ws:
            _dos_save_cfg(dossiers_mod.add_dossier(_dos_cfg_text(P), fname.strip(), ws, fkind), P)
            st.success(f"✅ اتحفظ ملف «{fname.strip()}». روح «🔗 اربط واعرض» عشان يظهر في الملفات.")
        else:
            st.warning("اكتب اسم الملف وكلمة واحدة على الأقل.")
    if st.toggle("📄 اعرض كروت نتائج البحث (الأصل والترجمة)", key=f"{pk}_cards"):
        render_results(rk)


def render_dossiers_cfg(P="pol"):
    sx = PROFS[P]["sx"]
    egp = P == "eg"
    with st.expander("⚙️ الملفات اللي بيدور عليها (تقدر تضيف وتعدل)"):
        txt = _dos_cfg_text(P)
        dos, err = dossiers_mod.parse_config(txt)
        if dos:
            st.markdown("**الملفات الحالية:** " + "، ".join(("🇺🇸 " if d["lens"] else "📈 " if d["type"] == "ترند" else "📁 ") + d["name"] for d in dos))
        if st.button(("🆕 ضيف الملفات الجاهزة للشأن المصري (السيسي 2030، الإخوان، الاقتصاد والأسعار، قوانين، جرائم...)" if egp else "🆕 ضيف الملفات الجاهزة الجديدة (غزة وفلسطين، رفح، حدود السودان، اقتصاد مصر، قوانين، جرائم...)"), key=f"dos_merge_btn{sx}", use_container_width=True):
            try:
                new_txt, added = dossiers_mod.merge_defaults(txt, egypt=egp)
                if added:
                    _dos_save_cfg(new_txt, P)
                    st.session_state["dos_msg"] = "✅ اتضاف: " + "، ".join(added) + ". دوس «اربط» عشان تظهر."
                else:
                    st.session_state["dos_msg"] = "كل الملفات الجاهزة موجودة عندك بالفعل."
                st.rerun()
            except Exception as ex:
                st.error(f"مقدرتش أضيف ({type(ex).__name__}).")
        st.markdown("**➕ ملف أو ترند جديد بسرعة**")
        c1, c2 = st.columns(2)
        nm = c1.text_input("اسم الملف (مثال: ترند الطماطم في تونس)", key=f"dos_new_name{sx}")
        kind = c2.radio("النوع", ["ملف", "ترند"], horizontal=True, key=f"dos_new_kind{sx}")
        g1 = st.text_input("كلمات المجموعة الأولى مفصولة بفاصلة (مثال: طماطم، tomato)", key=f"dos_new_g1{sx}")
        g2 = st.text_input("كلمات مجموعة تانية لازم تتذكر معاها (اختياري، مثال: تونس، tunisia)", key=f"dos_new_g2{sx}")
        if st.button("➕ ضيف الملف", key=f"dos_new_btn{sx}"):
            groups = [[w.strip() for w in re.split(r"[,،]", g) if w.strip()] for g in (g1, g2)]
            groups = [g for g in groups if g]
            if nm.strip() and groups:
                raw = json.loads(txt)
                raw.append({"name": nm.strip(), "type": kind, "all_of": groups})
                _dos_save_cfg(json.dumps(raw, ensure_ascii=False, indent=1), P)
                st.session_state["dos_msg"] = f"✅ اتضاف ملف «{nm.strip()}». دوس «اربط» عشان يظهر."
                st.rerun()
            else:
                st.warning("اكتب اسم الملف وكلمة واحدة على الأقل.")
        if IS_ADMIN:
            st.markdown("**تعديل متقدم (JSON)**: كل ملف ليه اسم، ونوع، و all_of = مجموعات كلمات، والخبر لازم يلمس كلمة من كل مجموعة.")
            new = st.text_area("تعريف الملفات", value=txt, height=300, key=f"dos_cfg_edit{sx}")
            c1, c2 = st.columns(2)
            if c1.button("💾 احفظ التعديل", key=f"dos_cfg_save{sx}"):
                ok, e2 = dossiers_mod.parse_config(new)
                if ok:
                    _dos_save_cfg(new, P)
                    st.session_state["dos_msg"] = "✅ اتحفظت الملفات."
                    st.rerun()
                else:
                    st.error(f"فيه غلطة في الكتابة: {e2}")
            if c2.button("↩️ رجّع الملفات الأصلية", key=f"dos_cfg_reset{sx}"):
                _dos_save_cfg((dossiers_mod.egypt_config_text() if egp else dossiers_mod.default_config_text()), P)
                st.session_state.pop(f"dos_cfg_edit{sx}", None)
                st.rerun()
        if err:
            st.error(f"تعريف الملفات فيه مشكلة: {err}")


SEARCH_CFG, SEARCH_STATUS = "marsad_search_cfg.json", "marsad_search_job.json"
SEARCH_SCOPES = {"il": "🇮🇱 المصادر الإسرائيلية", "us": "🇺🇸 المصادر الأمريكية", "uk": "🇬🇧 المصادر البريطانية",
                 "rg": "🌍 تركيا وإيران وإثيوبيا", "eg": "🇪🇬 الشأن المصري", "wr": "✍️ الكتّاب الأجانب", "wa": "🇸🇦 الكتّاب العرب"}
PERIOD_OPTS = {"آخر 12 ساعة": 0.5, "آخر 24 ساعة": 1, "آخر يومين": 2, "آخر 3 أيام": 3, "آخر 5 أيام": 5, "آخر 7 أيام": 7}


def _period_label(d):
    if d is None:
        return ""
    d = float(d)
    if d < 1:
        return f"آخر {int(round(d * 24))} ساعة"
    return "آخر 24 ساعة" if d == 1 else f"آخر {int(d)} يوم"


def _sa_load(force=False):
    ss = st.session_state
    if force or "sa_cfg" not in ss:
        try:
            ss["sa_cfg"] = store.load_file(GH_TOKEN, GH_GIST, SEARCH_CFG, {}) or {}
            ss["sa_status"] = store.load_file(GH_TOKEN, GH_GIST, SEARCH_STATUS, {}) or {}
        except Exception:
            ss.setdefault("sa_cfg", {})
            ss.setdefault("sa_status", {})
    return ss["sa_cfg"], ss["sa_status"]


def render_search_all():
    """زر واحد: بحث في كل المصادر على GitHub، والنتيجة تظهر في تاباتها وتدخل في الربط وتفضل لحد ما تبحث تاني"""
    with st.expander("🚀 بحث شامل في كل المصادر مرة واحدة (بيشتغل على GitHub)", expanded=False):
        if not (GH_TOKEN and GH_GIST):
            st.info("محتاج التخزين الدائم (GITHUB_TOKEN وGIST_ID).")
            return
        ss = st.session_state
        cfg, stt = _sa_load()
        tok, repo, branch = _sec("ACTIONS_TOKEN"), _sec("GH_REPO") or gh_actions.DEFAULT_REPO, _sec("GH_BRANCH") or "main"
        st.caption("اكتب كلماتك مرة واحدة ودوس الزرار، وسيب GitHub يدور في **كل** المصادر (إسرائيلية وأمريكية وبريطانية وتركيا وإيران وإثيوبيا والكتّاب) "
                   "بنفس طريقة بحث كل تاب. لما يخلص، كل تاب هتلاقي فيه نتيجته زي ما هي، وكلها بتدخل في الربط، وبتفضل محفوظة لحد ما تدوس بحث جديد. "
                   "مش لازم تفضل فاتح التطبيق.")
        terms_txt = st.text_area("كلمات البحث (كلمة أو أكتر، افصل بفاصلة أو سطر جديد). سيبها فاضية لو عايز كل ما نُشر من غير كلمات",
                                 value=cfg.get("terms", ""), height=90, key="sa_terms", placeholder="مثال: سد النهضة، إثيوبيا، الدعم السريع")
        c1, c2 = st.columns(2)
        plabels = list(PERIOD_OPTS)
        cur_p = next((k for k, v in PERIOD_OPTS.items() if v == cfg.get("days")), "آخر 3 أيام")
        period = c1.selectbox("الفترة", plabels, index=plabels.index(cur_p), key="sa_period")
        joiner_lbl = c2.radio("لو كتبت أكتر من كلمة", ["أي كلمة منهم (OR)", "كل الكلمات مع بعض (AND)"], index=0 if cfg.get("joiner", "OR") == "OR" else 1,
                              key="sa_join")
        st.caption("💡 اقتراح: لو بتتابع حدث ساخن النهاردة اختار 12 أو 24 ساعة. للقصة الشغالة اختار 3 أيام. للصورة الأوسع 7 أيام. كل ما كبّرت الفترة، البحث بياخد وقت أطول.")
        keys_sel = st.multiselect("ادور في إيه؟", list(SEARCH_SCOPES), default=[k for k in (cfg.get("scopes") or list(SEARCH_SCOPES)) if k in SEARCH_SCOPES],
                                  format_func=lambda k: SEARCH_SCOPES[k], key="sa_scopes")
        use_body = st.checkbox("🔬 ابحث كمان جوه نص المقالات (أبطأ بكتير بس بيلقط اللي كلمتك في وسطه)", value=bool(cfg.get("use_body")), key="sa_body")
        lr = None
        if tok:
            t0, v0 = ss.get("sa_lr", (0, None))
            if time.time() - t0 > 45:
                try:
                    v0 = gh_actions.last_run(tok, repo, "search.yml")
                except Exception as ex:
                    v0 = None
                    st.caption(f"تعذّر قراءة حالة التشغيل ({type(ex).__name__}). اتأكد إنك رفعت ملف search.yml.")
                ss["sa_lr"] = (time.time(), v0)
            lr = v0
        else:
            st.warning("زرار التشغيل محتاج ACTIONS_TOKEN في Secrets (نفس اللي عملناه للتقرير اليومي).")
        busy = bool(lr and lr["status"] in ("queued", "in_progress", "waiting", "requested"))
        if lr:
            ico = {"success": "✅ خلص", "failure": "❌ فشل", "cancelled": "⚪ اتلغى"}.get(lr["conclusion"] or "", "⏳ شغال دلوقتي" if busy else "—")
            when = keys_mod.parse(lr["created"])
            wt = when.astimezone(core.TZ).strftime("%Y-%m-%d %H:%M") if when else ""
            st.markdown(f"آخر تشغيل: **{ico}** — بدأ {wt} (القاهرة) · [افتح التفاصيل على GitHub]({lr['url']})")
        if stt.get("done") is not None:
            parts = [f"{SEARCH_SCOPES.get(k, k).split(' ', 1)[-1]}: {n}" for k, n in (stt.get("counts") or {}).items()]
            fin = keys_mod.parse(stt.get("finished") or stt.get("updated"))
            ft = fin.astimezone(core.TZ).strftime("%Y-%m-%d %H:%M") if fin else ""
            state = "✅ خلص" if stt.get("state") == "done" else "⏳ شغال (خلّص " + str(len(stt.get("done") or [])) + " قسم)"
            st.markdown(f"آخر بحث شامل: **{state}** · {ft} (القاهرة) · الكلمات: {'، '.join(stt.get('terms') or []) or 'من غير كلمات (كل ما نُشر)'} · {_period_label(stt.get('days'))}"
                        + (f"  \nعدد النتايج: {' · '.join(parts)}" if parts else ""))
            for k, e in (stt.get("errors") or {}).items():
                st.warning(f"{SEARCH_SCOPES.get(k, k)}: فشل ({e[:120]})")
        if ss.get("sa_msg"):
            st.success(ss["sa_msg"])
        b1, b2 = st.columns(2)
        if b1.button("▶️ ابحث في كل المصادر دلوقتي", type="primary", disabled=busy or not tok, key="sa_go", use_container_width=True):
            if not keys_sel:
                st.warning("اختار قسم واحد على الأقل.")
            else:
                new_cfg = {"terms": terms_txt, "days": PERIOD_OPTS[period], "joiner": "OR" if joiner_lbl.startswith("أي") else "AND",
                           "scopes": keys_sel, "use_body": use_body}
                try:
                    store.save_file(GH_TOKEN, GH_GIST, SEARCH_CFG, new_cfg)
                    ss["sa_cfg"] = new_cfg
                    ok, msg = gh_actions.dispatch(tok, repo, branch, "search.yml")
                    if ok:
                        time.sleep(4)
                        ss.pop("sa_lr", None)
                        ss["sa_msg"] = f"✅ اتبعت الأمر لـ GitHub الساعة {datetime.now(core.TZ).strftime('%H:%M')}. " + msg + " ولما يخلص دوس «حدّث وحمّل النتايج»."
                        st.rerun()
                    st.error(msg)
                except Exception as ex:
                    st.error(f"مقدرتش أبدأ ({type(ex).__name__}).")
        if b2.button("🔄 حدّث وحمّل النتايج في التابات", key="sa_refresh", use_container_width=True):
            ss.pop("sa_msg", None)
            ss.pop("sa_lr", None)
            _sa_load(force=True)
            try:
                n = reload_results()
                ss["sa_msg"] = f"✅ اتحمّل {n} قسم من آخر نتايج محفوظة. افتح أي تاب هتلاقي نتيجته، ودوس «اربط» تحت عشان تدخل في الخيوط."
            except Exception as ex:
                ss["sa_msg"] = f"تعذّر تحميل النتايج ({type(ex).__name__})."
            st.rerun()


@_fragment
def render_dossiers(P="pol"):
    ss = st.session_state
    sx, egp = PROFS[P]["sx"], P == "eg"
    if egp:
        st.caption("ملفات وخيوط الشأن المصري **لوحدها**: بتاخد بس نتايج تاب «الشأن المصري» وتتبّع المواضيع، ومبتتخلطش بسياسة المنطقة. "
                   "فيها ملفات جاهزة (نهاية حكم السيسي 2030 ومن بعده، الإخوان، الاقتصاد والأسعار…) وتقدر تعمل ملف جديد على أي موضوع أو ترند. "
                   "دوس «اربط» وهتطلعلك الملفات والخيوط، وجوه كل ملف برومبت تحليل.")
    else:
        st.caption("بيجمع الأخبار اللي عندك في ملفات (مواضيع ثابتة) وخيوط (قصص بتتكون لوحدها من الأخبار اللي فيها نفس الأطراف في أيام قريبة). "
                   "عدّ وربط بس من غير ذكاء اصطناعي، فمش بيصرف رصيد. والتحليل بيتعمل بالبرومبت الجاهز لأهم الملفات.")
    if ss.get("dos_msg"):
        st.success(ss.pop("dos_msg"))
    if not egp:
        with st.expander("📖 ازاي تستخدم التبويب ده؟ (خطوة بخطوة)", expanded=_dos_result(P) is None):
            st.markdown(DOS_HELP)
        render_search_all()
    if auto_pull_jobs():
        st.success("✅ لقيت بحث جديد خلص على GitHub، وحمّلت نتايجه لوحدي.")
    pool = {a["url"]: a for a in _pool_for(P)}
    tabs_n = Counter(t_ for a in pool.values() for t_ in (a.get("tabs") or [a.get("tab", "")]) if (t_ in EG_TABS) == egp)
    st.markdown(f"🔎 **أرشيف البحث" + (" (الشأن المصري)" if egp else " (السياسة والمنطقة)") + f":** {len(pool)} خبر (آخر 21 يوم)"
                + (f" — منهم {', '.join(f'{TAB_LABELS.get(k, k)} ({n})' for k, n in tabs_n.most_common(6))}" if pool else
                   " — لسه مفيش. أي بحث تعمله في تاب الشأن المصري أو تتبّع موضوع هيتسجل هنا لوحده." if egp else
                   " — لسه مفيش. أي بحث تعمله في أي تاب هيتسجل هنا لوحده."))
    if pool and st.button("🗑️ امسح أرشيف البحث ده", key=f"dos_pool_clear{sx}"):
        gone = set(pool)
        ss["dos_pool"] = {u: a for u, a in _dos_pool().items() if u not in gone}
        if PERSIST:
            try:
                store.save_file(GH_TOKEN, GH_GIST, DOS_POOL_FILE, ss["dos_pool"])
            except Exception:
                pass
        st.rerun()
    with st.expander("💬 منشورات فيس وتويتر (الخلاط التحليلي)", expanded=False):
        render_posts(P)
    render_dossiers_cfg(P)
    if not egp:
        if st.toggle("🔎 ترند أو موضوع طارئ (وقف الطيران، عطل مايكروسوفت…)؟ تتبّعه من كل المصادر واعمله ملف", key="trd_open"):
            render_topic_track("pol")

    st.markdown("### 🔗 اربط الأخبار")
    opts = {"بحث": "نتايج البحث اللي في التابات", "يومي": "التقرير اليومي (آخر 7 أيام)", "مخصص": "التقرير المخصص",
            "محفوظات": "المحفوظات", "أمريكا": "تحركات أمريكا وتصريحات ترامب (ملف جاهز بالروابط)"}
    if egp:
        opts = {"بحث": "نتايج البحث بتاعة الشأن المصري (التاب وتتبّع المواضيع)"}
    use = st.multiselect("هات الأخبار منين؟", list(opts), default=list(opts), format_func=lambda k: opts[k], key=f"dos_use{sx}")
    ups = st.file_uploader("ملفات أخبار إضافية CSV (اختياري) — الأعمدة: date, source, country, title, url, summary",
                           type=["csv"], accept_multiple_files=True, key=f"dos_up{sx}")
    DAYS_OPTS = {"آخر 6 ساعات": 0.25, "آخر 12 ساعة": 0.5, "آخر 24 ساعة": 1, "آخر يومين": 2, "آخر 3 أيام": 3, "آخر 5 أيام": 5,
                 "آخر 7 أيام": 7, "آخر 14 يوم": 14, "آخر 30 يوم": 30}
    pp = _dos_prefs().get(P) or {}
    lk_opts = ["🌐 الصفحة الأصلية (للتصوير والمرجع)", "📖 صفحة الترجمة"]
    dl = pick(st, "📅 الأخبار بتاعة أنهي فترة؟ (أي حاجة أقدم من كده بتتشال)", list(DAYS_OPTS),
              pp.get("days") if pp.get("days") in DAYS_OPTS else "آخر 7 أيام", f"dos_days2{sx}")
    max_days = DAYS_OPTS[dl]
    st.caption("💡 اقتراح: **6 أو 12 ساعة** لو بتتابع حدث ساخن لسه حاصل. **24 ساعة أو 3 أيام** لقصة شغالة. **7 أيام** للصورة العامة (الافتراضي). **14 أو 30 يوم** للخلفية بس. "
               "الأخبار اللي مفيهاش ساعة (زي ملف أمريكا والمنشورات) بتتحسب باليوم.")
    lk = st.radio("🔗 لما أدوس على عنوان خبر يفتح إيه؟", lk_opts, index=1 if pp.get("link") == "tr" else 0, horizontal=True, key=f"dos_link_r{sx}")
    st.session_state["dos_link"] = "tr" if lk.startswith("📖") else "orig"
    st.caption("وجنب كل خبر لينك صغير تاني للتاني، فتقدر تفتح الاتنين.")
    c1, c2 = st.columns(2)
    window = pick(c1, "أقصى فرق بالأيام بين خبرين في نفس الخيط", range(1, 8), int(pp.get("win") or 3), f"dos_win{sx}")
    mins = pick(c2, "أقل عدد أطراف مشتركة (زي مصر + إثيوبيا = 2)", [1, 2, 3], int(pp.get("min") or 2), f"dos_min{sx}")
    _dos_save_prefs(P, {"days": dl, "link": "tr" if lk.startswith("📖") else "orig", "win": window, "min": mins})
    cur_params = {"max_days": max_days, "window": window, "mins": mins, "use": sorted(use)}
    old_res = _dos_result(P)
    auto = False
    if old_res:
        old_params = old_res.get("params") or {**cur_params, "max_days": old_res.get("max_days")}
        auto = old_params != cur_params  # غيّرت الفترة أو الإعدادات: نربط تاني لوحدنا بدل ما نعرض القديم
        made = keys_mod.parse(old_res.get("created"))
        if made and max_days:
            if made.tzinfo is None:
                made = made.replace(tzinfo=timezone.utc)  # السيرفر بيكتب الوقت بتوقيت UTC
            if datetime.now(timezone.utc) - made > timedelta(days=float(max_days)):
                auto = True  # الربط المحفوظ أقدم من الفترة نفسها (زي ربط آخر 24 ساعة اتعمل من 3 أيام): نحدّثه
    clicked = st.button("🔗 اربط واعرض الملفات والخيوط", type="primary", use_container_width=True, key=f"dos_run{sx}")
    if clicked or auto:
        dos, err = dossiers_mod.parse_config(_dos_cfg_text(P))
        if err:
            st.error(f"تعريف الملفات فيه مشكلة: {err}")
        else:
            with st.spinner("⏳ غيّرت الفترة، فبيربط تاني على الفترة الجديدة…" if auto and not clicked else "⏳ بيجمع ويربط…"):
                items, counts = _dos_collect(use, ups, P)
                if not items:
                    st.warning("مفيش أخبار. اعمل بحث في أي تاب، أو استنى التقرير اليومي، أو ضيف منشورات.")
                else:
                    res = dossiers_mod.run(items, dos, window, mins, max_days)
                    res["counts"] = counts
                    res["params"] = cur_params
                    res["newest"] = max((str(it.get("date") or "") for it in items), default="")
                    ss[PROFS[P]["res_key"]] = res
                    if PERSIST:
                        try:
                            store.save_file(GH_TOKEN, GH_GIST, PROFS[P]["res_file"], res)
                        except Exception as e:
                            st.caption(f"النتيجة ما اتحفظتش في التخزين الدائم ({type(e).__name__})")

    res = _dos_result(P)
    if not res:
        st.info("دوس «اربط» عشان يطلعلك الملفات والخيوط. النتيجة بتفضل محفوظة لحد ما تربط تاني.")
        return
    st.divider()
    cr = keys_mod.parse(res.get("created"))
    ct = cr.strftime("%Y-%m-%d %H:%M") if cr else "؟"
    if res.get("max_days"):
        st.caption(f"📅 أخبار {_period_label(res['max_days'])} بس" + (f" · اتشال {res['dropped_old']} خبر أقدم" if res.get("dropped_old") else "") + f" · الربط اتعمل {ct}")
    else:
        st.warning(f"⚠️ النتيجة دي اتعملت {ct} من غير فلتر فترة، فممكن فيها أخبار قديمة. دوس «اربط واعرض» تاني فوق عشان تتنضف.")
    try:
        if res.get("first") and res.get("max_days") and str(res["first"])[:10] < (datetime.now(timezone.utc) - timedelta(days=float(res["max_days"]) + 1)).strftime("%Y-%m-%d"):
            st.warning("⚠️ النتيجة المعروضة قديمة (فيها أخبار أقدم من الفترة المختارة). دوس «اربط واعرض» تاني عشان تتحدّث.")
    except Exception:
        pass
    if not res.get("total"):
        nw = res.get("newest") or ""
        st.warning("مفيش أخبار في الفترة دي." + (f" أحدث خبر عندك في الأرشيف بتاريخ **{nw[:10]}**، يعني مفيش بحث جديد اتعمل من ساعتها." if nw else "")
                   + " اعمل بحث جديد (أو «🚀 بحث شامل في كل المصادر» فوق ودوس «حدّث وحمّل النتايج») عشان تيجي أخبار النهارده، أو كبّر الفترة.")
        return
    nw = res.get("newest") or ""
    try:
        if nw and res.get("max_days") and nw[:10] < (datetime.now(timezone.utc) - timedelta(days=float(res["max_days"]) + 1)).strftime("%Y-%m-%d"):
            st.info(f"ℹ️ أحدث خبر عندك في الأرشيف بتاريخ {nw[:10]}. عشان تجيب أخبار النهارده اعمل بحث جديد أو «🚀 بحث شامل».")
    except Exception:
        pass
    st.caption(f"آخر ربط: {res.get('created', '').replace('T', ' ')} · الأخبار جت من: "
               + "، ".join(f"{k} ({v})" for k, v in (res.get("counts") or {}).items() if v))
    m = st.columns(4)
    for col, (lbl, val) in zip(m, [("عنصر", res["total"]), ("ملف فيه أخبار", len(res["dossiers"])),
                                   ("خيط", res["n_threads"]), ("منشور", res["posts"])]):
        col.markdown(f"<div class='hm-stat'><b>{val}</b>{lbl}</div>", unsafe_allow_html=True)
    view = st.radio("اعرض", ["📁 الملفات", "🧵 خيوط القصص", "💡 اقتراحات ملفات جديدة"], horizontal=True, key=f"dos_view{sx}")
    if view.startswith("📁"):
        names = [g["name"] for g in res["dossiers"]]
        if names:
            def _dlabel(nm):
                g_ = res["dossiers"][names.index(nm)]
                ico_ = "🇺🇸" if g_.get("lens") else "📈" if g_["type"] == "ترند" else "📁"
                return f"{ico_} {nm} — {len(g_['items'])} عنصر"
            st.caption("بنعرض ملف واحد في المرة عشان الصفحة تفضل خفيفة. اختار الملف من القايمة.")
            pick_d = st.selectbox(f"اختار ملف ({len(names)} ملف فيه أخبار)", names, format_func=_dlabel, key=f"dos_pick{sx}")
            _dos_group(res["dossiers"][names.index(pick_d)], "الملف", f"{sx}d{names.index(pick_d)}")
        if not res["dossiers"]:
            st.info("مفيش ولا خبر دخل أي ملف. جرّب تجيب أخبار أكتر أو ضيف كلمات للملفات.")
    elif view.startswith("🧵"):
        st.caption("الخيط = أخبار فيها نفس الأطراف في أيام قريبة. مرتبة من الأهم (أخبار ومصادر وتصريحات أكتر).")
        if res["threads"]:
            tl_ = [f"{n}. {t['name']} — {len(t['items'])} عنصر · الملف: {t['dossier']}" for n, t in enumerate(res["threads"], 1)]
            pick_t = st.selectbox(f"اختار خيط ({len(tl_)} خيط)", tl_, key=f"dos_tpick{sx}")
            n_t = tl_.index(pick_t) + 1
            _dos_group(res["threads"][n_t - 1], "الخيط", f"{sx}t{n_t}")
        if not res["threads"]:
            st.info("مفيش خيوط. جرّب تكبّر عدد الأيام أو تقلل الأطراف المشتركة لـ 1.")
    else:
        st.caption("كلمات وأطراف بتتكرر في أخبار مش داخلة أي ملف. لو حاجة منها مهمة، دوس «اعمله ملف».")
        for i, sgg in enumerate(res["suggested_words"]):
            c1, c2 = st.columns([4, 1])
            c1.markdown(f"**{sgg['word']}** — في {sgg['news']} خبر و{sgg['posts']} منشور")
            if c2.button("➕ اعمله ملف", key=f"dos_sg{sx}_{i}"):
                _dos_save_cfg(dossiers_mod.add_dossier(_dos_cfg_text(P), f"مقترح: {sgg['word']}", [sgg["word"]]), P)
                ss["dos_msg"] = f"✅ اتعمل ملف «{sgg['word']}». دوس «اربط» تاني عشان يتملى."
                st.rerun()
        if res.get("suggested_entities"):
            st.markdown("**أطراف بتظهر كتير من غير ملف:** " + "، ".join(f"{e['entity']} ({e['count']})" for e in res["suggested_entities"]))
        if not res["suggested_words"]:
            st.info("مفيش كلمات متكررة كفاية.")
    if st.toggle("⬇️ جهّز التقرير الكامل للتنزيل (ملف نصي)", key=f"dos_dlt{sx}"):
        st.download_button("⬇️ نزّل التقرير", dossiers_mod.briefing_md(res), file_name="dossiers_report.md", key=f"dos_dl{sx}")


EG_PRESETS = {
    "🚨 جرائم وحوادث": "جريمة، مقتل، القبض على، النيابة العامة، حادث",
    "⚖️ قوانين وقرارات": "قانون، مجلس النواب، قرار جمهوري، الجريدة الرسمية، تعديل تشريعي",
    "💰 اقتصاد وأسعار": "الدولار، الجنيه، التضخم، الأسعار، الدعم، البنك المركزي",
    "🇸🇩 الحدود مع السودان": "السودان، الحدود، لاجئين، أرقين، حلايب",
    "🇵🇸 غزة ورفح": "غزة، رفح، معبر رفح، فلسطين، المساعدات",
    "💍 مجتمع وأحوال شخصية": "زواج، طلاق، أسرة، قضية رأي عام",
    "🏥 صحة وتعليم": "المستشفيات، التأمين الصحي، الثانوية العامة، الجامعات، التعليم",
    "⛽ خدمات وطاقة": "الكهرباء، انقطاع الكهرباء، الوقود، البنزين، المياه",
}

with tab_eg:
    use_filters("eg", "full")
    st.caption("أخبار الشأن الداخلي المصري من صحف ومواقع مصرية بس: جرائم وحوادث، ومجتمع، واقتصاد وأسعار، وقوانين وقرارات، والحدود، والخدمات. "
               "اختار موضوع جاهز تحت أو اكتب كلماتك في الخانة فوق. وللشرح (القانون ده بيعمل إيه ولزمته إيه) روح تاب «🧵 الملفات والخيوط» واختار «📜 شرح للمواطن».")
    pre = st.multiselect("🎯 مواضيع جاهزة (بتدور على كلماتها كلها)", list(EG_PRESETS), key="eg_pre")
    if pre:
        if query.strip():
            st.caption("كلماتك اللي فوق هي اللي بتتستخدم (المواضيع الجاهزة بتشتغل لما الخانة تبقى فاضية).")
        else:
            query = "، ".join(EG_PRESETS[p] for p in pre)
            joiner = "OR"
            st.caption(f"هيدور على: {query}")
    eg_view = st.radio("عايز إيه؟", ["🔎 تتبّع موضوع كامل (أسعار الطماطم، جريمة معينة…) من كل المصادر", "📰 بحث عادي في المصادر", "🧵 ملفات وخيوط الشأن المصري (منفصلة عن السياسة)"], key="eg_view")
    if eg_view.startswith("🔎"):
        render_topic_track("eg")
    elif eg_view.startswith("🧵"):
        render_dossiers("eg")
    else:
        curated_tab("eg", EGYPT, "EG", "EG", "ابحث في المصادر المصرية")


with tab_dr:
    if IS_ADMIN:
        render_watch()
    render_daily()

with tab_dos:
    render_dossiers()

with tab_sv:
    render_saved()

with tab_ms:
    with st.expander("🎧 إعدادات القراءة الصوتية (للمترو والسماعات)"):
        tts_settings("tts")
        st.radio("ما الذي يُقرأ عند الضغط على «🎧 استمع»؟", TTS_MODES, key="tts_mode")
        st.caption("تُجهَّز القراءة بصوت عربي عصبي، ويمكن تنزيلها MP3 قبل نزول المترو للاستماع بلا إنترنت.")
    if IS_ADMIN:
        render_manage()
        st.divider()
        render_keys_admin()
    else:
        st.info("إدارة المصادر والشفرات غير متاحة في النسخة التجريبية.")

save_results()
show_footer()
