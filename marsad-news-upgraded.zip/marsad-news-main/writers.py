# -*- coding: utf-8 -*-
"""قائمة الكتّاب والمحللين. عدّلها بحرية: أضف كاتباً بسطر W(...) أو احذف سطراً."""

COUNTRY_EN = {"US": "United States", "UK": "United Kingdom", "IL": "Israel", "SA": "Saudi Arabia", "GCC": "Gulf", "EG": "Egypt", "AR": "Arab world"}


def _or(items, fmt):
    items = list(items)
    if len(items) == 1:
        return fmt.format(items[0])
    return "(" + " OR ".join(fmt.format(i) for i in items) + ")"


def W(id, name_ar, name_en, outlet, country, kind, sites, feeds=(), aliases=(), heb=None, default=False, twitter=""):
    """kind: النوع الافتراضي (رأي/تحليل/خبر) — sites: مواقع النشر — feeds: خلاصات RSS لصفحة الكاتب إن وُجدت
    heb: (الاسم بالعبرية، [مواقع عبرية]) لبحث إضافي بالعبرية"""
    names = _or([name_en, *aliases], '"{}"')
    gn = []
    if sites and name_en and country in ("US", "UK", "IL"):
        gn.append({"q": f"{names} {_or(sites, 'site:{}')}", "hl": "en-US", "gl": "US", "ceid": "US:en", "lang": "English"})
    if country in ("SA", "GCC", "EG", "AR"):  # كاتب عربي: بحث بالاسم العربي (داخل مواقعه إن وُجدت)
        loc = {"SA": ("ar", "SA", "SA:ar"), "EG": ("ar", "EG", "EG:ar")}.get(country, ("ar", "SA", "SA:ar"))
        gn.append({"q": f'"{name_ar}"' + (f" {_or(sites, 'site:{}')}" if sites else ""), "hl": loc[0], "gl": loc[1], "ceid": loc[2], "lang": "Arabic"})
    if heb:
        gn.append(
            {"q": f'"{heb[0]}" {_or(heb[1], "site:{}")}', "hl": "iw", "gl": "IL", "ceid": "IL:he", "lang": "Hebrew"}
        )
    return {
        "id": id, "name_ar": name_ar, "name_en": name_en, "outlet": outlet, "country": country,
        "kind": kind, "feeds": list(feeds), "gn": gn, "default": default,
        "aliases": [name_en, *aliases], "twitter": twitter,
    }


NYT = "https://www.nytimes.com/svc/collections/v1/publish/https://www.nytimes.com/by/{}/rss.xml"
GUARDIAN = "https://www.theguardian.com/profile/{}/rss"

WRITERS = [
    # ── أمريكيون ──
    W("friedman", "توماس فريدمان", "Thomas Friedman", "نيويورك تايمز", "US", "رأي", ["nytimes.com"],
      feeds=[NYT.format("thomas-l-friedman")], aliases=["Thomas L. Friedman"], default=True),
    W("ignatius", "ديفيد إغناطيوس", "David Ignatius", "واشنطن بوست", "US", "رأي", ["washingtonpost.com"], default=True),
    W("hubbard", "بن هابرد", "Ben Hubbard", "نيويورك تايمز", "US", "تحليل", ["nytimes.com"],
      feeds=[NYT.format("ben-hubbard")], default=True),
    W("cook", "ستيفن كوك", "Steven A. Cook", "مجلس العلاقات الخارجية / فورين بوليسي", "US", "رأي",
      ["cfr.org", "foreignpolicy.com", "bloomberg.com"], aliases=["Steven Cook"], default=True),
    W("wright", "روبن رايت", "Robin Wright", "ذا نيويوركر", "US", "رأي", ["newyorker.com"]),
    W("amiller", "آرون ديفيد ميلر", "Aaron David Miller", "كارنيجي", "US", "تحليل",
      ["carnegieendowment.org", "foreignpolicy.com", "cnn.com"]),
    W("ibish", "حسين إبيش", "Hussein Ibish", "معهد دول الخليج العربية", "US", "رأي", ["agsiw.org", "bloomberg.com"]),
    # ── بريطانيون ──
    W("bowen", "جيريمي بوين", "Jeremy Bowen", "بي بي سي", "UK", "تحليل", ["bbc.com", "bbc.co.uk"], default=True),
    W("england", "أندرو إنجلاند", "Andrew England", "فاينانشال تايمز", "UK", "تحليل", ["ft.com"], default=True),
    W("wintour", "باتريك وينتور", "Patrick Wintour", "الغارديان", "UK", "تحليل", ["theguardian.com"],
      feeds=[GUARDIAN.format("patrick-wintour")], default=True),
    W("carlstrom", "جريج كارلستروم", "Gregg Carlstrom", "الإيكونوميست", "UK", "تحليل", ["economist.com"], default=True),
    W("chulov", "مارتن شولوف", "Martin Chulov", "الغارديان", "UK", "تحليل", ["theguardian.com"],
      feeds=[GUARDIAN.format("martin-chulov")]),
    W("beaumont", "بيتر بومونت", "Peter Beaumont", "الغارديان", "UK", "تحليل", ["theguardian.com"],
      feeds=[GUARDIAN.format("peter-beaumont")]),
    W("doucet", "ليز دوسيه", "Lyse Doucet", "بي بي سي", "UK", "تحليل", ["bbc.com", "bbc.co.uk"]),
    W("hearst", "ديفيد هيرست", "David Hearst", "ميدل إيست آي", "UK", "رأي", ["middleeasteye.net"]),
    W("engel", "ريتشارد إنجل", "Richard Engel", "إن بي سي", "US", "تحليل", ["nbcnews.com", "msnbc.com"]),
    W("torbati", "يغانه طربتي", "Yeganeh Torbati", "واشنطن بوست / نيويورك تايمز", "US", "خبر", ["washingtonpost.com", "nytimes.com"]),
    W("fassihi", "فرناز فصيحي", "Farnaz Fassihi", "نيويورك تايمز", "US", "خبر", ["nytimes.com"]),
    W("kingsley", "باتريك كينغسلي", "Patrick Kingsley", "نيويورك تايمز", "US", "تحليل", ["nytimes.com"]),
    W("kirkpatrick", "ديفيد كيركباتريك", "David D. Kirkpatrick", "ذا نيويوركر", "US", "تحليل", ["newyorker.com", "nytimes.com"],
      aliases=["David Kirkpatrick"]),
    W("cparker", "كلير باركر", "Claire Parker", "واشنطن بوست", "US", "خبر", ["washingtonpost.com"]),
    W("smagdy", "سامي مجدي", "Samy Magdy", "أسوشيتد برس", "US", "خبر", ["apnews.com"]),
    W("mmichael", "ماجي مايكل", "Maggie Michael", "رويترز / أسوشيتد برس", "US", "خبر", ["reuters.com", "apnews.com"]),
    W("hallam", "هانا علام", "Hannah Allam", "واشنطن بوست", "US", "خبر", ["washingtonpost.com", "propublica.org"]),
    W("liebermann", "أورين ليبرمان", "Oren Liebermann", "سي إن إن", "US", "خبر", ["cnn.com"]),
    W("maloney", "سوزان مالوني", "Suzanne Maloney", "بروكينغز", "US", "تحليل", ["brookings.edu", "foreignaffairs.com"]),
    W("dubowitz", "مارك دوبوفيتز", "Mark Dubowitz", "مؤسسة الدفاع عن الديمقراطيات", "US", "رأي", ["fdd.org", "wsj.com"]),
    W("nasr", "فالي نصر", "Vali Nasr", "جونز هوبكنز", "US", "رأي", ["foreignaffairs.com", "nytimes.com"]),
    W("boot", "ماكس بوت", "Max Boot", "واشنطن بوست", "US", "رأي", ["washingtonpost.com"]),
    W("lynch", "مارك لينش", "Marc Lynch", "جامعة جورج واشنطن / فورين أفيرز", "US", "تحليل",
      ["foreignaffairs.com", "foreignpolicy.com"], aliases=["Marc F. Lynch"], default=True),
    W("byman", "دانيال بايمان", "Daniel Byman", "CSIS / فورين أفيرز", "US", "تحليل",
      ["foreignaffairs.com", "csis.org", "lawfaremedia.org"], default=True),
    W("telhami", "شيبلي تلحمي", "Shibley Telhami", "بروكينجز / جامعة ميريلاند", "US", "رأي",
      ["brookings.edu", "foreignaffairs.com"], default=True),
    W("parsi", "تريتا بارسي", "Trita Parsi", "معهد كوينسي / Responsible Statecraft", "US", "رأي",
      ["quincyinst.org", "responsiblestatecraft.org"], default=True),
    W("katulis", "براين كاتوليس", "Brian Katulis", "معهد الشرق الأوسط", "US", "تحليل",
      ["mei.edu"], default=True),
    # ── بريطانيون (إضافات) ──
    W("oliphant", "رولاند أوليفانت", "Roland Oliphant", "التلغراف", "UK", "تحليل", ["telegraph.co.uk"]),
    W("rainey", "فينيشيا رايني", "Venetia Rainey", "التلغراف", "UK", "تحليل", ["telegraph.co.uk"]),
    W("samaan", "مجدي سمعان", "Magdy Samaan", "التايمز", "UK", "خبر", ["thetimes.com", "thetimes.co.uk"]),
    W("shenker", "جاك شينكر", "Jack Shenker", "الغارديان", "UK", "رأي", ["theguardian.com"]),
    W("maghafi", "نوال المغافي", "Nawal Al-Maghafi", "بي بي سي", "UK", "تحليل", ["bbc.com", "bbc.co.uk"]),
    W("gardner", "فرانك غاردنر", "Frank Gardner", "بي بي سي", "UK", "تحليل", ["bbc.com", "bbc.co.uk"]),
    W("hokayem", "إميل هوكايم", "Emile Hokayem", "المعهد الدولي للدراسات الاستراتيجية", "UK", "تحليل",
      ["iiss.org"], default=True),
    W("tisdall", "سايمون تيسدال", "Simon Tisdall", "الجارديان", "UK", "رأي",
      ["theguardian.com"], default=True),
    W("davidgardner", "ديفيد غاردنر", "David Gardner", "فاينانشال تايمز", "UK", "رأي",
      ["ft.com"], default=True),
    W("guerin", "أورلا غيرين", "Orla Guerin", "بي بي سي", "UK", "خبر", ["bbc.com", "bbc.co.uk"]),
    # ── إسرائيليون ──
    W("barel", "تسفي بارئيل", "Zvi Bar'el", "هآرتس", "IL", "تحليل", ["haaretz.com"], aliases=["Zvi Bar’el"],
      heb=("צבי בר\"אל", ["haaretz.co.il"]), default=True),
    W("perry", "سمدار بيري", "Smadar Perry", "يديعوت أحرونوت / Ynet", "IL", "تحليل", ["ynetnews.com"],
      heb=("סמדר פרי", ["ynet.co.il"]), default=True),
    W("yaari", "إيهود يعاري", "Ehud Yaari", "القناة 12 / معهد واشنطن", "IL", "تحليل",
      ["timesofisrael.com", "washingtonpost.com", "jpost.com", "washingtoninstitute.org"],
      heb=("אהוד יערי", ["mako.co.il", "13tv.co.il"]), default=True),
    W("issacharoff", "آفي يساخاروف", "Avi Issacharoff", "تايمز أوف إسرائيل / يديعوت", "IL", "تحليل",
      ["timesofisrael.com", "ynetnews.com"], feeds=["https://www.timesofisrael.com/writers/avi-issacharoff/feed/"],
      heb=("אבי יששכרוף", ["ynet.co.il"]), default=True),
    W("ravid", "باراك رافيد", "Barak Ravid", "أكسيوس", "IL", "خبر", ["axios.com"],
      heb=("ברק רביד", ["mako.co.il", "13tv.co.il"]), default=True),
    W("harel", "عاموس هرئيل", "Amos Harel", "هآرتس", "IL", "تحليل", ["haaretz.com"], heb=("עמוס הראל", ["haaretz.co.il"])),
    W("hass", "عميرة هاس", "Amira Hass", "هآرتس", "IL", "رأي", ["haaretz.com"], heb=("עמירה הס", ["haaretz.co.il"])),
    W("levy", "جدعون ليفي", "Gideon Levy", "هآرتس", "IL", "رأي", ["haaretz.com"], heb=("גדעון לוי", ["haaretz.co.il"])),
    W("pfeffer", "أنشل بفيفر", "Anshel Pfeffer", "هآرتس", "IL", "رأي", ["haaretz.com"], heb=("אנשל פפר", ["haaretz.co.il"])),
    W("barnea", "ناحوم برنياع", "Nahum Barnea", "يديعوت أحرونوت", "IL", "رأي", ["ynetnews.com"],
      heb=("נחום ברנע", ["ynet.co.il"])),
    W("caspit", "بن كاسبيت", "Ben Caspit", "معاريف", "IL", "رأي", ["maariv.co.il"], heb=("בן כספית", ["maariv.co.il"])),
    W("limor", "يوآف ليمور", "Yoav Limor", "إسرائيل هيوم", "IL", "تحليل", ["israelhayom.com"],
      heb=("יואב לימור", ["israelhayom.co.il"])),
    W("benyishai", "رون بن يشاي", "Ron Ben-Yishai", "Ynet", "IL", "تحليل", ["ynetnews.com"],
      heb=("רון בן ישי", ["ynet.co.il"])),
    W("hemo", "أوهاد حمو", "Ohad Hemo", "القناة 12", "IL", "خبر", ["timesofisrael.com"], heb=("אוהד חמו", ["mako.co.il"])),
    W("anghel", "إيتاي أنجل", "Itai Anghel", "القناة 12", "IL", "خبر", ["timesofisrael.com"], heb=("איתי אנגל", ["mako.co.il"])),
    W("yehezkeli", "تسفي يحزقيلي", "Zvi Yehezkeli", "القناة 13 / 12", "IL", "تحليل", ["timesofisrael.com", "jpost.com"],
      heb=("צבי יחזקאלי", ["13tv.co.il", "mako.co.il"])),
    W("alufbenn", "ألوف بن", "Aluf Benn", "هآرتس", "IL", "رأي", ["haaretz.com"],
      heb=("אלוף בן", ["haaretz.co.il"]), default=True),
    W("yossimelman", "يوسي ميلمان", "Yossi Melman", "هآرتس / معاريف", "IL", "تحليل",
      ["haaretz.com", "maariv.co.il"], default=True),
    # ── كتّاب عرب ──
    W("atwan", "عبد الباري عطوان", "Abdel Bari Atwan", "رأي اليوم", "AR", "رأي", ["raialyoum.com"], default=True),
    W("sharbel", "غسان شربل", "Ghassan Charbel", "الشرق الأوسط", "AR", "رأي", ["aawsat.com"], default=True),
    W("alrashed", "عبد الرحمن الراشد", "Abdulrahman Al-Rashed", "الشرق الأوسط", "SA", "رأي",
      ["aawsat.com", "asharq.com"], default=True),
]

WRITER_GROUPS = {
    "🇺🇸 أمريكيون": [w for w in WRITERS if w["country"] == "US"],
    "🇬🇧 بريطانيون": [w for w in WRITERS if w["country"] == "UK"],
    "🇮🇱 إسرائيليون": [w for w in WRITERS if w["country"] == "IL"],
}
